using System.Collections.Generic;
using UnityEngine;

public static class ProvinceDatabase
{
    private static List<ProvinceData> provinces = null;

    /// <summary>Returns all provinces in the database.</summary>
    public static List<ProvinceData> GetAllProvinces()
    {
        if (provinces == null) BuildProvinces();
        return provinces;
    }

    /// <summary>Finds a province by name.</summary>
    public static ProvinceData GetProvince(string name)
    {
        if (provinces == null) BuildProvinces();
        return provinces.Find(p => p.provinceName == name);
    }

    /// <summary>Returns all provinces controlled by the given faction.</summary>
    public static List<ProvinceData> GetProvincesOwnedBy(int factionId)
    {
        if (provinces == null) BuildProvinces();
        return provinces.FindAll(p => p.controllingFactionId == factionId);
    }

    /// <summary>Returns all provinces in a given historical region.</summary>
    public static List<ProvinceData> GetProvincesInRegion(string region)
    {
        if (provinces == null) BuildProvinces();
        return provinces.FindAll(p => p.historicalRegion == region);
    }

    static void BuildProvinces()
    {
        provinces = new List<ProvinceData>();

        // Territory-map provinces: positions synced to TerritoryGraphRenderer (Y flipped: provinceY = 1 - graphY)
        AddProvince("England",       "British Isles",   new Vector2(0.149f, 0.603f)); // London
        AddProvince("Scotland",      "British Isles",   new Vector2(0.50f,  0.64f));
        AddProvince("Ireland",       "British Isles",   new Vector2(0.064f, 0.562f)); // Dublin
        AddProvince("Wales",         "British Isles",   new Vector2(0.44f,  0.54f));

        AddProvince("France",        "France",          new Vector2(0.181f, 0.662f)); // Paris
        AddProvince("Brittany",      "France",          new Vector2(0.36f,  0.44f));
        AddProvince("Normandy",      "France",          new Vector2(0.42f,  0.48f));
        AddProvince("Aquitaine",     "France",          new Vector2(0.38f,  0.40f));
        AddProvince("Provence",      "France",          new Vector2(0.222f, 0.789f)); // Marseille

        AddProvince("Spain",         "Iberia",          new Vector2(0.099f, 0.855f)); // Madrid
        AddProvince("Portugal",      "Iberia",          new Vector2(0.026f, 0.893f)); // Lisbon
        AddProvince("Catalonia",     "Iberia",          new Vector2(0.32f,  0.38f));

        AddProvince("Netherlands",   "Low Countries",   new Vector2(0.216f, 0.583f)); // Amsterdam
        AddProvince("Belgium",       "Low Countries",   new Vector2(0.210f, 0.619f)); // Brussels

        AddProvince("Prussia",       "German States",   new Vector2(0.331f, 0.580f)); // Berlin
        AddProvince("Bavaria",       "German States",   new Vector2(0.307f, 0.680f)); // Munich
        AddProvince("Saxony",        "German States",   new Vector2(0.58f,  0.52f));
        AddProvince("Hanover",       "German States",   new Vector2(0.285f, 0.555f)); // Hamburg
        AddProvince("Baden",         "German States",   new Vector2(0.52f,  0.46f));
        AddProvince("Westphalia",    "German States",   new Vector2(0.52f,  0.52f));

        AddProvince("Piedmont",      "Italian States",  new Vector2(0.50f,  0.36f));
        AddProvince("Lombardy",      "Italian States",  new Vector2(0.52f,  0.34f));
        AddProvince("Venice",        "Italian States",  new Vector2(0.316f, 0.741f)); // Venice
        AddProvince("Tuscany",       "Italian States",  new Vector2(0.302f, 0.778f)); // Florence
        AddProvince("Papal States",  "Italian States",  new Vector2(0.319f, 0.821f)); // Rome
        AddProvince("Naples",        "Italian States",  new Vector2(0.343f, 0.845f)); // Naples
        AddProvince("Sicily",        "Italian States",  new Vector2(0.346f, 0.957f)); // Valletta

        AddProvince("Switzerland",   "Switzerland",     new Vector2(0.232f, 0.723f)); // Geneva

        AddProvince("Austria",       "Austrian Empire", new Vector2(0.372f, 0.677f)); // Vienna
        AddProvince("Bohemia",       "Austrian Empire", new Vector2(0.345f, 0.635f)); // Prague
        AddProvince("Hungary",       "Austrian Empire", new Vector2(0.408f, 0.693f)); // Budapest

        AddProvince("Poland",        "Poland",          new Vector2(0.420f, 0.635f)); // Krakow
        AddProvince("Baltic",        "Russia",          new Vector2(0.477f, 0.480f)); // Riga

        AddProvince("Sweden",        "Scandinavia",     new Vector2(0.395f, 0.424f)); // Stockholm
        AddProvince("Norway",        "Scandinavia",     new Vector2(0.54f,  0.72f));
        AddProvince("Denmark",       "Scandinavia",     new Vector2(0.320f, 0.509f)); // Copenhagen

        AddProvince("Russia",        "Russia",          new Vector2(0.660f, 0.508f)); // Moscow
        AddProvince("Ukraine",       "Russia",          new Vector2(0.564f, 0.625f)); // Kyiv

        AddProvince("Ottoman Empire","Balkans",         new Vector2(0.544f, 0.841f)); // Constantinople
        AddProvince("Serbia",        "Balkans",         new Vector2(0.428f, 0.753f)); // Belgrade
        AddProvince("Greece",        "Balkans",         new Vector2(0.471f, 0.909f)); // Athens
        AddProvince("Wallachia",     "Balkans",         new Vector2(0.504f, 0.764f)); // Bucharest
        AddProvince("Bosnia",        "Balkans",         new Vector2(0.64f,  0.38f));
        AddProvince("Dalmatia",      "Balkans",         new Vector2(0.395f, 0.800f)); // Dubrovnik

        AddProvince("Egypt",         "North Africa",    new Vector2(0.72f,  0.14f));
        AddProvince("Maghreb",       "North Africa",    new Vector2(0.30f,  0.14f));
    }

    static void AddProvince(string name, string region, Vector2 position)
    {
        provinces.Add(new ProvinceData(name, region, position, false));
    }
}
