using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class TerritoryGraphRenderer : MonoBehaviour
{
    public static TerritoryGraphRenderer Instance { get; private set; }

    static readonly Vector2 MAP_RES = new Vector2(1920, 1080);

    static Dictionary<string, Vector2> positions;
    Texture2D baseGrid;
    GameObject labelsContainer;
    public string highlightedSource = null;
    string pendingAttackSrcName = null;
    string pendingAttackTgtName = null;

    void Awake()
    {
        Instance = this;
        InitPositions();
    }

    void InitPositions()
    { 
        EnsurePositions();
    }

    static void EnsurePositions()
    {
        if (positions != null) return;
        positions = new Dictionary<string, Vector2>
        {
            { "London",         new Vector2(0.149f, 0.397f) },
            { "Dublin",         new Vector2(0.064f, 0.438f) },
            { "Paris",          new Vector2(0.181f, 0.338f) },
            { "Lyon",           new Vector2(0.215f, 0.265f) },
            { "Madrid",         new Vector2(0.099f, 0.145f) },
            { "Lisbon",         new Vector2(0.026f, 0.107f) },
            { "Toledo",         new Vector2(0.095f, 0.134f) },
            { "Amsterdam",      new Vector2(0.216f, 0.417f) },
            { "Brussels",       new Vector2(0.210f, 0.381f) },
            { "Rome",           new Vector2(0.319f, 0.179f) },
            { "Venice",         new Vector2(0.316f, 0.259f) },
            { "Florence",       new Vector2(0.302f, 0.222f) },
            { "Valletta",       new Vector2(0.346f, 0.043f) },
            { "Vienna",         new Vector2(0.372f, 0.323f) },
            { "Prague",         new Vector2(0.345f, 0.365f) },
            { "Geneva",         new Vector2(0.232f, 0.277f) },
            { "Krakow",         new Vector2(0.420f, 0.365f) },
            { "Constantinople", new Vector2(0.544f, 0.159f) },
            { "Dubrovnik",      new Vector2(0.395f, 0.200f) },
            { "Riga",           new Vector2(0.477f, 0.520f) },
            { "Berlin",         new Vector2(0.331f, 0.420f) },
            { "Munich",         new Vector2(0.307f, 0.320f) },
            { "Hamburg",        new Vector2(0.285f, 0.445f) },
            { "Stockholm",      new Vector2(0.395f, 0.576f) },
            { "Copenhagen",     new Vector2(0.320f, 0.491f) },
            { "Warsaw",         new Vector2(0.435f, 0.413f) },
            { "Moscow",         new Vector2(0.660f, 0.492f) },
            { "Kyiv",           new Vector2(0.564f, 0.375f) },
            { "Budapest",       new Vector2(0.408f, 0.307f) },
            { "Belgrade",       new Vector2(0.428f, 0.247f) },
            { "Athens",         new Vector2(0.471f, 0.091f) },
            { "Naples",         new Vector2(0.343f, 0.155f) },
            { "Marseille",      new Vector2(0.222f, 0.211f) },
            { "Bucharest",      new Vector2(0.504f, 0.236f) }
        };
    }

    public static Vector2 GetTerritoryPosition(string name)
    {
        EnsurePositions();
        return positions.TryGetValue(name, out Vector2 pos) ? pos : Vector2.zero;
    }

    public void CacheBaseGrid(Texture2D grid)
    {
        if (baseGrid != null && baseGrid != grid)
            DestroyImmediate(baseGrid);
        baseGrid = grid;
    }

    public void RedrawArrows()
    {
        if (MapLayerManager.Instance == null) return;

        Texture2D src = baseGrid ?? ProvinceGridRenderer.GenerateGridTexture(
            ProvinceDatabase.GetAllProvinces(), (int)MAP_RES.x, (int)MAP_RES.y);
        if (baseGrid == null) baseGrid = src;

        int w = (int)MAP_RES.x;
        int h = (int)MAP_RES.y;

        Texture2D composited = new Texture2D(w, h, TextureFormat.RGBA32, false);
        composited.wrapMode = TextureWrapMode.Clamp;
        composited.filterMode = FilterMode.Bilinear;
        Color[] pixels = src.GetPixels();
        composited.name = "ArrowGrid";

        DrawConnectionArrows(pixels, w, h);
        composited.SetPixels(pixels);
        composited.Apply();
        MapLayerManager.Instance.SetGridTexture(composited);

        RebuildArrowLabels();
    }

    void DrawConnectionArrows(Color[] pixels, int w, int h)
    {
        List<string> allTerritories = new List<string>(positions.Keys);
        HashSet<string> drawn = new HashSet<string>();

        foreach (string nameA in allTerritories)
        {
            if (!positions.ContainsKey(nameA)) continue;
            Vector2 uvA = positions[nameA];
            int x1 = (int)(uvA.x * w);
            int y1 = (int)(uvA.y * h);

            List<string> adj = TerritoryGraph.GetAdjacentTerritories(nameA);
            foreach (string nameB in adj)
            {
                string pairKey = nameA.CompareTo(nameB) < 0 ? nameA + "_" + nameB : nameB + "_" + nameA;
                if (drawn.Contains(pairKey)) continue;
                drawn.Add(pairKey);

                if (!positions.ContainsKey(nameB)) continue;
                Vector2 uvB = positions[nameB];
                int x2 = (int)(uvB.x * w);
                int y2 = (int)(uvB.y * h);

                Color lineColor = GetLineColor(nameA, nameB);

                DrawThickLine(pixels, w, h, x1, y1, x2, y2, lineColor, 3);
                DrawArrowhead(pixels, w, h, (x1 + x2) / 2, (y1 + y2) / 2, x1, y1, x2, y2, lineColor, 10);
            }
        }

        if (pendingAttackSrcName != null && pendingAttackTgtName != null &&
            positions.ContainsKey(pendingAttackSrcName) && positions.ContainsKey(pendingAttackTgtName))
        {
            Vector2 uvS = positions[pendingAttackSrcName];
            Vector2 uvT = positions[pendingAttackTgtName];
            int sx = (int)(uvS.x * w), sy = (int)(uvS.y * h);
            int tx = (int)(uvT.x * w), ty = (int)(uvT.y * h);
            Color gold = new Color(0.78f, 0.58f, 0.16f, 1f);
            DrawThickLine(pixels, w, h, sx, sy, tx, ty, gold, 4);
            DrawArrowhead(pixels, w, h, (sx + tx) / 2, (sy + ty) / 2, sx, sy, tx, ty, gold, 14);
        }
    }

    Color GetLineColor(string nameA, string nameB)
    {
        if (GameManager.Instance == null) return new Color(0.7f, 0.7f, 0.7f, 0.85f);

        if (highlightedSource != null)
        {
            bool aIsSource = nameA == highlightedSource;
            bool bIsSource = nameB == highlightedSource;
            if (aIsSource || bIsSource)
            {
                TerritoryData src = GameManager.Instance.territories.Find(t => t.name == highlightedSource);
                string other = aIsSource ? nameB : nameA;
                TerritoryData otherT = GameManager.Instance.territories.Find(t => t.name == other);
                if (src != null && otherT != null && otherT.controlledBy >= 0 && otherT.controlledBy != src.controlledBy)
                    return new Color(1.0f, 0.35f, 0.0f, 1.0f);
            }
        }

        int pid = GameManager.Instance.playerFactionId;

        TerritoryData tA = GameManager.Instance.territories.Find(t => t.name == nameA);
        TerritoryData tB = GameManager.Instance.territories.Find(t => t.name == nameB);
        if (tA == null || tB == null) return new Color(0.7f, 0.7f, 0.7f, 0.85f);

        bool ownedA = tA.controlledBy == pid;
        bool ownedB = tB.controlledBy == pid;

        if (ownedA && ownedB) return new Color(0.2f, 0.8f, 0.2f, 0.9f);
        if (ownedA && !ownedB && tB.controlledBy >= 0) return new Color(1.0f, 0.5f, 0.0f, 0.95f);
        if (ownedB && !ownedA && tA.controlledBy >= 0) return new Color(1.0f, 0.5f, 0.0f, 0.95f);
        if (tA.controlledBy >= 0 && tB.controlledBy >= 0) return new Color(0.9f, 0.2f, 0.2f, 0.9f);
        return new Color(0.7f, 0.7f, 0.7f, 0.85f);
    }

    static void DrawThickLine(Color[] pixels, int w, int h, int x1, int y1, int x2, int y2, Color c, int thickness)
    {
        int dx = Mathf.Abs(x2 - x1), dy = Mathf.Abs(y2 - y1);
        int sx = x1 < x2 ? 1 : -1, sy = y1 < y2 ? 1 : -1;
        int err = dx - dy, e2;

        float len = Mathf.Sqrt(dx * dx + dy * dy);
        float pdx = len > 0 ? -dy / len : 0;
        float pdy = len > 0 ? dx / len : 0;
        int halfThick = thickness / 2;

        int cx = x1, cy = y1;
        while (true)
        {
            for (int t = -halfThick; t <= halfThick; t++)
            {
                int px = cx + Mathf.RoundToInt(pdx * t);
                int py = cy + Mathf.RoundToInt(pdy * t);
                int idx = py * w + px;
                if (px >= 0 && px < w && py >= 0 && py < h && idx >= 0 && idx < pixels.Length)
                    pixels[idx] = Color.Lerp(pixels[idx], c, c.a);
            }
            if (cx == x2 && cy == y2) break;
            e2 = 2 * err;
            if (e2 > -dy) { err -= dy; cx += sx; }
            if (e2 < dx) { err += dx; cy += sy; }
        }
    }

    static void DrawArrowhead(Color[] pixels, int w, int h, int mx, int my, int x1, int y1, int x2, int y2, Color c, int size)
    {
        float angle = Mathf.Atan2(y2 - y1, x2 - x1);
        float arrowAngle = 0.45f;
        Color ac = new Color(c.r, c.g, c.b, 0.95f);

        for (int side = -1; side <= 1; side += 2)
        {
            for (int d = 0; d < size; d++)
            {
                int px = mx + (int)(Mathf.Cos(angle + side * arrowAngle) * d);
                int py = my + (int)(Mathf.Sin(angle + side * arrowAngle) * d);
                int idx = py * w + px;
                if (px >= 0 && px < w && py >= 0 && py < h && idx >= 0 && idx < pixels.Length)
                    pixels[idx] = Color.Lerp(pixels[idx], ac, ac.a);
            }
        }
    }

    public void HighlightAttackOptions(TerritoryData source)
    {
        highlightedSource = source?.name;
        RedrawArrows();
    }

    public void ClearHighlight()
    {
        highlightedSource = null;
        RedrawArrows();
    }

    public void ShowPendingAttack(string srcName, string tgtName)
    {
        pendingAttackSrcName = srcName;
        pendingAttackTgtName = tgtName;
        RedrawArrows();
    }

    public void ClearPendingAttack()
    {
        pendingAttackSrcName = null;
        pendingAttackTgtName = null;
        RedrawArrows();
    }

    void RebuildArrowLabels()
    {
        if (labelsContainer == null)
        {
            if (MapLayerManager.Instance == null || MapLayerManager.Instance.mapCanvas == null) return;
            labelsContainer = new GameObject("ArrowLabels");
            labelsContainer.transform.SetParent(MapLayerManager.Instance.mapCanvas.transform, false);
        }

        foreach (Transform child in labelsContainer.transform)
            Destroy(child.gameObject);

        HashSet<string> drawn = new HashSet<string>();
        foreach (var kvp in positions)
        {
            string nameA = kvp.Key;
            Vector2 uvA = kvp.Value;
            List<string> adj = TerritoryGraph.GetAdjacentTerritories(nameA);
            foreach (string nameB in adj)
            {
                string pairKey = nameA.CompareTo(nameB) < 0 ? nameA + "_" + nameB : nameB + "_" + nameA;
                if (drawn.Contains(pairKey)) continue;
                drawn.Add(pairKey);

                if (!positions.ContainsKey(nameB)) continue;
                Vector2 uvB = positions[nameB];
                Vector2 mid = (uvA + uvB) * 0.5f;

                string label = nameB.Length >= 3 ? nameB.Substring(0, 3).ToUpper() : nameB.ToUpper();
                Color lc = GetLineColor(nameA, nameB);

                GameObject lbl = new GameObject("ArrowLabel_" + label);
                lbl.transform.SetParent(labelsContainer.transform, false);
                RectTransform rt = lbl.AddComponent<RectTransform>();
                rt.anchorMin = rt.anchorMax = mid;
                rt.sizeDelta = new Vector2(32, 12);
                rt.anchoredPosition = Vector2.zero;

                Text t = lbl.AddComponent<Text>();
                t.font = GetFont();
                t.fontSize = 7;
                t.fontStyle = FontStyle.Bold;
                t.color = lc;
                t.text = label;
                t.alignment = TextAnchor.MiddleCenter;
                t.raycastTarget = false;
            }
        }
    }

    static Font GetFont() => UIFont.Get();
}
