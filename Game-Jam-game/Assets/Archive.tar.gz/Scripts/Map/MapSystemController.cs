using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MapSystemController : MonoBehaviour
{
    public static MapSystemController Instance { get; private set; }

    MapLayerManager mapLayerManager;
    MapTimelineUI timelineUI;
    int lastTurnYear = -1;
    bool initialSyncDone = false;

    public static Dictionary<string, string> territoryToProvince = new Dictionary<string, string>
    {
        { "London", "England" },
        { "Dublin", "Ireland" },
        { "Paris", "France" },
        { "Lyon", "France" },
        { "Madrid", "Spain" },
        { "Lisbon", "Portugal" },
        { "Toledo", "Spain" },
        { "Amsterdam", "Netherlands" },
        { "Brussels", "Belgium" },
        { "Rome", "Papal States" },
        { "Venice", "Venice" },
        { "Florence", "Tuscany" },
        { "Valletta", "Sicily" },
        { "Vienna", "Austria" },
        { "Prague", "Bohemia" },
        { "Geneva", "Switzerland" },
        { "Krakow", "Poland" },
        { "Constantinople", "Ottoman Empire" },
        { "Dubrovnik", "Dalmatia" },
        { "Riga", "Baltic" },
        { "Berlin", "Prussia" },
        { "Munich", "Bavaria" },
        { "Hamburg", "Hanover" },
        { "Stockholm", "Sweden" },
        { "Copenhagen", "Denmark" },
        { "Warsaw", "Poland" },
        { "Moscow", "Russia" },
        { "Kyiv", "Ukraine" },
        { "Budapest", "Hungary" },
        { "Belgrade", "Serbia" },
        { "Athens", "Greece" },
        { "Naples", "Naples" },
        { "Marseille", "Provence" },
        { "Bucharest", "Wallachia" }
    };

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    void Start()
    {
        string sceneName = SceneManager.GetActiveScene().name;
        if (sceneName == "MainMenu" || sceneName.ToLower().Contains("menu"))
        {
            gameObject.SetActive(false);
            return;
        }
        mapLayerManager = FindObjectOfType<MapLayerManager>();
        if (mapLayerManager == null)
        {
            GameObject mlm = new GameObject("MapLayerManager");
            mapLayerManager = mlm.AddComponent<MapLayerManager>();
        }

        timelineUI = FindObjectOfType<MapTimelineUI>();
        if (timelineUI == null)
        {
            GameObject tui = new GameObject("MapTimelineUI");
            timelineUI = tui.AddComponent<MapTimelineUI>();
        }

        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnTurnChanged += OnTurnChanged;
            GameManager.Instance.OnYearChanged += OnYearChanged;
            GameManager.Instance.OnFactionEliminated += OnFactionEliminated;
            GameManager.Instance.OnCombatResolved += OnCombatResolved;
            GameManager.Instance.OnStateChanged += OnGameStateChanged;
        }

        int turn = GameManager.Instance != null ? GameManager.Instance.currentTurn : 0;
        int year = TurnDateManager.GetYear(turn);

        if (timelineUI != null)
            timelineUI.UpdatePosition(turn);

        Debug.Log($"[MapSystem] Initialized. Turn {turn} — {TurnDateManager.GetDateString(turn)}");
    }

    void OnDestroy()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnTurnChanged -= OnTurnChanged;
            GameManager.Instance.OnYearChanged -= OnYearChanged;
            GameManager.Instance.OnFactionEliminated -= OnFactionEliminated;
            GameManager.Instance.OnCombatResolved -= OnCombatResolved;
            GameManager.Instance.OnStateChanged -= OnGameStateChanged;
        }
    }

    void OnTurnChanged(int turn)
    {
        int year = TurnDateManager.GetYear(turn);
        string date = TurnDateManager.GetDateString(turn);

        if (year != lastTurnYear)
        {
            lastTurnYear = year;
            if (mapLayerManager != null)
                mapLayerManager.RefreshPoliticalMap(year);

            Debug.Log($"[MapSystem] Turn {turn} — {date} — Map snapshot: {year}");
        }

        if (timelineUI != null)
            timelineUI.UpdatePosition(turn);
    }

    void OnYearChanged(int year)
    {
        if (mapLayerManager != null)
            mapLayerManager.RefreshPoliticalMap(year);
        lastTurnYear = year;
    }

    void OnFactionEliminated(FactionData faction)
    {
        foreach (ProvinceData p in ProvinceDatabase.GetAllProvinces())
        {
            if (p.controllingFactionId == faction.factionId)
            {
                p.controllingFactionId = -1;
                p.factionOverlayColor = Color.clear;
            }
        }
        RegenerateOverlay();
    }

    void OnGameStateChanged(GameState state)
    {
        if (!initialSyncDone && state == GameState.REINFORCEMENT_PHASE)
        {
            initialSyncDone = true;
            SyncProvincesFromTerritories();
            RegenerateOverlay();
            if (TerritoryGraphRenderer.Instance != null)
                TerritoryGraphRenderer.Instance.RedrawArrows();
        }
    }

    void OnCombatResolved(CombatResult result, TerritoryData source, TerritoryData target)
    {
        if (result.territoryCaptured)
        {
            SyncProvinceFromTerritory(source.name);
            SyncProvinceFromTerritory(target.name);
            RegenerateOverlay();
            if (TerritoryGraphRenderer.Instance != null)
            {
                TerritoryGraphRenderer.Instance.RedrawArrows();
                TerritoryGraphRenderer.Instance.ClearPendingAttack();
            }
            if (GameUIManager.Instance != null)
                GameUIManager.Instance.FlashTerritory(target.name);
        }
    }

    /// <summary>Syncs province ownership from the game's territory system. Should be called after territory ownership changes.</summary>
    public void SyncProvincesFromTerritories()
    {
        if (GameManager.Instance == null) return;

        foreach (var kvp in territoryToProvince)
        {
            string territoryName = kvp.Key;
            string provinceName = kvp.Value;

            TerritoryData terr = GameManager.Instance.territories.Find(t => t.name == territoryName);
            ProvinceData prov = ProvinceDatabase.GetProvince(provinceName);

            if (terr != null && prov != null)
            {
                prov.controllingFactionId = terr.controlledBy;
            }
        }

        RegenerateOverlay();
        if (TerritoryGraphRenderer.Instance != null)
            TerritoryGraphRenderer.Instance.RedrawArrows();
    }

    /// <summary>Updates a single province from its matching territory. Call when a territory changes ownership.</summary>
    public void SyncProvinceFromTerritory(string territoryName)
    {
        if (!territoryToProvince.ContainsKey(territoryName)) return;

        string provinceName = territoryToProvince[territoryName];
        TerritoryData terr = GameManager.Instance.territories.Find(t => t.name == territoryName);
        ProvinceData prov = ProvinceDatabase.GetProvince(provinceName);

        if (terr != null && prov != null)
        {
            prov.controllingFactionId = terr.controlledBy;
        }

        RegenerateOverlay();
    }

    /// <summary>Regenerates the faction overlay on the map. Safe to call multiple times.</summary>
    public void RegenerateOverlay()
    {
        if (mapLayerManager != null)
            mapLayerManager.RegenerateOverlay();
    }
}
