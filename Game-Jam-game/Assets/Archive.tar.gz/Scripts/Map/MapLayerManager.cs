using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.SceneManagement;

public class MapLayerManager : MonoBehaviour
{
    public static MapLayerManager Instance { get; private set; }

    RawImage layer1Parchment;
    RawImage layer2Political;
    RawImage layer3Overlay;
    public RawImage layer4Grid;

    public Canvas mapCanvas;
    Texture2D parchmentTexture;
    Texture2D currentPoliticalTexture;
    Texture2D currentOverlayTexture;

    int snapshotYear = -1;

    static readonly Vector2 MapAnchorMin = new Vector2(0.01f, 0.06f);
    static readonly Vector2 MapAnchorMax = new Vector2(0.73f, 0.94f);

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    void Start()
    {
        string sceneName = SceneManager.GetActiveScene().name;
        if (sceneName == "MainMenu" || sceneName.ToLower().Contains("menu"))
        {
            gameObject.SetActive(false);
            return;
        }
        BuildCanvasAndLayers();
        GenerateParchment();
        GenerateGridOverlay();
        if (GameManager.Instance != null)
            RefreshPoliticalMap(TurnDateManager.GetYear(GameManager.Instance.currentTurn));
        // Overlay is populated by MapSystemController.OnGameStateChanged on first REINFORCEMENT_PHASE
    }

    void BuildCanvasAndLayers()
    {
        GameObject co = new GameObject("MapCanvas", typeof(RectTransform));
        co.transform.SetParent(null);
        mapCanvas = co.AddComponent<Canvas>();
        mapCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
        mapCanvas.sortingOrder = -1;

        CanvasScaler scaler = co.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);

        GraphicRaycaster existingGR = co.GetComponent<GraphicRaycaster>();
        if (existingGR != null) DestroyImmediate(existingGR);

        Transform ct = co.transform;

        layer1Parchment = CreateLayer(ct, "Layer1_Parchment", 0);
        layer1Parchment.color = Color.white;
        layer2Political = CreateLayer(ct, "Layer2_Political", 1);
        layer2Political.color = new Color(1, 1, 1, 0.40f);
        layer3Overlay = CreateLayer(ct, "Layer3_Overlay", 2);
        layer3Overlay.color = Color.white;
        layer4Grid = CreateLayer(ct, "Layer4_Grid", 3);
        layer4Grid.color = Color.white;

        Texture2D blankMap = Resources.Load<Texture2D>("Maps/EuropeBlank");
        if (blankMap != null)
            layer2Political.texture = blankMap;
    }

    RawImage CreateLayer(Transform parent, string name, int siblingIndex)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        go.transform.SetSiblingIndex(siblingIndex);

        RawImage ri = go.AddComponent<RawImage>();
        ri.raycastTarget = false;

        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = MapAnchorMin;
        rt.anchorMax = MapAnchorMax;
        rt.sizeDelta = Vector2.zero;
        rt.anchoredPosition = Vector2.zero;

        return ri;
    }

    void GenerateParchment()
    {
        parchmentTexture = new Texture2D(1920, 1080, TextureFormat.RGBA32, false);
        parchmentTexture.wrapMode = TextureWrapMode.Clamp;
        parchmentTexture.filterMode = FilterMode.Bilinear;

        Color parchmentColor = new Color(0.78f, 0.68f, 0.52f);
        Color[] pixels = new Color[1920 * 1080];
        for (int i = 0; i < pixels.Length; i++)
        {
            float noise = Random.Range(-0.04f, 0.04f);
            pixels[i] = new Color(
                Mathf.Clamp01(parchmentColor.r + noise),
                Mathf.Clamp01(parchmentColor.g + noise),
                Mathf.Clamp01(parchmentColor.b + noise)
            );
        }
        parchmentTexture.SetPixels(pixels);
        parchmentTexture.Apply();

        if (layer1Parchment != null)
            layer1Parchment.texture = parchmentTexture;
    }

    void GenerateGridOverlay()
    {
        if (layer4Grid != null)
        {
            Texture2D gridTex = ProvinceGridRenderer.GenerateGridTexture(
                ProvinceDatabase.GetAllProvinces(), 1920, 1080);
            layer4Grid.texture = gridTex;
            layer4Grid.SetMaterialDirty();
            if (TerritoryGraphRenderer.Instance != null)
                TerritoryGraphRenderer.Instance.CacheBaseGrid(gridTex);
        }
    }

    Dictionary<int, Texture2D> apiCache = null;

    public void RefreshCachedMaps(Dictionary<int, Texture2D> cache)
    {
        apiCache = cache;
        int year = GameManager.Instance != null
            ? GameManager.Instance.CurrentYear
            : 1790;
        snapshotYear = -1;
        RefreshPoliticalMap(year);
        Debug.Log("[MapLayer] Cache received, refreshing map for year " + year);
    }

    public void RefreshPoliticalMap(int year)
    {
        if (year == snapshotYear && currentPoliticalTexture != null) return;
        snapshotYear = year;

        Debug.Log("[MapLayer] Applying texture for year " + year +
                  " texture null? " + (currentPoliticalTexture == null));
        Debug.Log("[MapLayer] layer2Political null? " + (layer2Political == null));

        MapSnapshot snapshot = HistoricalMapDatabase.GetClosestSnapshot(year);
        Texture2D mapTex = null;

        if (apiCache != null && apiCache.TryGetValue(snapshot.year, out Texture2D cached))
        {
            mapTex = cached;
        }

        if (mapTex == null)
        {
            mapTex = Resources.Load<Texture2D>(snapshot.resourcePath);
        }

        if (mapTex == null)
        {
            mapTex = HistoricalMapDatabase.GeneratePlaceholderMap(snapshot.year);
            mapTex.name = $"Placeholder_{snapshot.year}";
        }

        if (mapTex == null)
        {
            mapTex = new Texture2D(4, 4);
            mapTex.SetPixels(Enumerable.Repeat(
                new Color(0.45f, 0.35f, 0.25f), 16).ToArray());
            mapTex.Apply();
            mapTex.name = "FallbackMap";
        }

        Texture2D oldPolitical = currentPoliticalTexture;
        currentPoliticalTexture = mapTex;

        if (layer2Political != null)
        {
            layer2Political.texture = currentPoliticalTexture;
            layer2Political.SetMaterialDirty();
        }

        if (oldPolitical != null && oldPolitical != mapTex)
        {
            bool isDynamic = oldPolitical.name != null &&
                             (oldPolitical.name.StartsWith("Placeholder_") ||
                              oldPolitical.name.StartsWith("Synthetic_") ||
                              oldPolitical.name.StartsWith("Cached_"));
            if (isDynamic)
                DestroyImmediate(oldPolitical);
        }

        string source = mapTex.name != null && mapTex.name.StartsWith("Synthetic_") ? "Synthetic" :
                        mapTex.name != null && mapTex.name.StartsWith("Cached_") ? "Cache" :
                        mapTex.name != null && mapTex.name.StartsWith("Placeholder_") ? "Placeholder" : "Resource";
        Debug.Log($"[MapLayer] Political map updated to {snapshot.year} ({source})");
    }

    public void RegenerateOverlay()
    {
        List<ProvinceData> provinces = ProvinceDatabase.GetAllProvinces();
        Texture2D overlay = FactionOverlayRenderer.GenerateOverlay(provinces, 1920, 1080);
        SetOverlayTexture(overlay);
    }

    public void SetOverlayTexture(Texture2D overlay)
    {
        Texture2D old = currentOverlayTexture;
        currentOverlayTexture = overlay;
        if (layer3Overlay != null)
        {
            layer3Overlay.texture = overlay;
            layer3Overlay.SetMaterialDirty();
        }
        if (old != null && old != overlay)
            DestroyImmediate(old);
    }

    public void SetGridTexture(Texture2D tex)
    {
        if (layer4Grid != null)
        {
            layer4Grid.texture = tex;
            layer4Grid.SetMaterialDirty();
        }
    }
}
