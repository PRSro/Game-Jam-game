using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class HistoricalEvent
{
    public string eventName;
    public string description;
    public System.Action<GameManager> applyEffect;
    public System.Action<GameManager> clearEffect;
    public int earliestTurn;
    public int latestTurn;
    public bool hasTriggered = false;

    public HistoricalEvent(string name, string desc, System.Action<GameManager> apply, System.Action<GameManager> clear = null)
    {
        eventName = name;
        description = desc;
        applyEffect = apply;
        clearEffect = clear;
    }
}

public static class HistoricalEventManager
{
    static List<HistoricalEvent> eventPool;
    static HistoricalEvent activeEvent = null;

    public static HistoricalEvent ActiveEvent => activeEvent;

    static void EnsurePool()
    {
        if (eventPool != null) return;
        eventPool = new List<HistoricalEvent>();

        eventPool.Add(new HistoricalEvent("French Revolution",
            "All factions lose 5 power. Illuminati gains 10 influence.",
            gm => {
                foreach (var f in gm.factions)
                    if (!f.isEliminated) f.power = Mathf.Max(0, f.power - 5);
                var illum = gm.factions.Find(f => f.factionId == 0);
                if (illum != null && !illum.isEliminated)
                    illum.influence = Mathf.Min(100, illum.influence + 10);
            }) { earliestTurn = 0,   latestTurn = 18  });

        eventPool.Add(new HistoricalEvent("Napoleonic Wars",
            "ATTACK cards deal +3 damage this turn.",
            gm => { },
            gm => { }) { earliestTurn = 26,  latestTurn = 50  });

        eventPool.Add(new HistoricalEvent("Congress of Vienna",
            "All INFLUENCE cards gain +2 power this turn.",
            gm => { },
            gm => { }) { earliestTurn = 48,  latestTurn = 58  });

        eventPool.Add(new HistoricalEvent("Industrial Revolution",
            "All FARMING cards gain +3 power this turn.",
            gm => { },
            gm => { }) { earliestTurn = 0,   latestTurn = 100 });

        eventPool.Add(new HistoricalEvent("Revolutions of 1848",
            "A random faction loses 10 influence.",
            gm => {
                var alive = gm.factions.FindAll(f => !f.isEliminated);
                if (alive.Count > 0)
                {
                    var target = alive[Random.Range(0, alive.Count)];
                    target.influence = Mathf.Max(0, target.influence - 10);
                }
            }) { earliestTurn = 114, latestTurn = 124 });

        eventPool.Add(new HistoricalEvent("Unification of Germany",
            "The Carbonari gains 10 power. All factions lose 3 secrets.",
            gm => {
                var carbonari = gm.factions.Find(f => f.factionId == 3);
                if (carbonari != null && !carbonari.isEliminated)
                    carbonari.power = Mathf.Min(100, carbonari.power + 10);
                foreach (var f in gm.factions)
                    if (!f.isEliminated) f.secrets = Mathf.Max(0, f.secrets - 3);
            }) { earliestTurn = 160, latestTurn = 172 });

        eventPool.Add(new HistoricalEvent("Scramble for Africa",
            "All factions gain 5 secrets from colonial exploitation.",
            gm => {
                foreach (var f in gm.factions)
                    if (!f.isEliminated) f.secrets = Mathf.Min(50, f.secrets + 5);
            }) { earliestTurn = 178, latestTurn = 222 });

        eventPool.Add(new HistoricalEvent("Belle Époque",
            "BLACK_MARKET card effects doubled this turn.",
            gm => { },
            gm => { }) { earliestTurn = 198, latestTurn = 250 });

        eventPool.Add(new HistoricalEvent("Assassination at Sarajevo",
            "No ATTACK cards can be played this turn by anyone. All factions lose 3 power.",
            gm => {
                foreach (var f in gm.factions)
                    if (!f.isEliminated) f.power = Mathf.Max(0, f.power - 3);
            },
            gm => { }) { earliestTurn = 246, latestTurn = 254 });

        eventPool.Add(new HistoricalEvent("Russian Revolution",
            "Rosicrucian INFLUENCE cards gain +5 power. Freemasons lose 8 influence.",
            gm => {
                var masons = gm.factions.Find(f => f.factionId == 2);
                if (masons != null && !masons.isEliminated)
                    masons.influence = Mathf.Max(0, masons.influence - 8);
            },
            gm => { }) { earliestTurn = 252, latestTurn = 262 });

        eventPool.Add(new HistoricalEvent("Great Depression",
            "All factions lose 10 power. Secrets generation halved this turn.",
            gm => {
                foreach (var f in gm.factions)
                    if (!f.isEliminated) f.power = Mathf.Max(0, f.power - 10);
            }) { earliestTurn = 276, latestTurn = 300 });

        eventPool.Add(new HistoricalEvent("Rise of Fascism",
            "Knights Templar gain 15 power. SABOTAGE cards deal +2 damage this turn.",
            gm => {
                var templar = gm.factions.Find(f => f.factionId == 1);
                if (templar != null && !templar.isEliminated)
                    templar.power = Mathf.Min(100, templar.power + 15);
            },
            gm => { }) { earliestTurn = 284, latestTurn = 300 });

        eventPool.Add(new HistoricalEvent("World War II",
            "All factions lose 8 power. Rosicrucian cards are penalized -2 power.",
            gm => {
                foreach (var f in gm.factions)
                    if (!f.isEliminated) f.power = Mathf.Max(0, f.power - 8);
            },
            gm => { }) { earliestTurn = 296, latestTurn = 314 });

        eventPool.Add(new HistoricalEvent("Cold War Begins",
            "Espionage intensifies. All factions gain 5 secrets. Black market thrives.",
            gm => {
                foreach (var f in gm.factions)
                    if (!f.isEliminated) f.secrets = Mathf.Min(50, f.secrets + 5);
            },
            gm => { }) { earliestTurn = 312, latestTurn = 400 });

        eventPool.Add(new HistoricalEvent("Nuclear Age",
            "The ultimate weapon changes everything. A random faction gains 20 power.",
            gm => {
                var alive = gm.factions.FindAll(f => !f.isEliminated);
                if (alive.Count > 0)
                {
                    var target = alive[Random.Range(0, alive.Count)];
                    target.power = Mathf.Min(100, target.power + 20);
                }
            }) { earliestTurn = 308, latestTurn = 342 });
    }

    public static bool TryTriggerEvent(GameManager gm)
    {
        EnsurePool();
        if (activeEvent != null) return false;

        int turn = gm.currentTurn;

        List<HistoricalEvent> eligible = eventPool.FindAll(e =>
            !e.hasTriggered &&
            turn >= e.earliestTurn &&
            turn <= e.latestTurn);

        if (eligible.Count == 0) return false;

        HistoricalEvent selected = null;
        foreach (HistoricalEvent e in eligible)
        {
            float windowProgress = (float)(turn - e.earliestTurn) / Mathf.Max(1, e.latestTurn - e.earliestTurn);
            float triggerChance = Mathf.Lerp(0.05f, 0.30f, windowProgress);
            if (Random.value < triggerChance)
            {
                selected = e;
                break;
            }
        }

        if (selected == null) return false;

        selected.hasTriggered = true;
        activeEvent = selected;
        activeEvent.applyEffect?.Invoke(gm);
        gm.LogMessage($"\u26A1 HISTORICAL EVENT [{gm.CurrentYear} AD]: {activeEvent.eventName} \u2014 {activeEvent.description}");
        return true;
    }

    public static void Reset()
    {
        if (eventPool != null)
            foreach (var e in eventPool) e.hasTriggered = false;
        activeEvent = null;
    }

    public static void ClearActiveEvent(GameManager gm)
    {
        if (activeEvent != null)
        {
            activeEvent.clearEffect?.Invoke(gm);
            activeEvent = null;
        }
    }

    public static bool IsEventActive(string name)
    {
        return activeEvent != null && activeEvent.eventName == name;
    }

    public static int GetInfluenceBoost()
    {
        if (activeEvent != null && activeEvent.eventName == "Congress of Vienna")
            return 2;
        return 0;
    }

    public static int GetAttackBoostForFaction(int factionId)
    {
        if (activeEvent != null && activeEvent.eventName == "Napoleonic Wars")
            return 3;
        return 0;
    }

    public static int GetInfluenceBoostForFaction(int factionId)
    {
        if (activeEvent != null && activeEvent.eventName == "Russian Revolution" && factionId == 3)
            return 5;
        return 0;
    }

    public static int GetFarmingBoost()
    {
        if (activeEvent != null && activeEvent.eventName == "Industrial Revolution")
            return 3;
        return 0;
    }

    public static int GetSabotageBoost()
    {
        if (activeEvent != null && activeEvent.eventName == "Rise of Fascism")
            return 2;
        return 0;
    }

    public static float GetBlackMarketMultiplier()
    {
        if (activeEvent != null && activeEvent.eventName == "Belle Époque")
            return 2f;
        if (activeEvent != null && activeEvent.eventName == "Cold War Begins")
            return 1.5f;
        return 1f;
    }

    public static int GetPenaltyForFaction(int factionId)
    {
        if (activeEvent != null && activeEvent.eventName == "World War II" && factionId == 3)
            return -2;
        return 0;
    }

    public static bool IsAttacksBlocked()
    {
        return activeEvent != null && activeEvent.eventName == "Assassination at Sarajevo";
    }
}
