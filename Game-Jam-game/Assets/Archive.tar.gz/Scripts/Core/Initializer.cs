using UnityEngine;
using UnityEngine.EventSystems;

public static class Initializer
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    static void Initialize()
    {
        Screen.SetResolution(1280, 720, FullScreenMode.Windowed);

        if (GameManager.Instance == null)
        {
            GameObject gm = new GameObject("GameManager");
            gm.AddComponent<GameManager>();
            Object.DontDestroyOnLoad(gm);
        }

        if (AIController.Instance == null)
        {
            GameObject ai = new GameObject("AIController");
            ai.AddComponent<AIController>();
            Object.DontDestroyOnLoad(ai);
        }
        if (Object.FindObjectOfType<CutsceneManager>() == null)
        {
            GameObject cm = new GameObject("CutsceneManager");
            cm.AddComponent<CutsceneManager>();
        }
        if (Object.FindObjectOfType<MapSystemController>() == null)
        {
            GameObject msc = new GameObject("MapSystemController");
            msc.AddComponent<MapSystemController>();
        }
        if (Object.FindObjectOfType<MapAPIFetcher>() == null)
        {
            GameObject maf = new GameObject("MapAPIFetcher");
            maf.AddComponent<MapAPIFetcher>();
            Object.DontDestroyOnLoad(maf);
        }
        if (MainMenuManager.Instance == null)
        {
            GameObject mm = new GameObject("MainMenuManager");
            mm.AddComponent<MainMenuManager>();
        }

        if (GameUIManager.Instance == null)
        {
            GameObject gui = new GameObject("GameUIManager");
            gui.AddComponent<GameUIManager>();
            Object.DontDestroyOnLoad(gui);
        }

        if (Object.FindObjectOfType<TurnPhaseManager>() == null)
        {
            GameObject tpm = new GameObject("TurnPhaseManager");
            tpm.AddComponent<TurnPhaseManager>();
            Object.DontDestroyOnLoad(tpm);
        }

        if (Object.FindObjectOfType<EventSystem>() == null)
        {
            GameObject es = new GameObject("EventSystem", typeof(EventSystem));
            es.AddComponent<StandaloneInputModule>();
            Object.DontDestroyOnLoad(es);
        }
    }
}
