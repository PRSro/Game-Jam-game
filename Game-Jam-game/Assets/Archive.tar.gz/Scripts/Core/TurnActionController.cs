using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public static class TurnActionController
{
    public static bool PlayCard(FactionData faction, CardData card, FactionData target)
    {
        if (!ValidateCardPlay(faction, card)) return false;

        GameManager gm = GameManager.Instance;
        faction.hand.Remove(card);
        gm.QueueCard(card, faction, target);
        faction.cardsPlayedThisTurn++;
        gm.allCardsThisResolution.Add(card);
        if (faction.isPlayerControlled) gm.PlayerCardsThisResolution.Add(card);
        gm.OnCardPlayed?.Invoke(card, faction, target);
        gm.LogMessage($"{faction.factionName} plays {card.cardName}" +
            (target != faction ? $" targeting {target.factionName}" : ""));
        return true;
    }

    public static bool PlayTerritoryAttack(FactionData faction, CardData card,
                                           TerritoryData source, TerritoryData target)
    {
        if (!ValidateCardPlay(faction, card)) return false;
        if (!ValidateTerritoryAttack(faction, card, source, target)) return false;

        GameManager gm = GameManager.Instance;
        faction.hand.Remove(card);
        gm.QueueTerritoryAttack(card, faction, source, target);
        faction.cardsPlayedThisTurn++;
        gm.allCardsThisResolution.Add(card);
        if (faction.isPlayerControlled) gm.PlayerCardsThisResolution.Add(card);
        gm.LogMessage($"{faction.factionName} plays {card.cardName}: {source.name} attacks {target.name}!");
        return true;
    }

    public static bool Expand(FactionData faction, TerritoryData source, TerritoryData target)
    {
        if (!ValidateExpand(faction, source, target)) return false;

        source.troops = Mathf.Max(1, source.troops - 10);
        target.controlledBy = faction.factionId;
        target.troops = 5;
        if (!faction.territories.Contains(target)) faction.territories.Add(target);
        faction.cardsPlayedThisTurn++;
        GameManager gm = GameManager.Instance;
        gm.allCardsThisResolution.Add(null);
        if (faction.isPlayerControlled) gm.PlayerCardsThisResolution.Add(null);
        gm.LogMessage($"{faction.factionName} expands from {source.name} to {target.name}.");
        MapSystemController.Instance?.SyncProvinceFromTerritory(target.name);
        return true;
    }

    static bool ValidateCardPlay(FactionData faction, CardData card)
    {
        GameManager gm = GameManager.Instance;
        if (faction.isEliminated) return false;
        if (faction.cardsPlayedThisTurn >= GameManager.MAX_CARDS_PER_TURN) return false;
        if (gm.currentState != GameState.PLAY_PHASE) return false;
        if (!faction.hand.Contains(card)) return false;
        if (card.cardType == CardType.ATTACK && HistoricalEventManager.IsAttacksBlocked())
        {
            gm.LogMessage("Attacks blocked this turn by historical event.");
            return false;
        }
        return true;
    }

    static bool ValidateTerritoryAttack(FactionData faction, CardData card,
                                        TerritoryData source, TerritoryData target)
    {
        GameManager gm = GameManager.Instance;
        if (gm.currentTurn < 10)
        {
            gm.LogMessage("Territory attacks are locked until turn 10.");
            return false;
        }
        if (source.controlledBy != faction.factionId)
        {
            gm.LogMessage("Source territory does not belong to you.");
            return false;
        }
        if (target.controlledBy == faction.factionId)
        {
            gm.LogMessage("You cannot attack your own territory.");
            return false;
        }
        if (!TerritoryGraph.AreAdjacent(source.name, target.name))
        {
            gm.LogMessage("Territories are not adjacent.");
            return false;
        }
        if (source.troops < 10)
        {
            gm.LogMessage("Source territory needs at least 10 troops.");
            return false;
        }
        return true;
    }

    static bool ValidateExpand(FactionData faction, TerritoryData source, TerritoryData target)
    {
        GameManager gm = GameManager.Instance;
        if (gm.currentState != GameState.PLAY_PHASE) return false;
        if (source.controlledBy != faction.factionId) return false;
        if (target.controlledBy != -1) return false;
        if (!TerritoryGraph.AreAdjacent(source.name, target.name)) return false;
        if (source.troops < 10) return false;
        return true;
    }
}
