using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class ZoomController : MonoBehaviour, IScrollHandler, IDragHandler, IBeginDragHandler, IEndDragHandler
{
    Canvas canvas;
    RectTransform targetRect;
    float minZoom = 0.5f;
    float maxZoom = 3f;
    float currentZoom = 1f;
    Vector2 dragStart;
    Vector2 panStart;
    bool isDragging = false;

    public void Setup(Canvas c, RectTransform target)
    {
        canvas = c;
        targetRect = target;
    }

    public void OnScroll(PointerEventData eventData)
    {
        if (targetRect == null) return;
        float scrollDelta = eventData.scrollDelta.y * 0.1f;
        currentZoom = Mathf.Clamp(currentZoom + scrollDelta, minZoom, maxZoom);
        targetRect.localScale = Vector3.one * currentZoom;
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        if (targetRect == null) return;
        isDragging = true;
        dragStart = eventData.position;
        panStart = targetRect.anchoredPosition;
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (!isDragging || targetRect == null || canvas == null) return;
        Vector2 delta = eventData.position - dragStart;
        float scaleFactor = canvas.scaleFactor;
        targetRect.anchoredPosition = panStart + delta / scaleFactor;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        isDragging = false;
    }
}
