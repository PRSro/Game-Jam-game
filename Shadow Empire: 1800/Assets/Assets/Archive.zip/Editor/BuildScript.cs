using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;
using System.IO;

public class BuildScript
{
    public static void BuildLinux()
    {
        string outputDir = Path.Combine(Application.dataPath, "../../Build/Linux");
        Directory.CreateDirectory(outputDir);

        PlayerSettings.SetScriptingBackend(BuildTargetGroup.Standalone, ScriptingImplementation.Mono2x);

        var buildScenes = EditorBuildSettings.scenes;
        var enabled = System.Array.FindAll(buildScenes, s => s.enabled);
        string[] scenePaths = System.Array.ConvertAll(enabled, s => s.path);

        BuildPlayerOptions opts = new BuildPlayerOptions
        {
            scenes           = scenePaths,
            locationPathName = Path.Combine(outputDir, "ShadowEmpires.x86_64"),
            target           = BuildTarget.StandaloneLinux64,
            options          = BuildOptions.Development
        };

        BuildReport  report  = BuildPipeline.BuildPlayer(opts);
        BuildSummary summary = report.summary;

        if (summary.result == BuildResult.Succeeded)
            Debug.Log($"[Build] SUCCESS — {opts.locationPathName} ({summary.totalSize / 1048576} MB)");
        else
            Debug.LogError($"[Build] FAILED — {summary.totalErrors} error(s).");
    }
}
