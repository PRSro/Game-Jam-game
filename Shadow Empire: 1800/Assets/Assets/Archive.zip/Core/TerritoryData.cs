using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class TerritoryData
{
    public string name;
    public int controlledBy = -1;
    public int farmingValue;
    public int strategicValue;
    public bool isPort;
    public string historicalNote;
    public Vector2 mapPosition;
    public int troops = 0;
    public int farmingBoostTurns = 0;
    public int defensePenalty = 0;
    public int holyWarMarkedByFaction = -1;
    public int ambushAttackBonus = 0;
    public bool suppressAttackNextTurn = false;
    public bool skipReinforceNextTurn = false;
    public List<string> adjacentTerritories = new List<string>();

    public TerritoryData(string name, int farmingValue, int strategicValue, bool isPort, string historicalNote, int controlledBy = -1)
        : this(name, farmingValue, strategicValue, isPort, historicalNote, Vector2.zero, controlledBy)
    {
    }

    public TerritoryData(string name, int farmingValue, int strategicValue, bool isPort, string historicalNote, Vector2 mapPosition, int controlledBy = -1)
    {
        this.name = name;
        this.farmingValue = farmingValue;
        this.strategicValue = strategicValue;
        this.isPort = isPort;
        this.historicalNote = historicalNote;
        this.mapPosition = mapPosition;
        this.controlledBy = controlledBy;
        this.troops = controlledBy >= 0 ? 5 : 0;
        this.farmingBoostTurns = 0;
    }

    /// <summary>Adds troops to this territory, clamped to minimum 0.</summary>
    public void AddTroops(int count)
    {
        troops = Mathf.Max(0, troops + count);
    }

    /// <summary>Removes troops from this territory, clamped to minimum 0.</summary>
    public void RemoveTroops(int count)
    {
        troops = Mathf.Max(0, troops - count);
    }
}

public static class TerritoryDatabase
{
    private static List<TerritoryData> territories = null;

    public static void Reset()
    {
        territories = null;
    }

    public static List<TerritoryData> GetAllTerritories()
    {
        if (territories == null)
        {
            territories = new List<TerritoryData>();
            CreateTerritories();
        }
        return territories;
    }

    public static List<TerritoryData> GetTerritoriesOwnedBy(int factionId)
    {
        return GetAllTerritories().FindAll(t => t.controlledBy == factionId);
    }

    static void AddAdjacent(TerritoryData t, params string[] neighbors)
    {
        t.adjacentTerritories.AddRange(neighbors);
    }

    static void CreateTerritories()
    {
        territories = new List<TerritoryData>();

        TerritoryData t;

        t = new TerritoryData("Rome", 3, 5, false, "Rome: Capital of unified Italy after 1870. Heart of Papal power until the Lateran Treaty of 1929.");
        AddAdjacent(t, "Florence", "Venice", "Valletta", "Lyon");
        territories.Add(t);

        t = new TerritoryData("Venice", 2, 4, true, "Venice: Fell to Napoleon in 1797, ending the Venetian Republic. Later part of Austrian and then unified Italy.");
        AddAdjacent(t, "Rome", "Florence", "Vienna", "Lyon", "Geneva", "Dubrovnik");
        territories.Add(t);

        t = new TerritoryData("Paris", 4, 5, false, "Paris: Epicenter of revolution — 1789, 1830, 1848, 1871. Commune, empire, and republic by turns.");
        AddAdjacent(t, "London", "Brussels", "Amsterdam", "Lyon", "Geneva", "Madrid");
        territories.Add(t);

        t = new TerritoryData("London", 3, 4, true, "London: Capital of the British Empire at its zenith. Center of global finance throughout the 19th century.");
        AddAdjacent(t, "Dublin", "Amsterdam", "Paris", "Brussels");
        territories.Add(t);

        t = new TerritoryData("Constantinople", 3, 5, true, "Constantinople: Ottoman capital until 1922. Renamed Istanbul under the Turkish Republic.");
        AddAdjacent(t, "Vienna", "Dubrovnik", "Valletta", "Athens", "Bucharest");
        territories.Add(t);

        t = new TerritoryData("Vienna", 4, 4, false, "Vienna: Capital of the Austro-Hungarian Empire. Congress of Vienna 1815 reshaped Europe.");
        AddAdjacent(t, "Prague", "Venice", "Constantinople", "Krakow", "Geneva");
        territories.Add(t);

        t = new TerritoryData("Prague", 3, 3, false, "Prague: Industrial and cultural hub of the Bohemian Crown. Center of Czech nationalism in the 19th century.");
        AddAdjacent(t, "Vienna", "Krakow", "Venice");
        territories.Add(t);

        t = new TerritoryData("Madrid", 3, 3, false, "Madrid: Capital of Spain through war, revolution, and civil war. Center of the Spanish Golden Age legacy.");
        AddAdjacent(t, "Lisbon", "Paris", "Lyon", "Toledo");
        territories.Add(t);

        t = new TerritoryData("Lisbon", 2, 3, true, "Lisbon: Capital of Portugal, neutral in WWII. Survived the 1755 earthquake to remain a global port.");
        AddAdjacent(t, "Madrid", "Toledo");
        territories.Add(t);

        t = new TerritoryData("Amsterdam", 3, 4, true, "Amsterdam: Global financial capital through the 19th century. Center of diamond trade and banking.");
        AddAdjacent(t, "London", "Brussels", "Paris");
        territories.Add(t);

        t = new TerritoryData("Brussels", 2, 2, false, "Brussels: Capital of Belgium after 1830 independence. Seat of European power in the modern era.");
        AddAdjacent(t, "Paris", "Amsterdam", "London");
        territories.Add(t);

        t = new TerritoryData("Geneva", 1, 2, false, "Geneva: Refuge for revolutionaries and thinkers. Host of the International Red Cross founded 1863.");
        AddAdjacent(t, "Lyon", "Paris", "Venice", "Florence", "Vienna");
        territories.Add(t);

        t = new TerritoryData("Florence", 2, 3, false, "Florence: Briefly capital of Italy 1865–1871. Center of art and culture through the 19th century.");
        AddAdjacent(t, "Rome", "Venice", "Geneva", "Lyon");
        territories.Add(t);

        t = new TerritoryData("Toledo", 2, 3, false, "Toledo: Ancient capital of Spain, center of the Spanish Civil War's iconic siege at the Alcázar.");
        AddAdjacent(t, "Madrid", "Lisbon");
        territories.Add(t);

        t = new TerritoryData("Krakow", 3, 3, false, "Krakow: Polish cultural capital under Austrian partition. Center of 19th-century Polish nationalism.");
        AddAdjacent(t, "Vienna", "Prague", "Riga");
        territories.Add(t);

        t = new TerritoryData("Riga", 2, 2, true, "Riga: Major Baltic port of the Russian Empire. Center of Latvian national awakening in the 1800s.");
        AddAdjacent(t, "Krakow", "Warsaw", "Moscow", "Kyiv", "Stockholm");
        territories.Add(t);

        t = new TerritoryData("Dubrovnik", 1, 3, true, "Dubrovnik: The Ragusan Republic ended in 1808 under Napoleon. A Habsburg port thereafter.");
        AddAdjacent(t, "Venice", "Constantinople", "Rome", "Vienna");
        territories.Add(t);

        t = new TerritoryData("Valletta", 1, 4, true, "Valletta: Fell to Napoleon in 1798 then to Britain. Strategic Mediterranean naval base for a century.");
        AddAdjacent(t, "Rome", "Constantinople");
        territories.Add(t);

        t = new TerritoryData("Dublin", 2, 1, true, "Dublin: Heart of Irish nationalism and the 1916 Easter Rising. Capital of the Irish Free State from 1922.");
        AddAdjacent(t, "London");
        territories.Add(t);

        t = new TerritoryData("Lyon", 3, 2, false, "Lyon: Silk capital of Europe, center of the French Resistance during WWII.");
        AddAdjacent(t, "Paris", "Geneva", "Florence", "Venice", "Rome", "Madrid");
        territories.Add(t);

        t = new TerritoryData("Berlin", 3, 4, false, "Berlin: Capital of Prussia and later unified Germany. Center of the Industrial Revolution in Central Europe.");
        AddAdjacent(t, "Hamburg", "Munich", "Prague", "Warsaw", "Copenhagen");
        territories.Add(t);

        t = new TerritoryData("Munich", 2, 2, false, "Munich: Bavarian capital, center of the 1918 revolution and the Nazi movement's birthplace.");
        AddAdjacent(t, "Berlin", "Vienna", "Prague", "Venice", "Geneva");
        territories.Add(t);

        t = new TerritoryData("Hamburg", 3, 3, true, "Hamburg: Major Hanseatic port, gateway to the Atlantic for Central Europe. Devastated in WWII.");
        AddAdjacent(t, "Berlin", "Copenhagen", "Amsterdam");
        territories.Add(t);

        t = new TerritoryData("Stockholm", 2, 2, true, "Stockholm: Capital of Sweden, neutral in both world wars. Center of Scandinavian culture.");
        AddAdjacent(t, "Copenhagen", "Riga");
        territories.Add(t);

        t = new TerritoryData("Copenhagen", 2, 3, true, "Copenhagen: Danish capital, home of Tivoli Gardens. Fell to Prussia in 1864 losing Schleswig-Holstein.");
        AddAdjacent(t, "Hamburg", "Stockholm", "Berlin");
        territories.Add(t);

        t = new TerritoryData("Warsaw", 3, 3, false, "Warsaw: Polish capital, partitioned between Russia, Prussia, and Austria through the 19th century.");
        AddAdjacent(t, "Berlin", "Krakow", "Kyiv", "Moscow", "Riga");
        territories.Add(t);

        t = new TerritoryData("Moscow", 4, 5, false, "Moscow: Ancient capital of Russia, burned during Napoleon's 1812 invasion. Survived to become Soviet capital.");
        AddAdjacent(t, "Warsaw", "Kyiv", "Riga");
        territories.Add(t);

        t = new TerritoryData("Kyiv", 3, 3, false, "Kyiv: Heartland of the Russian Empire's grain wealth. Major railway hub by the late 19th century.");
        AddAdjacent(t, "Warsaw", "Moscow", "Bucharest", "Riga");
        territories.Add(t);

        t = new TerritoryData("Budapest", 3, 3, false, "Budapest: Twin city of Buda and Pest, capital of the Kingdom of Hungary within the Habsburg Empire.");
        AddAdjacent(t, "Vienna", "Belgrade", "Bucharest", "Krakow");
        territories.Add(t);

        t = new TerritoryData("Belgrade", 2, 3, false, "Belgrade: Strategic fortress city at the confluence of the Danube and Sava. Key to Balkan control.");
        AddAdjacent(t, "Budapest", "Bucharest", "Constantinople", "Dubrovnik");
        territories.Add(t);

        t = new TerritoryData("Athens", 2, 3, true, "Athens: Birthplace of democracy, became independent from the Ottoman Empire in 1830.");
        AddAdjacent(t, "Constantinople", "Valletta");
        territories.Add(t);

        t = new TerritoryData("Naples", 2, 3, true, "Naples: Capital of the Kingdom of the Two Sicilies until Garibaldi's unification of Italy in 1860.");
        AddAdjacent(t, "Rome", "Valletta", "Florence");
        territories.Add(t);

        t = new TerritoryData("Marseille", 3, 3, true, "Marseille: Major Mediterranean port, gateway to the French Empire's colonial holdings in North Africa.");
        AddAdjacent(t, "Lyon", "Madrid", "Geneva");
        territories.Add(t);

        t = new TerritoryData("Bucharest", 2, 2, false, "Bucharest: Capital of the Romanian Principalities, unified in 1859. Known as the Little Paris of the East.");
        AddAdjacent(t, "Belgrade", "Constantinople", "Kyiv", "Budapest");
        territories.Add(t);

        t = new TerritoryData("Seville", 3, 2, true, "Seville: Major port for trade with the Americas. Center of Andalusian culture.");
        AddAdjacent(t, "Madrid", "Lisbon", "Toledo");
        territories.Add(t);

        t = new TerritoryData("Algiers", 2, 2, true, "Algiers: Center of the Barbary Coast, subject to French invasion in 1830.");
        AddAdjacent(t, "Marseille", "Tunis", "Seville");
        territories.Add(t);

        t = new TerritoryData("Tunis", 2, 3, true, "Tunis: Capital of the Tunisian Regency under Ottoman suzerainty until French protectorate in 1881.");
        AddAdjacent(t, "Naples", "Valletta", "Algiers");
        territories.Add(t);

        t = new TerritoryData("Ankara", 2, 3, false, "Ankara: Ottoman provincial capital, later capital of the Turkish Republic under Atatürk.");
        AddAdjacent(t, "Constantinople", "Smyrna", "Trebizond");
        territories.Add(t);

        t = new TerritoryData("Smyrna", 2, 3, true, "Smyrna: Major Aegean port of the Ottoman Empire, center of the 1919 Greco-Turkish war.");
        AddAdjacent(t, "Constantinople", "Ankara", "Athens");
        territories.Add(t);

        t = new TerritoryData("Trebizond", 2, 2, true, "Trebizond: Black Sea port, last Greek-speaking empire fell to the Ottomans in 1461.");
        AddAdjacent(t, "Ankara", "Tbilisi");
        territories.Add(t);

        t = new TerritoryData("Tbilisi", 2, 3, false, "Tbilisi: Capital of Georgia, contested between Russian and Ottoman empires in the 19th century.");
        AddAdjacent(t, "Trebizond", "Baku", "Kyiv");
        territories.Add(t);

        t = new TerritoryData("Baku", 1, 3, true, "Baku: Major oil port on the Caspian Sea, center of the 19th-century oil boom.");
        AddAdjacent(t, "Tbilisi");
        territories.Add(t);

        t = new TerritoryData("Beirut", 2, 3, true, "Beirut: Major port of the Ottoman Empire's Levant region, center of 19th-century silk trade.");
        AddAdjacent(t, "Constantinople", "Alexandria");
        territories.Add(t);

        t = new TerritoryData("Alexandria", 2, 2, true, "Alexandria: Egypt's Mediterranean port, strategic link between Europe and the Near East.");
        AddAdjacent(t, "Beirut", "Tunis");
        territories.Add(t);

        t = new TerritoryData("Tripoli", 2, 2, true, "Tripoli: Ottoman-controlled North African port, gateway to the Sahara.");
        AddAdjacent(t, "Tunis", "Alexandria", "Valletta");
        territories.Add(t);

        ApplyMapPositions();
    }

    static void ApplyMapPositions()
    {
        var positions = new Dictionary<string, Vector2>
        {
            // ── British Isles ──────────────────────────────────────────────
            { "London",          new Vector2(0.3060f, 0.5056f) },
            { "England",         new Vector2(0.3060f, 0.5056f) },
            { "Edinburgh",       new Vector2(0.2440f, 0.3653f) },
            { "Scotland",        new Vector2(0.2440f, 0.3653f) },
            { "Dublin",          new Vector2(0.2168f, 0.4410f) },
            { "Ireland",         new Vector2(0.2168f, 0.4410f) },
            { "Wales",           new Vector2(0.2750f, 0.4900f) },

            // ── France ────────────────────────────────────────────────────
            { "Paris",           new Vector2(0.3000f, 0.5229f) },
            { "France",          new Vector2(0.3000f, 0.5229f) },
            { "Bordeaux",        new Vector2(0.3092f, 0.6764f) },
            { "Aquitaine",       new Vector2(0.3092f, 0.6764f) },
            { "Marseille",       new Vector2(0.3495f, 0.6806f) },
            { "Provence",        new Vector2(0.3495f, 0.6806f) },
            { "Toulouse",        new Vector2(0.3109f, 0.6757f) },
            { "Lyon",            new Vector2(0.3505f, 0.6250f) },
            { "Normandy",        new Vector2(0.2900f, 0.5100f) },
            { "Brittany",        new Vector2(0.2550f, 0.5450f) },

            // ── Iberia ────────────────────────────────────────────────────
            { "Madrid",          new Vector2(0.2511f, 0.7528f) },
            { "Spain",           new Vector2(0.2511f, 0.7528f) },
            { "Lisbon",          new Vector2(0.1989f, 0.8083f) },
            { "Portugal",        new Vector2(0.1989f, 0.8083f) },
            { "Sevilla",         new Vector2(0.2277f, 0.8431f) },
            { "Seville",         new Vector2(0.2277f, 0.8431f) },
            { "Barcelona",       new Vector2(0.3326f, 0.7403f) },
            { "Catalonia",       new Vector2(0.3326f, 0.7403f) },
            { "Toledo",          new Vector2(0.2511f, 0.7528f) },

            // ── Low Countries & Switzerland ───────────────────────────────
            { "Amsterdam",       new Vector2(0.3641f, 0.4847f) },
            { "Netherlands",     new Vector2(0.3641f, 0.4847f) },
            { "Brussels",        new Vector2(0.3402f, 0.4972f) },
            { "Belgium",         new Vector2(0.3402f, 0.4972f) },
            { "Geneva",          new Vector2(0.3663f, 0.6139f) },
            { "Switzerland",     new Vector2(0.3663f, 0.6139f) },

            // ── Germany ───────────────────────────────────────────────────
            { "Berlin",          new Vector2(0.4424f, 0.4465f) },
            { "Prussia",         new Vector2(0.4424f, 0.4465f) },
            { "Munich",          new Vector2(0.4299f, 0.5681f) },
            { "Bavaria",         new Vector2(0.4299f, 0.5681f) },
            { "Hamburg",         new Vector2(0.4103f, 0.4375f) },
            { "Hanover",         new Vector2(0.4103f, 0.4375f) },
            { "Dresden",         new Vector2(0.4489f, 0.4903f) },
            { "Saxony",          new Vector2(0.4489f, 0.4903f) },
            { "Westphalia",      new Vector2(0.3900f, 0.4700f) },
            { "Baden",           new Vector2(0.3950f, 0.5400f) },

            // ── Central Europe ────────────────────────────────────────────
            { "Vienna",          new Vector2(0.4864f, 0.5660f) },
            { "Austria",         new Vector2(0.4864f, 0.5660f) },
            { "Prague",          new Vector2(0.4446f, 0.4972f) },
            { "Bohemia",         new Vector2(0.4446f, 0.4972f) },
            { "Warsaw",          new Vector2(0.5321f, 0.4590f) },
            { "Poland",          new Vector2(0.5321f, 0.4590f) },
            { "Krakow",          new Vector2(0.5293f, 0.5243f) },
            { "Galicia",         new Vector2(0.5293f, 0.5243f) },
            { "Budapest",        new Vector2(0.5315f, 0.5347f) },
            { "Hungary",         new Vector2(0.5315f, 0.5347f) },

            // ── Italy ─────────────────────────────────────────────────────
            { "Rome",            new Vector2(0.4353f, 0.7229f) },
            { "Papal States",    new Vector2(0.4353f, 0.7229f) },
            { "Venice",          new Vector2(0.4679f, 0.6542f) },
            { "Venetia",         new Vector2(0.4679f, 0.6542f) },
            { "Florence",        new Vector2(0.4217f, 0.7090f) },
            { "Tuscany",         new Vector2(0.4217f, 0.7090f) },
            { "Naples",          new Vector2(0.4500f, 0.7500f) },
            { "SouthItaly",      new Vector2(0.4500f, 0.7500f) },
            { "Piedmont",        new Vector2(0.3900f, 0.6400f) },
            { "Palermo",         new Vector2(0.4533f, 0.8167f) },
            { "Sicily",          new Vector2(0.4533f, 0.8167f) },
            { "Valletta",        new Vector2(0.4668f, 0.8597f) },

            // ── Balkans ───────────────────────────────────────────────────
            { "Belgrade",        new Vector2(0.5348f, 0.6465f) },
            { "Serbia",          new Vector2(0.5348f, 0.6465f) },
            { "Dubrovnik",       new Vector2(0.4918f, 0.6799f) },
            { "Dalmatia",        new Vector2(0.4918f, 0.6799f) },
            { "Croatia",         new Vector2(0.4918f, 0.6799f) },
            { "Bucharest",       new Vector2(0.6011f, 0.6562f) },
            { "Romania",         new Vector2(0.6011f, 0.6562f) },
            { "Sofia",           new Vector2(0.5679f, 0.6972f) },
            { "Bulgaria",        new Vector2(0.5679f, 0.6972f) },
            { "Athens",          new Vector2(0.5962f, 0.8410f) },
            { "Greece",          new Vector2(0.5962f, 0.8410f) },
            { "Thessaloniki",    new Vector2(0.5636f, 0.7465f) },
            { "Bosnia",          new Vector2(0.5000f, 0.6600f) },

            // ── Ottoman Empire ────────────────────────────────────────────
            { "Constantinople",  new Vector2(0.6560f, 0.7653f) },
            { "Ottoman",         new Vector2(0.6560f, 0.7653f) },

            // ── Russia / Eastern Europe ───────────────────────────────────
            { "Moscow",          new Vector2(0.7364f, 0.3868f) },
            { "Russia",          new Vector2(0.7364f, 0.3868f) },
            { "Kyiv",            new Vector2(0.6630f, 0.5431f) },
            { "Ukraine",         new Vector2(0.6630f, 0.5431f) },
            { "Odessa",          new Vector2(0.6761f, 0.5806f) },
            { "Riga",            new Vector2(0.5815f, 0.3604f) },
            { "Baltic",          new Vector2(0.5815f, 0.3604f) },
            { "Vilnius",         new Vector2(0.5701f, 0.3917f) },
            { "Minsk",           new Vector2(0.6060f, 0.4514f) },
            { "St. Petersburg",  new Vector2(0.6300f, 0.2900f) },

            // ── Scandinavia ───────────────────────────────────────────────
            { "Stockholm",       new Vector2(0.4913f, 0.3222f) },
            { "Sweden",          new Vector2(0.4913f, 0.3222f) },
            { "Scandinavia",     new Vector2(0.4913f, 0.3222f) },
            { "Copenhagen",      new Vector2(0.4408f, 0.3861f) },
            { "Denmark",         new Vector2(0.4408f, 0.3861f) },
            { "Oslo",            new Vector2(0.4196f, 0.2771f) },
            { "Norway",          new Vector2(0.4196f, 0.2771f) },
            { "Helsinki",        new Vector2(0.5902f, 0.2778f) },
            { "Finland",         new Vector2(0.5902f, 0.2778f) },

            // ── Additional territories (estimated from GeoToUV with corrected bounds) ──
            { "Algiers",         new Vector2(0.3301f, 0.8395f) },
            { "Tunis",           new Vector2(0.4138f, 0.8376f) },
            { "Ankara",          new Vector2(0.6807f, 0.7636f) },
            { "Smyrna",          new Vector2(0.6134f, 0.7995f) },
            { "Trebizond",       new Vector2(0.7614f, 0.7381f) },
            { "Tbilisi",         new Vector2(0.8215f, 0.7217f) },
            { "Baku",            new Vector2(0.8808f, 0.7521f) },
            { "Beirut",          new Vector2(0.7118f, 0.9074f) },
            { "Alexandria",      new Vector2(0.6618f, 0.9986f) },
            { "Tripoli",         new Vector2(0.4492f, 0.9310f) },
        };

        foreach (TerritoryData territory in territories)
        {
            if (positions.TryGetValue(territory.name, out Vector2 pos))
            {
                territory.mapPosition = pos;
            }
            else
            {
                Debug.LogWarning($"[TerritoryData] No pixel position defined for '{territory.name}' — add it to ApplyMapPositions().");
                territory.mapPosition = new Vector2(0.5f, 0.5f);
            }
        }
    }
}
