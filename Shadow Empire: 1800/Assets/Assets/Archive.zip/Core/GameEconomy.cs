using System.Linq;
using UnityEngine;

public static class GameEconomy
{
    public static void ApplyTerritoryIncome(FactionData faction, System.Collections.Generic.List<TerritoryData> territories, System.Action<FactionData> onGoldChanged)
    {
        int totalFarming = 0;
        int totalInfluence = 0;
        int totalPower = 0;

        foreach (TerritoryData t in territories)
        {
            if (t.controlledBy != faction.factionId) continue;
            totalFarming += t.farmingValue;
            if (t.isPort)
                totalInfluence += 1;
            if (t.strategicValue >= 4)
                totalPower += 2;
        }

        faction.secrets = Mathf.Min(75, faction.secrets + totalFarming);
        faction.influence = Mathf.Min(100, faction.influence + totalInfluence + 1);
        faction.power = Mathf.Min(100, faction.power + totalPower);

        int ownedCount = 0;
        foreach (TerritoryData t in territories)
            if (t.controlledBy == faction.factionId) ownedCount++;
        faction.goldIncome = Mathf.Max(1, ownedCount + faction.goldIncomeBonus);
        faction.gold += faction.goldIncome;
        onGoldChanged?.Invoke(faction);
    }

    public static void ApplyPassiveEffects(FactionData faction, System.Action<string> logMessage)
    {
        int shieldFromSecrets = faction.secrets / 10;
        if (shieldFromSecrets > 0)
        {
            faction.shieldPoints += shieldFromSecrets;
            logMessage($"{faction.factionName}'s secrets generate {shieldFromSecrets} shield.");
        }

        if (faction.influence >= 100)
            logMessage($"{faction.factionName} is DOMINANT — attacks deal +2 damage!");
    }

    public static void ApplyFactionPassives(System.Collections.Generic.List<FactionData> factions, System.Collections.Generic.List<TerritoryData> territories, System.Action<string> logMessage)
    {
        foreach (FactionData faction in factions)
        {
            if (faction == null || faction.isEliminated) continue;
            switch (faction.factionId)
            {
                case 0:
                    faction.influence = Mathf.Min(100, faction.influence + 2);
                    logMessage("Illuminati Enlightened: +2 influence.");
                    break;
                case 1:
                    int templarGains = 0;
                    foreach (TerritoryData t in territories)
                    {
                        if (t.controlledBy == faction.factionId && t.troops < 8)
                        { t.troops += 1; templarGains++; }
                    }
                    logMessage($"Knights Templar Fortified: {templarGains} territories gain 1 troop.");
                    break;
                case 2:
                    int lodgeSecrets = territories.Count(t => t.controlledBy == faction.factionId);
                    faction.secrets = Mathf.Min(75, faction.secrets + lodgeSecrets);
                    logMessage($"Freemason Lodge Network: +{lodgeSecrets} secrets.");
                    break;
                case 3:
                    int carbonariGold = faction.territories.Count / 2;
                    faction.gold += carbonariGold;
                    logMessage($"Carbonari Underground: +{carbonariGold} gold from shadow networks.");
                    break;
            }
        }
    }

    public static void ApplyFarmingBoosts(FactionData faction, System.Action<string> logMessage)
    {
        foreach (TerritoryData t in faction.territories)
        {
            if (t.farmingBoostTurns > 0)
            {
                int bonus = t.farmingValue;
                t.AddTroops(bonus);
                logMessage($"{t.name} generates {bonus} bonus troops from farming boost ({t.farmingBoostTurns} turns remaining).");
                t.farmingBoostTurns--;
            }
        }
    }
}
