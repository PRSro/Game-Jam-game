using UnityEngine;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System;

public static class SaveSystem
{
    static string SaveDirectory => Application.persistentDataPath + "/saves";

    [Serializable]
    public class GameSaveData
    {
        public string saveName;
        public string timestamp;
        public int version = 1;

        public GameState currentState;
        public int currentTurn;
        public int currentSubTurn;
        public int playerFactionId;
        public int lastPlayerNeutralExpansionTurn;

        public FactionSaveData[] factions;
        public TerritorySaveData[] territories;

        public string pendingAttackSourceName;
        public string pendingAttackTargetName;
        public int pendingAttackerDiceCount;
        public int pendingAttackerTroopCount;
        public int pendingAmbushAttackBonus;
        public int pendingCardPowerBonus;

        public bool isWaitingForReinforcements;
        public bool isWaitingForEventDismiss;
        public bool isWaitingForAttackSelection;
        public bool isWaitingForFortify;

        public MarketSlotSaveData[] marketSlots;

        public string activeEventName;

        public CardSaveData[][] factionHands;
        public CardSaveData[][] factionDecks;
        public CardSaveData[][] factionDiscards;

        public PlayedCardSaveData[] resolutionQueue;

        public List<string> grandLodgeLinks;
        public int resolutionQueueVersion;
    }

    [Serializable]
    public class FactionSaveData
    {
        public int factionId;
        public int power;
        public int influence;
        public int secrets;
        public int shieldPoints;
        public int gold;
        public int goldIncome;
        public int goldIncomeBonus;
        public bool isEliminated;
        public bool isPlayerControlled;
        public float legitimacy;
        public float publicExposure;
        public int pendingReinforcements;
        public int secretCards;
        public int cardTradeCount;
        public float marketDiscount;
        public bool skipDrawNextTurn;
        public int cardsPlayedThisTurn;
        public int uniqueActionLastTurn;
        public int territoryAttackWins;
        public List<TerritoryCardSaveData> territoryCards;
    }

    [Serializable]
    public class TerritorySaveData
    {
        public string name;
        public int controlledBy;
        public int troops;
        public int farmingBoostTurns;
        public int defensePenalty;
        public int holyWarMarkedByFaction;
        public int ambushAttackBonus;
        public bool suppressAttackNextTurn;
        public bool skipReinforceNextTurn;
    }

    [Serializable]
    public class CardSaveData
    {
        public int cardId;
        public int factionId;
    }

    [Serializable]
    public class TerritoryCardSaveData
    {
        public string territoryName;
        public TerritoryCardType cardType;
    }

    [Serializable]
    public class MarketSlotSaveData
    {
        public int cardId;
        public int itemType;
        public int secretsCost;
        public int quantity;
        public int factionTarget;
        public bool purchased;
        public bool reserved;
    }

    [Serializable]
    public class PlayedCardSaveData
    {
        public int cardId;
        public int sourceFactionId;
        public int targetFactionId;
        public string sourceTerritoryName;
        public string targetTerritoryName;
        public int chosenDice;
        public int chosenTroops;
    }

    static void EnsureDirectory()
    {
        if (!Directory.Exists(SaveDirectory))
            Directory.CreateDirectory(SaveDirectory);
    }

    public static string[] GetSaveList()
    {
        EnsureDirectory();
        return Directory.GetFiles(SaveDirectory, "*.json")
            .Select(Path.GetFileNameWithoutExtension)
            .OrderByDescending(n => File.GetLastWriteTime(SaveDirectory + "/" + n + ".json"))
            .ToArray();
    }

    public static bool SaveExists(string slotName)
    {
        return File.Exists(SaveDirectory + "/" + slotName + ".json");
    }

    public static void SaveGame(string slotName)
    {
        GameManager gm = GameManager.Instance;
        if (gm == null)
        {
            Debug.LogError("[SaveSystem] Cannot save: GameManager instance is null.");
            return;
        }

        GameSaveData data = new GameSaveData();
        data.saveName = slotName;
        data.timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        data.version = 1;

        data.currentState = gm.currentState;
        data.currentTurn = gm.currentTurn;
        data.currentSubTurn = gm.currentSubTurn;
        data.playerFactionId = gm.playerFactionId;
        data.lastPlayerNeutralExpansionTurn = gm.lastPlayerNeutralExpansionTurn;

        data.pendingAttackSourceName = gm.pendingAttackSource?.name;
        data.pendingAttackTargetName = gm.pendingAttackTarget?.name;
        data.pendingAttackerDiceCount = gm.pendingAttackerDiceCount;
        data.pendingAttackerTroopCount = gm.pendingAttackerTroopCount;
        data.pendingAmbushAttackBonus = gm.pendingAmbushAttackBonus;
        data.pendingCardPowerBonus = gm.pendingCardPowerBonus;

        data.isWaitingForReinforcements = gm.IsWaitingForReinforcements;
        data.isWaitingForEventDismiss = gm.IsWaitingForEventDismiss;
        data.isWaitingForAttackSelection = gm.IsWaitingForAttackSelection;
        data.isWaitingForFortify = gm.IsWaitingForFortify;

        data.factions = gm.factions.Select(f => new FactionSaveData
        {
            factionId = f.factionId,
            power = f.power,
            influence = f.influence,
            secrets = f.secrets,
            shieldPoints = f.shieldPoints,
            gold = f.gold,
            goldIncome = f.goldIncome,
            goldIncomeBonus = f.goldIncomeBonus,
            isEliminated = f.isEliminated,
            isPlayerControlled = f.isPlayerControlled,
            legitimacy = f.legitimacy,
            publicExposure = f.publicExposure,
            pendingReinforcements = f.pendingReinforcements,
            secretCards = f.secretCards,
            cardTradeCount = f.cardTradeCount,
            marketDiscount = f.marketDiscount,
            skipDrawNextTurn = f.skipDrawNextTurn,
            cardsPlayedThisTurn = f.cardsPlayedThisTurn,
            uniqueActionLastTurn = f.uniqueActionLastTurn,
            territoryAttackWins = f.territoryAttackWins,
            territoryCards = f.territoryCards.Select(tc => new TerritoryCardSaveData { territoryName = tc.territoryName, cardType = tc.cardType }).ToList()
        }).ToArray();

        data.territories = gm.territories.Select(t => new TerritorySaveData
        {
            name = t.name,
            controlledBy = t.controlledBy,
            troops = t.troops,
            farmingBoostTurns = t.farmingBoostTurns,
            defensePenalty = t.defensePenalty,
            holyWarMarkedByFaction = t.holyWarMarkedByFaction,
            ambushAttackBonus = t.ambushAttackBonus,
            suppressAttackNextTurn = t.suppressAttackNextTurn,
            skipReinforceNextTurn = t.skipReinforceNextTurn
        }).ToArray();

        if (gm.currentMarket != null)
        {
            data.marketSlots = gm.currentMarket.Select(s => s == null ? null : new MarketSlotSaveData
            {
                cardId = s.card?.cardId ?? -1,
                itemType = (int)s.itemType,
                secretsCost = s.secretsCost,
                quantity = s.quantity,
                factionTarget = s.factionTarget,
                purchased = s.purchased,
                reserved = s.reserved
            }).ToArray();
        }

        data.activeEventName = HistoricalEventManager.ActiveEvent?.eventName;

        data.factionHands = gm.factions.Select(f => f.hand.Select(c => new CardSaveData { cardId = c.cardId, factionId = c.factionId }).ToArray()).ToArray();
        data.factionDecks = gm.factions.Select(f => f.deck.Select(c => new CardSaveData { cardId = c.cardId, factionId = c.factionId }).ToArray()).ToArray();
        data.factionDiscards = gm.factions.Select(f => f.discardPile.Select(c => new CardSaveData { cardId = c.cardId, factionId = c.factionId }).ToArray()).ToArray();

        var queueList = new List<PlayedCardSaveData>();
        foreach (var pc in GetResolutionQueue(gm))
            queueList.Add(new PlayedCardSaveData
            {
                cardId = pc.card?.cardId ?? -1,
                sourceFactionId = pc.source?.factionId ?? -1,
                targetFactionId = pc.target?.factionId ?? -1,
                sourceTerritoryName = pc.sourceTerritory?.name,
                targetTerritoryName = pc.targetTerritory?.name,
                chosenDice = pc.chosenDice,
                chosenTroops = pc.chosenTroops
            });
        data.resolutionQueue = queueList.ToArray();

        data.grandLodgeLinks = TurnActionController.GetAllLinks();
        data.resolutionQueueVersion = 0;

        EnsureDirectory();
        string json = JsonUtility.ToJson(data, true);
        File.WriteAllText(SaveDirectory + "/" + slotName + ".json", json);
        Debug.Log($"[SaveSystem] Game saved to '{slotName}'.");
    }

    static List<PlayedCard> GetResolutionQueue(GameManager gm)
    {
        return gm.GetResolutionQueueCopy();
    }

    public static bool LoadGame(string slotName)
    {
        string path = SaveDirectory + "/" + slotName + ".json";
        if (!File.Exists(path))
        {
            Debug.LogError($"[SaveSystem] Save file not found: {path}");
            return false;
        }

        string json = File.ReadAllText(path);
        GameSaveData data = JsonUtility.FromJson<GameSaveData>(json);
        if (data == null)
        {
            Debug.LogError("[SaveSystem] Failed to deserialize save data.");
            return false;
        }

        GameManager gm = GameManager.Instance;
        if (gm == null)
        {
            Debug.LogError("[SaveSystem] GameManager instance is null during load.");
            return false;
        }

        CardDatabase.Reset();
        CardDatabase.GetAllCards();

        gm.StopAllCoroutines();
        if (AIController.Instance != null)
            AIController.Instance.StopAllCoroutines();

        ProvinceGraph.ClearCache();
        TerritoryGraphRenderer.ClearPositions();
        TurnActionController.ResetUniqueActionState();
        GameUIManager.ResetStaticState();

        gm.currentState = data.currentState;
        gm.currentTurn = data.currentTurn;
        gm.currentSubTurn = data.currentSubTurn;
        gm.playerFactionId = data.playerFactionId;
        gm.lastPlayerNeutralExpansionTurn = data.lastPlayerNeutralExpansionTurn;

        gm.pendingAttackSource = ResolveTerritory(gm.territories, data.pendingAttackSourceName);
        gm.pendingAttackTarget = ResolveTerritory(gm.territories, data.pendingAttackTargetName);
        gm.pendingAttackerDiceCount = data.pendingAttackerDiceCount;
        gm.pendingAttackerTroopCount = data.pendingAttackerTroopCount;
        gm.pendingAmbushAttackBonus = data.pendingAmbushAttackBonus;
        gm.pendingCardPowerBonus = data.pendingCardPowerBonus;

        gm.IsWaitingForReinforcements = data.isWaitingForReinforcements;
        gm.IsWaitingForEventDismiss = data.isWaitingForEventDismiss;
        gm.IsWaitingForAttackSelection = data.isWaitingForAttackSelection;
        gm.IsWaitingForFortify = data.isWaitingForFortify;

        gm.factions = FactionDatabase.GetAllFactions();
        for (int i = 0; i < gm.factions.Count && i < data.factions.Length; i++)
            ApplyFactionData(gm.factions[i], data.factions[i], data, i);

        gm.territories.Clear();
        foreach (var tsd in data.territories)
        {
            TerritoryData t = TerritoryDatabase.GetAllTerritories().Find(x => x.name == tsd.name);
            if (t != null)
            {
                t.controlledBy = tsd.controlledBy;
                t.troops = tsd.troops;
                t.farmingBoostTurns = tsd.farmingBoostTurns;
                t.defensePenalty = tsd.defensePenalty;
                t.holyWarMarkedByFaction = tsd.holyWarMarkedByFaction;
                t.ambushAttackBonus = tsd.ambushAttackBonus;
                t.suppressAttackNextTurn = tsd.suppressAttackNextTurn;
                t.skipReinforceNextTurn = tsd.skipReinforceNextTurn;
                gm.territories.Add(t);
            }
        }

        foreach (FactionData f in gm.factions)
            f.territories = gm.territories.Where(t => t.controlledBy == f.factionId).ToList();

        MapSystemController.Instance?.SyncProvincesFromTerritories();

        if (data.marketSlots != null)
        {
            gm.currentMarket = data.marketSlots.Select(s => s == null ? null : new BlackMarketSystem.MarketSlot
            {
                card = s.cardId >= 0 ? CardDatabase.GetCardById(s.cardId) : null,
                itemType = (BlackMarketSystem.MarketItemType)s.itemType,
                secretsCost = s.secretsCost,
                quantity = s.quantity,
                factionTarget = s.factionTarget,
                purchased = s.purchased,
                reserved = s.reserved
            }).ToArray();
        }

        HistoricalEventManager.Reset();
        if (!string.IsNullOrEmpty(data.activeEventName))
            HistoricalEventManager.RebuildActiveEvent(data.activeEventName);

        TurnActionController.LoadLinks(data.grandLodgeLinks);

        var queue = new System.Collections.Generic.List<PlayedCard>();
        if (data.resolutionQueue != null)
        {
            foreach (var psd in data.resolutionQueue)
            {
                FactionData src = psd.sourceFactionId >= 0 ? gm.factions.Find(f => f.factionId == psd.sourceFactionId) : null;
                FactionData tgt = psd.targetFactionId >= 0 ? gm.factions.Find(f => f.factionId == psd.targetFactionId) : null;
                TerritoryData srcT = ResolveTerritory(gm.territories, psd.sourceTerritoryName);
                TerritoryData tgtT = ResolveTerritory(gm.territories, psd.targetTerritoryName);
                CardData card = psd.cardId >= 0 ? CardDatabase.GetCardById(psd.cardId) : null;
                queue.Add(new PlayedCard(card, src, tgt, srcT, tgtT, psd.chosenDice, psd.chosenTroops));
            }
        }
        gm.ClearAndSetResolutionQueue(queue);

        if (GameUIManager.Instance != null)
        {
            GameUIManager.Instance.InitializeUI(gm.factions);
            GameUIManager.Instance.UpdatePlayerHand(gm.factions[gm.playerFactionId].hand);
            GameUIManager.Instance.OnGameStateChanged(data.currentState);
        }

        gm.OnYearChanged?.Invoke(gm.CurrentYear);
        gm.OnTurnChanged?.Invoke(gm.currentTurn);

        gm.LogMessage($"Game loaded from '{slotName}' (Turn {data.currentTurn}).");
        Debug.Log($"[SaveSystem] Game loaded from '{slotName}'.");
        return true;
    }

    static void ApplyFactionData(FactionData faction, FactionSaveData sd, GameSaveData data, int index)
    {
        faction.power = sd.power;
        faction.influence = sd.influence;
        faction.secrets = sd.secrets;
        faction.shieldPoints = sd.shieldPoints;
        faction.gold = sd.gold;
        faction.goldIncome = sd.goldIncome;
        faction.goldIncomeBonus = sd.goldIncomeBonus;
        faction.isEliminated = sd.isEliminated;
        faction.isPlayerControlled = sd.isPlayerControlled;
        faction.legitimacy = sd.legitimacy;
        faction.publicExposure = sd.publicExposure;
        faction.pendingReinforcements = sd.pendingReinforcements;
        faction.secretCards = sd.secretCards;
        faction.cardTradeCount = sd.cardTradeCount;
        faction.marketDiscount = sd.marketDiscount;
        faction.skipDrawNextTurn = sd.skipDrawNextTurn;
        faction.cardsPlayedThisTurn = sd.cardsPlayedThisTurn;
        faction.uniqueActionLastTurn = sd.uniqueActionLastTurn;
        faction.territoryAttackWins = sd.territoryAttackWins;

        faction.territoryCards.Clear();
        if (sd.territoryCards != null)
            foreach (var tc in sd.territoryCards)
                faction.territoryCards.Add(new TerritoryCard(tc.territoryName, tc.cardType));

        if (data.factionHands != null && index < data.factionHands.Length && data.factionHands[index] != null)
        {
            faction.hand.Clear();
            foreach (var cd in data.factionHands[index])
            {
                CardData card = CardDatabase.GetCardById(cd.cardId);
                if (card != null) faction.hand.Add(card);
            }
        }

        if (data.factionDecks != null && index < data.factionDecks.Length && data.factionDecks[index] != null)
        {
            faction.deck.Clear();
            foreach (var cd in data.factionDecks[index])
            {
                CardData card = CardDatabase.GetCardById(cd.cardId);
                if (card != null) faction.deck.Add(card);
            }
        }

        if (data.factionDiscards != null && index < data.factionDiscards.Length && data.factionDiscards[index] != null)
        {
            faction.discardPile.Clear();
            foreach (var cd in data.factionDiscards[index])
            {
                CardData card = CardDatabase.GetCardById(cd.cardId);
                if (card != null) faction.discardPile.Add(card);
            }
        }
    }

    static TerritoryData ResolveTerritory(List<TerritoryData> territories, string name)
    {
        if (string.IsNullOrEmpty(name)) return null;
        return territories.Find(t => t.name == name);
    }

    public static void DeleteSave(string slotName)
    {
        string path = SaveDirectory + "/" + slotName + ".json";
        if (File.Exists(path))
        {
            File.Delete(path);
            Debug.Log($"[SaveSystem] Deleted save '{slotName}'.");
        }
    }
}
