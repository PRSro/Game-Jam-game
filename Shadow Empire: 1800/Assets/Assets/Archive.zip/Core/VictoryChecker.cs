using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public static class VictoryChecker
{
    public const int EARLIEST_NON_TERRITORY_VICTORY_TURN = 20;

    public struct VictoryResult
    {
        public bool hasWinner;
        public FactionData winner;
        public string message;
    }

    public static VictoryResult CheckVictory(List<FactionData> factions, List<TerritoryData> territories, int currentTurn)
    {
        if (factions == null || territories == null)
            return default;

        SyncFactionTerritoryLists(factions, territories);

        if (currentTurn < 5) return default;

        // Territorial victory: control all territories
        foreach (FactionData faction in factions)
        {
            if (faction.isEliminated) continue;
            int total = territories.Count(t => t.controlledBy == faction.factionId);
            if (total >= territories.Count)
            {
                return new VictoryResult
                {
                    hasWinner = true,
                    winner = faction,
                    message = $"WORLD DOMINATION: {faction.factionName} controls all of Europe!"
                };
            }
        }

        // Non-territorial victories
        List<FactionData> dominance = new List<FactionData>();
        List<FactionData> influence = new List<FactionData>();
        List<FactionData> shadowCoup = new List<FactionData>();
        List<FactionData> conspiracy = new List<FactionData>();

        foreach (FactionData faction in factions)
        {
            if (faction.isEliminated) continue;

            if (currentTurn >= EARLIEST_NON_TERRITORY_VICTORY_TURN &&
                faction.influence >= 100 && faction.power >= 90 && faction.territories.Count >= 8)
                dominance.Add(faction);

            if (faction.influence >= 100 && currentTurn >= 60 && faction.territories.Count >= 6)
                influence.Add(faction);

            if (faction.secrets >= 60 && faction.territories.Count >= 5 && currentTurn >= 30)
                shadowCoup.Add(faction);

            if (faction.secrets >= 75)
            {
                int elimCount = factions.Count(f => f.isEliminated);
                if (elimCount >= 2)
                    conspiracy.Add(faction);
            }
        }

        var candidates = new (List<FactionData> list, string message)[]
        {
            (dominance, "DOMINANCE VICTORY: {0} controls the shadows of Europe!"),
            (influence, "INFLUENCE VICTORY: {0}'s influence is absolute!"),
            (shadowCoup, "SHADOW COUP: {0} executes a devastating secret coup!"),
            (conspiracy, "CONSPIRACY VICTORY: {0}'s secrets are absolute!")
        };

        foreach (var (list, msg) in candidates)
        {
            if (list.Count <= 0) continue;
            FactionData winner = list.OrderByDescending(f => f.influence + f.territories.Count + f.power).First();
            return new VictoryResult
            {
                hasWinner = true,
                winner = winner,
                message = string.Format(msg, winner.factionName)
            };
        }

        // Last faction standing
        int alive = factions.Count(f => !f.isEliminated);
        if (alive <= 1)
        {
            FactionData survivor = factions.FirstOrDefault(f => !f.isEliminated);
            if (survivor != null)
            {
                return new VictoryResult
                {
                    hasWinner = true,
                    winner = survivor,
                    message = survivor.isPlayerControlled
                        ? "VICTORY! Your faction is the last one standing!"
                        : "DEFEAT! Your faction has been eliminated."
                };
            }
        }

        return default;
    }

    public struct EliminationResult
    {
        public List<FactionData> eliminated;
        public List<string> messages;
    }

    public static EliminationResult CheckEliminations(List<FactionData> factions, List<TerritoryData> territories, int currentTurn)
    {
        SyncFactionTerritoryLists(factions, territories);

        var eliminated = new List<FactionData>();
        var messages = new List<string>();

        foreach (FactionData faction in factions)
        {
            if (faction.isEliminated) continue;

            bool noTerritories = faction.territories.Count == 0;
            bool powerDepleted = faction.power <= 0 && currentTurn >= 15;
            bool legitimacyCollapsed = faction.legitimacy <= 0f;

            if (noTerritories || powerDepleted || legitimacyCollapsed)
            {
                faction.isEliminated = true;
                faction.power = 0;
                eliminated.Add(faction);

                string reason;
                if (noTerritories)
                    reason = $"{faction.factionName} has lost all territories and is ELIMINATED!";
                else if (powerDepleted)
                    reason = $"{faction.factionName}'s power has collapsed — ELIMINATED!";
                else if (legitimacyCollapsed)
                    reason = $"{faction.factionName}'s legitimacy has shattered — ELIMINATED!";
                else
                    reason = $"{faction.factionName} has been fully exposed — ELIMINATED!";
                messages.Add(reason);
            }
        }

        return new EliminationResult { eliminated = eliminated, messages = messages };
    }

    public static void SyncFactionTerritoryLists(List<FactionData> factions, List<TerritoryData> territories)
    {
        if (factions == null || territories == null) return;
        foreach (FactionData faction in factions)
        {
            if (faction == null) continue;
            faction.territories = territories.Where(t => t.controlledBy == faction.factionId).ToList();
        }
    }
}
