using System.Text;
using UnityEngine;

/// <summary>Session debug logger for hand/card play tracing (debug mode).</summary>
public static class AgentHandDebugLog
{
    const string SessionId = "c71e3b";
    static string LogPath => System.IO.Path.Combine(Application.dataPath, ".cursor", "debug-c71e3b.log");

    public static void Write(string hypothesisId, string location, string message, object data)
    {
        string json = MiniJson(data);
        string line = $"{{\"sessionId\":\"{SessionId}\",\"hypothesisId\":\"{hypothesisId}\",\"location\":\"{location}\",\"message\":\"{message}\",\"data\":{json},\"timestamp\":{System.DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}}}";
        Debug.Log($"[AgentHand] {message} | {location} | {json}");
        try
        {
            string dir = System.IO.Path.Combine(Application.dataPath, ".cursor");
            System.IO.Directory.CreateDirectory(dir);
            System.IO.File.AppendAllText(LogPath, line + "\n");
        }
        catch { }
    }

    static string MiniJson(object data)
    {
        if (data == null) return "null";
        var sb = new StringBuilder();
        sb.Append('{');
        bool first = true;
        foreach (var prop in data.GetType().GetFields())
        {
            if (!first) sb.Append(',');
            first = false;
            sb.Append('"').Append(prop.Name).Append("\":");
            AppendValue(sb, prop.GetValue(data));
        }
        foreach (var prop in data.GetType().GetProperties())
        {
            if (!prop.CanRead || prop.GetIndexParameters().Length > 0) continue;
            if (!first) sb.Append(',');
            first = false;
            sb.Append('"').Append(prop.Name).Append("\":");
            AppendValue(sb, prop.GetValue(data));
        }
        sb.Append('}');
        return sb.ToString();
    }

    static void AppendValue(StringBuilder sb, object value)
    {
        if (value == null) { sb.Append("null"); return; }
        if (value is bool b) { sb.Append(b ? "true" : "false"); return; }
        if (value is int || value is long || value is float || value is double) { sb.Append(value); return; }
        string s = value.ToString().Replace("\\", "\\\\").Replace("\"", "\\\"");
        sb.Append('"').Append(s).Append('"');
    }
}
