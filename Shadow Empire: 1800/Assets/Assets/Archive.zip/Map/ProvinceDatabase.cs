using System.Collections.Generic;
using UnityEngine;

public static class ProvinceDatabase
{
    private static List<ProvinceData> provinces = null;

    /// <summary>Returns all provinces in the database.</summary>
    public static List<ProvinceData> GetAllProvinces()
    {
        if (provinces == null) BuildProvinces();
        return provinces;
    }

    /// <summary>Finds a province by name.</summary>
    public static ProvinceData GetProvince(string name)
    {
        if (provinces == null) BuildProvinces();
        return provinces.Find(p => p.provinceName == name);
    }

    /// <summary>Returns all provinces controlled by the given faction.</summary>
    public static List<ProvinceData> GetProvincesOwnedBy(int factionId)
    {
        if (provinces == null) BuildProvinces();
        return provinces.FindAll(p => p.controllingFactionId == factionId);
    }

    /// <summary>Returns all provinces in a given historical region.</summary>
    public static List<ProvinceData> GetProvincesInRegion(string region)
    {
        if (provinces == null) BuildProvinces();
        return provinces.FindAll(p => p.historicalRegion == region);
    }

    /// <summary>Nudges all provinces that landed in water onto the nearest land pixel.</summary>
    public static void NudgeAllToLand()
    {
        if (provinces == null) BuildProvinces();
        if (MapLayerController.Instance == null) return;
        foreach (ProvinceData p in provinces)
            p.mapPosition = MapProjection.NudgeToLand(p.mapPosition);
    }

    static void BuildProvinces()
    {
        provinces = new List<ProvinceData>();

        // ── BRITISH ISLES ──────────────────────────────────────────────────────
        AddProvince("England",        "British Isles",   new Vector2(0.3060f, 0.5056f));
        AddProvince("Scotland",       "British Isles",   new Vector2(0.2440f, 0.3653f));
        AddProvince("Ireland",        "British Isles",   new Vector2(0.2168f, 0.4410f));
        AddProvince("Wales",          "British Isles",   new Vector2(0.2750f, 0.4900f));

        // ── FRANCE ─────────────────────────────────────────────────────────────
        AddProvince("France",         "France",          new Vector2(0.3000f, 0.5229f));
        AddProvince("Brittany",       "France",          new Vector2(0.2550f, 0.5450f));
        AddProvince("Normandy",       "France",          new Vector2(0.2900f, 0.5100f));
        AddProvince("Aquitaine",      "France",          new Vector2(0.3092f, 0.6764f));
        AddProvince("Provence",       "France",          new Vector2(0.3495f, 0.6806f));

        // ── IBERIA ─────────────────────────────────────────────────────────────
        AddProvince("Spain",          "Iberia",          new Vector2(0.2511f, 0.7528f));
        AddProvince("Portugal",       "Iberia",          new Vector2(0.1989f, 0.8083f));
        AddProvince("Catalonia",      "Iberia",          new Vector2(0.3326f, 0.7403f));
        AddProvince("Andalusia",      "Iberia",          new Vector2(0.2277f, 0.8431f));

        // ── LOW COUNTRIES ──────────────────────────────────────────────────────
        AddProvince("Netherlands",    "Low Countries",   new Vector2(0.3641f, 0.4847f));
        AddProvince("Belgium",        "Low Countries",   new Vector2(0.3402f, 0.4972f));

        // ── GERMAN STATES ──────────────────────────────────────────────────────
        AddProvince("Prussia",        "German States",   new Vector2(0.4424f, 0.4465f));
        AddProvince("Bavaria",        "German States",   new Vector2(0.4299f, 0.5681f));
        AddProvince("Saxony",         "German States",   new Vector2(0.4489f, 0.4903f));
        AddProvince("Hanover",        "German States",   new Vector2(0.4103f, 0.4375f));
        AddProvince("Baden",          "German States",   new Vector2(0.3950f, 0.5400f));
        AddProvince("Westphalia",     "German States",   new Vector2(0.3900f, 0.4700f));
        AddProvince("Rhineland",      "German States",   MapProjection.GeoToUV(50.94f,   6.96f)); // Cologne

        // ── ITALIAN STATES ─────────────────────────────────────────────────────
        AddProvince("Piedmont",       "Italian States",  new Vector2(0.3900f, 0.6400f));
        AddProvince("Lombardy",       "Italian States",  MapProjection.GeoToUV(45.46f,   9.19f)); // Milan
        AddProvince("Venice",         "Italian States",  new Vector2(0.4679f, 0.6542f));
        AddProvince("Tuscany",        "Italian States",  new Vector2(0.4217f, 0.7090f));
        AddProvince("Papal States",   "Italian States",  new Vector2(0.4353f, 0.7229f));
        AddProvince("Naples",         "Italian States",  new Vector2(0.4500f, 0.7500f));
        AddProvince("Sicily",         "Italian States",  new Vector2(0.4533f, 0.8167f));

        // ── SWITZERLAND & ALPINE ───────────────────────────────────────────────
        AddProvince("Switzerland",    "Switzerland",     new Vector2(0.3663f, 0.6139f));

        // ── AUSTRIAN EMPIRE ────────────────────────────────────────────────────
        AddProvince("Austria",        "Austrian Empire", new Vector2(0.4864f, 0.5660f));
        AddProvince("Bohemia",        "Austrian Empire", new Vector2(0.4446f, 0.4972f));
        AddProvince("Hungary",        "Austrian Empire", new Vector2(0.5315f, 0.5347f));
        AddProvince("Croatia",        "Austrian Empire", new Vector2(0.4918f, 0.6799f));
        AddProvince("Galicia",        "Austrian Empire", new Vector2(0.5293f, 0.5243f));

        // ── POLAND ─────────────────────────────────────────────────────────────
        AddProvince("Poland",         "Poland",          new Vector2(0.5321f, 0.4590f));
        AddProvince("Lithuania",      "Poland",          MapProjection.GeoToUV(54.69f,  25.28f)); // Vilnius

        // ── SCANDINAVIA ────────────────────────────────────────────────────────
        AddProvince("Sweden",         "Scandinavia",     new Vector2(0.4913f, 0.3222f));
        AddProvince("Norway",         "Scandinavia",     new Vector2(0.4196f, 0.2771f));
        AddProvince("Denmark",        "Scandinavia",     new Vector2(0.4408f, 0.3861f));
        AddProvince("Finland",        "Scandinavia",     new Vector2(0.5902f, 0.2778f));
        AddProvince("Helsinki",       "Russia",          new Vector2(0.5902f, 0.2778f));

        // ── RUSSIA ─────────────────────────────────────────────────────────────
        AddProvince("Russia",         "Russia",          new Vector2(0.7364f, 0.3868f));
        AddProvince("St. Petersburg", "Russia",          new Vector2(0.6300f, 0.2900f));
        AddProvince("Baltic",         "Russia",          new Vector2(0.5815f, 0.3604f));
        AddProvince("Ukraine",        "Russia",          new Vector2(0.6630f, 0.5431f));
        AddProvince("Crimea",         "Russia",          MapProjection.GeoToUV(45.03f,  33.99f)); // Simferopol — center of peninsula
        AddProvince("Volga",          "Russia",          MapProjection.GeoToUV(53.20f,  50.15f)); // Samara — far east edge
        AddProvince("Don",            "Russia",          MapProjection.GeoToUV(47.23f,  39.72f)); // Rostov-on-Don

        // ── BALKANS ────────────────────────────────────────────────────────────
        AddProvince("Ottoman Empire", "Balkans",         new Vector2(0.6560f, 0.7653f));
        AddProvince("Serbia",         "Balkans",         new Vector2(0.5348f, 0.6465f));
        AddProvince("Greece",         "Balkans",         new Vector2(0.5962f, 0.8410f));
        AddProvince("Wallachia",      "Balkans",         MapProjection.GeoToUV(44.43f,  26.10f)); // Bucharest
        AddProvince("Moldavia",       "Balkans",         MapProjection.GeoToUV(47.00f,  28.83f)); // Chisinau
        AddProvince("Bosnia",         "Balkans",         new Vector2(0.5000f, 0.6600f));
        AddProvince("Bulgaria",       "Balkans",         new Vector2(0.5679f, 0.6972f));
        AddProvince("Albania",        "Balkans",         MapProjection.GeoToUV(41.33f,  19.83f)); // Tirana

        // ── OTTOMAN EMPIRE ─────────────────────────────────────────────────────
        AddProvince("Anatolia",       "Ottoman Empire",  MapProjection.GeoToUV(39.93f,  32.86f)); // Ankara
        AddProvince("Ionia",          "Ottoman Empire",  MapProjection.GeoToUV(38.42f,  27.14f)); // Smyrna — inland area
        AddProvince("Pontus",         "Ottoman Empire",  MapProjection.GeoToUV(41.29f,  36.33f)); // Samsun — on coast but only option
        AddProvince("Syria",          "Near East",       MapProjection.GeoToUV(33.51f,  36.29f)); // Damascus
        AddProvince("Levant",         "Near East",       MapProjection.GeoToUV(33.89f,  35.50f)); // Beirut — coastal but unavoidable
        AddProvince("Mesopotamia",    "Near East",       MapProjection.GeoToUV(33.34f,  44.40f)); // Baghdad

        // ── CAUCASUS ───────────────────────────────────────────────────────────
        AddProvince("Georgia",        "Caucasus",        MapProjection.GeoToUV(41.69f,  44.83f)); // Tbilisi
        AddProvince("Azerbaijan",     "Caucasus",        MapProjection.GeoToUV(40.41f,  49.87f)); // Baku — eastern edge of map
        AddProvince("Armenia",        "Caucasus",        MapProjection.GeoToUV(40.18f,  44.50f)); // Yerevan

        // ── NORTH AFRICA ───────────────────────────────────────────────────────
        AddProvince("Egypt",          "North Africa",    MapProjection.GeoToUV(30.06f,  31.25f)); // Cairo
        AddProvince("Maghreb",        "North Africa",    MapProjection.GeoToUV(34.85f,   1.65f)); // Tlemcen — inland Algeria
        AddProvince("Tunisia",        "North Africa",    MapProjection.GeoToUV(36.00f,   9.37f)); // Kairouan — inland
        AddProvince("Libya",          "North Africa",    MapProjection.GeoToUV(32.90f,  13.18f)); // Tripoli — coastal but unavoidable
        AddProvince("Morocco",        "North Africa",    MapProjection.GeoToUV(33.99f,  -5.00f)); // Fez — inland
    }

    static void AddProvince(string name, string region, Vector2 position)
    {
        provinces.Add(new ProvinceData(name, region, position, false));
    }
}
