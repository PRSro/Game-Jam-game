using UnityEngine;
using UnityEngine.UI;

public partial class GameUIManager : MonoBehaviour
{
    void AddStatBar(Transform parent, string label, Color fillColor,
                    float yMin, float yMax, out Image fillBarOut)
    {
        Text lbl = MakeUIText(parent, label + "Lbl", 7, FontStyle.Bold, Parchment,
                              new Vector2(0.03f, yMin), new Vector2(0.18f, yMax)).GetComponent<Text>();
        lbl.text = label;
        lbl.alignment = TextAnchor.MiddleLeft;

        GameObject track = MakeChild(parent, label + "Track",
                                      new Vector2(0.20f, yMin + 0.01f), new Vector2(0.97f, yMax - 0.01f), Vector2.zero);
        track.AddComponent<Image>().color = new Color(0.06f, 0.03f, 0.01f, 1f);

        GameObject fill = new GameObject(label + "Fill", typeof(RectTransform));
        fill.transform.SetParent(track.transform, false);
        fillBarOut = fill.AddComponent<Image>();
        fillBarOut.color = fillColor;
        RectTransform fr = fill.GetComponent<RectTransform>();
        fr.anchorMin = Vector2.zero;
        fr.anchorMax = new Vector2(0.5f, 1f);
        fr.sizeDelta = Vector2.zero;
        fr.anchoredPosition = Vector2.zero;
    }

    GameObject MakeUIText(Transform parent, string name, int size, FontStyle style,
                          Color color, Vector2 aMin, Vector2 aMax, TextAnchor align = TextAnchor.MiddleCenter)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        Text t = go.AddComponent<Text>();
        t.font = GetFont();
        t.fontSize = size;
        t.resizeTextForBestFit = false;
        t.fontStyle = style;
        t.alignment = align;
        t.color = color;
        t.raycastTarget = false;
        RectTransform r = go.GetComponent<RectTransform>();
        r.anchorMin = aMin;
        r.anchorMax = aMax;
        r.sizeDelta = Vector2.zero;
        r.anchoredPosition = Vector2.zero;
        return go;
    }

    GameObject MakeChild(Transform parent, string name, Vector2 aMin, Vector2 aMax, Vector2 sizeDelta)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        RectTransform r = go.GetComponent<RectTransform>();
        r.anchorMin = aMin;
        r.anchorMax = aMax;
        r.sizeDelta = sizeDelta;
        r.anchoredPosition = Vector2.zero;
        return go;
    }

    GameObject MakeHRule(Transform parent, Vector2 aMin, Vector2 aMax, Color color)
    {
        GameObject go = MakeChild(parent, "HRule", aMin, aMax, Vector2.zero);
        go.AddComponent<Image>().color = color;
        return go;
    }

    void FullStretch(RectTransform r, float w = 0, float h = 0)
    {
        r.anchorMin = Vector2.zero;
        r.anchorMax = Vector2.one;
        r.sizeDelta = new Vector2(w, h);
        r.anchoredPosition = Vector2.zero;
    }

    void Anchor(RectTransform r, float x0, float y0, float x1, float y1)
    {
        r.anchorMin = new Vector2(x0, y0);
        r.anchorMax = new Vector2(x1, y1);
        r.sizeDelta = Vector2.zero;
        r.anchoredPosition = Vector2.zero;
    }

    Button MakeButton(Transform parent, string name, Vector2 anchoredPos, Vector2 size, string label,
                      Color normal, Color highlighted)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        Image img = go.AddComponent<Image>();
        img.color = normal;
        Button btn = go.AddComponent<Button>();
        btn.targetGraphic = img;
        Navigation nav = new Navigation();
        nav.mode = Navigation.Mode.None;
        btn.navigation = nav;
        ColorBlock cb = btn.colors;
        cb.normalColor = normal;
        cb.highlightedColor = highlighted;
        btn.colors = cb;
        RectTransform r = go.GetComponent<RectTransform>();
        r.anchorMin = r.anchorMax = new Vector2(0.5f, 0.5f);
        r.sizeDelta = size;
        r.anchoredPosition = anchoredPos;
        MakeUIText(go.transform, "Label", 20, FontStyle.Bold,
                   Parchment, Vector2.zero, Vector2.one).GetComponent<Text>().text = label;
        return btn;
    }

    static Font GetFont() => UIFont.Get();

    static Sprite GetPhaseCircleSprite()
    {
        if (phaseCircleSprite == null)
        {
            phaseCircleSprite = RoundedRectGenerator.Generate(64, 64, 32,
                Color.clear,
                Color.white,
                4);
        }
        return phaseCircleSprite;
    }
}
