using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public partial class GameUIManager : MonoBehaviour
{
    void BuildCombatPopup(Transform ct)
    {
        combatPopup = new GameObject("CombatPopup", typeof(RectTransform));
        combatPopup.transform.SetParent(ct, false);
        Image cpBg = combatPopup.AddComponent<Image>();
        cpBg.color = new Color(0, 0, 0, 0.88f);
        cpBg.raycastTarget = true;
        FullStretch(combatPopup.GetComponent<RectTransform>());
        combatPopup.SetActive(false);

        GameObject cpBorder = new GameObject("Border", typeof(RectTransform));
        cpBorder.transform.SetParent(combatPopup.transform, false);
        cpBorder.AddComponent<Image>().color = Rust;
        RectTransform cbR = cpBorder.GetComponent<RectTransform>();
        cbR.anchorMin = new Vector2(0.28f, 0.22f);
        cbR.anchorMax = new Vector2(0.72f, 0.72f);
        cbR.sizeDelta = Vector2.zero;

        GameObject cpInner = new GameObject("Inner", typeof(RectTransform));
        cpInner.transform.SetParent(combatPopup.transform, false);
        cpInner.AddComponent<Image>().color = Darkest;
        RectTransform ciR = cpInner.GetComponent<RectTransform>();
        ciR.anchorMin = new Vector2(0.29f, 0.23f);
        ciR.anchorMax = new Vector2(0.71f, 0.71f);
        ciR.sizeDelta = Vector2.zero;

        combatPopupTitle = MakeUIText(combatPopup.transform, "Title", 24, FontStyle.Bold,
                                      Rust, new Vector2(0.30f, 0.62f), new Vector2(0.70f, 0.70f)).GetComponent<Text>();
        combatPopupTitle.text = "BATTLE";

        GameObject svGO = new GameObject("ScrollView", typeof(RectTransform));
        svGO.transform.SetParent(combatPopup.transform, false);
        ScrollRect sr = svGO.AddComponent<ScrollRect>();
        svGO.AddComponent<Image>().color = new Color(0.04f, 0.02f, 0.01f, 0.85f);
        RectTransform svR = svGO.GetComponent<RectTransform>();
        svR.anchorMin = new Vector2(0.30f, 0.28f);
        svR.anchorMax = new Vector2(0.70f, 0.58f);
        svR.sizeDelta = Vector2.zero;

        GameObject vp = new GameObject("Viewport", typeof(RectTransform));
        vp.transform.SetParent(svGO.transform, false);
        vp.AddComponent<Mask>();
        vp.AddComponent<Image>().color = Color.clear;
        FullStretch(vp.GetComponent<RectTransform>());

        GameObject ctGO = new GameObject("Content", typeof(RectTransform));
        ctGO.transform.SetParent(vp.transform, false);
        combatPopupDetails = ctGO.AddComponent<Text>();
        combatPopupDetails.font = GetFont();
        combatPopupDetails.fontSize = 13;
        combatPopupDetails.color = Parchment;
        combatPopupDetails.alignment = TextAnchor.UpperCenter;
        combatPopupDetails.horizontalOverflow = HorizontalWrapMode.Wrap;
        combatPopupDetails.lineSpacing = 1.2f;
        combatPopupDetails.supportRichText = true;
        RectTransform ctR = ctGO.GetComponent<RectTransform>();
        ctR.anchorMin = new Vector2(0, 1);
        ctR.anchorMax = new Vector2(1, 1);
        ctR.sizeDelta = Vector2.zero;
        ContentSizeFitter csf = ctGO.AddComponent<ContentSizeFitter>();
        csf.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

        combatPopupScrollRect = sr;
        sr.viewport = vp.GetComponent<RectTransform>();
        sr.content = ctR;
        sr.vertical = true;
        sr.horizontal = false;
        sr.movementType = ScrollRect.MovementType.Clamped;
        sr.scrollSensitivity = 20;

        combatPopupDismissBtn = MakeButton(combatPopup.transform, "DismissBtn",
                                            new Vector2(0, -120), new Vector2(120, 40), "OK", Med, Gold);

        Button closeBtn = MakeButton(combatPopup.transform, "CombatClose",
            new Vector2(0, 0), new Vector2(40, 40), "\u2715", Med, Gold);
        RectTransform closeR = closeBtn.GetComponent<RectTransform>();
        closeR.anchorMin = new Vector2(0.88f, 0.88f);
        closeR.anchorMax = new Vector2(1.00f, 1.00f);
        closeR.sizeDelta = Vector2.zero;
        closeR.anchoredPosition = Vector2.zero;
        closeBtn.onClick.AddListener(() => {
            if (combatAutoDismiss != null) StopCoroutine(combatAutoDismiss);
            combatPopup.SetActive(false);
        });
    }
    public void ShowCombatPopup(CombatResult result, TerritoryData source, TerritoryData target)
    {
        if (combatPopup == null) return;

        string title = result.territoryCaptured ? "VICTORY" : "BATTLE REPORT";
        combatPopupTitle.text = title;
        combatPopupTitle.color = result.territoryCaptured ? Gold : Rust;

        string details = $"<b>{source.name}</b> attacks <b>{target.name}</b>\n\n";

        if (!string.IsNullOrEmpty(result.battleLog))
        {
            details += "<size=11>" + result.battleLog.Replace("\n", "\n") + "</size>\n\n";
        }
        else
        {
            details += $"<size=14>Attacker Dice:</size>\n<size=24><color=#C8A040>{DiceFaces(result.attackerDice)}</color></size>\n";
            details += $"<size=14>Defender Dice:</size>\n<size=24><color=#CC5555>{DiceFaces(result.defenderDice)}</color></size>\n\n";
        }

        details += $"Attacker lost: {result.attackerTroopsLost} troops\n";
        details += $"Defender lost: {result.defenderTroopsLost} troops\n\n";

        if (result.territoryCaptured)
            details += $"<color=#C8A040>TERRITORY CAPTURED!</color>";
        else
            details += $"<color=#CC5555>Attack repelled.</color>";

        combatPopupDetails.text = details;
        combatPopup.SetActive(true);
        if (combatPopupScrollRect != null)
            StartCoroutine(ScrollCombatLogToBottom());

        if (combatAutoDismiss != null)
            StopCoroutine(combatAutoDismiss);
        combatAutoDismiss = StartCoroutine(AutoDismissCombatPopup());
    }
    IEnumerator ScrollCombatLogToBottom()
    {
        yield return null;
        if (combatPopupScrollRect != null)
            combatPopupScrollRect.verticalNormalizedPosition = 0f;
    }
    IEnumerator AutoDismissCombatPopup()
    {
        yield return new WaitForSeconds(3.5f);
        combatPopup.SetActive(false);
        combatAutoDismiss = null;
    }
    string DiceFaces(int[] dice)
    {
        if (dice == null || dice.Length == 0) return "";
        string[] faces = { "\u2680", "\u2681", "\u2682", "\u2683", "\u2684", "\u2685" };
        string result = "";
        foreach (int d in dice)
            result += faces[Mathf.Clamp(d - 1, 0, 5)];
        return result;
    }
    public void FlashDamageEffect() => StartCoroutine(DamageFlashRoutine());

    IEnumerator DamageFlashRoutine()
    {
        damageFlashOverlay.color = new Color(1, 0, 0, 0.30f);
        for (float e = 0; e < 0.35f; e += Time.deltaTime)
        {
            damageFlashOverlay.color = new Color(1, 0, 0, Mathf.Lerp(0.30f, 0f, e / 0.35f));
            yield return null;
        }
        damageFlashOverlay.color = new Color(1, 0, 0, 0);
    }
}
