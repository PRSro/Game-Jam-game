using UnityEngine;
using UnityEngine.EventSystems;

public class TerritoryClickHandler : MonoBehaviour, IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler
{
    public TerritoryData territory;
    public System.Action<TerritoryData> onLeftClick;
    public System.Action<TerritoryData> onRightClick;

    public void OnPointerClick(PointerEventData eventData)
    {
        if (eventData.button == PointerEventData.InputButton.Right)
        {
            onRightClick?.Invoke(territory);
            return;
        }

        if (territory != null)
            onLeftClick?.Invoke(territory);

        if (GameUIManager.Instance != null)
        {
            ProvinceData pvd = GameUIManager.Instance.FindProvinceAtScreenPoint(eventData.position);
            if (pvd != null) GameUIManager.Instance.OnProvinceClicked(pvd);
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (territory == null || GameUIManager.Instance == null) return;
        GameUIManager.Instance.ShowTerritoryTooltip(territory);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (GameUIManager.Instance != null)
            GameUIManager.Instance.HideTerritoryTooltip();
    }

    static Font GetFont() => UIFont.Get();
}
