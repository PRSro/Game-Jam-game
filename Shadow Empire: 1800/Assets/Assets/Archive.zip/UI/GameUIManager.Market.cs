using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public partial class GameUIManager : MonoBehaviour
{
    void BuildBlackMarketPanel(Transform ct)
    {
        marketPanel = new GameObject("BlackMarketPanel", typeof(RectTransform));
        marketPanel.transform.SetParent(ct, false);
        Image mpBg = marketPanel.AddComponent<Image>();
        mpBg.color = new Color(0.06f, 0.03f, 0.01f, 0.97f);
        mpBg.raycastTarget = true;
        Anchor(marketPanel.GetComponent<RectTransform>(), 0.00f, 0.06f, 0.73f, 0.44f);
        marketPanel.SetActive(false);

        GameObject border = new GameObject("Border", typeof(RectTransform));
        border.transform.SetParent(marketPanel.transform, false);
        Image borderImg = border.AddComponent<Image>();
        borderImg.color = Gold;
        borderImg.raycastTarget = false;
        FullStretch(border.GetComponent<RectTransform>(), 2, 2);

        MakeUIText(marketPanel.transform, "Title", 14, FontStyle.Bold,
                   Gold, new Vector2(0.02f, 0.85f), new Vector2(0.98f, 0.98f))
            .GetComponent<Text>().text = "BLACK MARKET";

        marketSecretsText = MakeUIText(marketPanel.transform, "Secrets", 10, FontStyle.Normal,
            Parchment, new Vector2(0.02f, 0.76f), new Vector2(0.98f, 0.84f)).GetComponent<Text>();
        MakeUIText(marketPanel.transform, "CurrencyNote", 9, FontStyle.Italic,
            new Color(0.7f, 0.9f, 0.5f), new Vector2(0.02f, 0.86f), new Vector2(0.98f, 0.91f))
            .GetComponent<Text>().text = "Costs SECRETS \u2014 use black market intel & sabotage";

        int cols = 3;
        int rows = 2;
        float slotW = 1f / cols;
        float slotH = 0.28f;
        float startX = 0.02f;
        float startY = 0.72f;

        for (int r = 0; r < rows; r++)
        {
            for (int c = 0; c < cols; c++)
            {
                int idx = r * cols + c;
                if (idx >= 6) break;

                GameObject slotGO = new GameObject("MarketSlot_" + idx, typeof(RectTransform));
                slotGO.transform.SetParent(marketPanel.transform, false);
                Image slotBg = slotGO.AddComponent<Image>();
                Outline slotOutline = slotGO.AddComponent<Outline>();
                slotOutline.effectColor = new Color(0.55f, 0.40f, 0.08f, 0.7f);
                slotOutline.effectDistance = new Vector2(1, -1);
                float shade = (idx % 2 == 0) ? 0.07f : 0.10f;
                slotBg.color = new Color(shade, shade * 0.5f, shade * 0.2f);
                RectTransform sR = slotGO.GetComponent<RectTransform>();
                sR.anchorMin = new Vector2(startX + c * slotW + 0.005f, startY - (r + 1) * slotH - 0.01f);
                sR.anchorMax = new Vector2(startX + (c + 1) * slotW - 0.005f, startY - r * slotH + 0.01f);
                sR.sizeDelta = Vector2.zero;

                GameObject iconArea = new GameObject("IconArea", typeof(RectTransform));
                iconArea.transform.SetParent(slotGO.transform, false);
                Anchor(iconArea.GetComponent<RectTransform>(), 0.02f, 0.40f, 0.98f, 0.95f);

                Text iconText = MakeUIText(iconArea.transform, "IconText", 9, FontStyle.Bold,
                    Parchment, Vector2.zero, Vector2.one).GetComponent<Text>();
                iconText.alignment = TextAnchor.MiddleCenter;

                GameObject costArea = new GameObject("CostArea", typeof(RectTransform));
                costArea.transform.SetParent(slotGO.transform, false);
                Anchor(costArea.GetComponent<RectTransform>(), 0.02f, 0.01f, 0.98f, 0.38f);

                Text costText = MakeUIText(costArea.transform, "CostText", 8, FontStyle.Normal,
                    Parchment.WithA(0.85f), new Vector2(0f, 0.55f), new Vector2(1f, 1f)).GetComponent<Text>();
                costText.alignment = TextAnchor.LowerCenter;

                GameObject buyBtnGO = new GameObject("BuyBtn", typeof(RectTransform));
                buyBtnGO.transform.SetParent(costArea.transform, false);
                Image buyImg = buyBtnGO.AddComponent<Image>();
                buyImg.color = new Color(0.2f, 0.5f, 0.2f);
                Button buyBtn = buyBtnGO.AddComponent<Button>();
                buyBtn.targetGraphic = buyImg;
                Navigation nav = new Navigation();
                nav.mode = Navigation.Mode.None;
                buyBtn.navigation = nav;
                RectTransform buyR = buyBtnGO.GetComponent<RectTransform>();
                buyR.anchorMin = new Vector2(0.1f, 0f);
                buyR.anchorMax = new Vector2(0.9f, 0.45f);
                buyR.sizeDelta = Vector2.zero;

                Text buyLabel = MakeUIText(buyBtnGO.transform, "Label", 7, FontStyle.Bold,
                    Parchment, Vector2.zero, Vector2.one).GetComponent<Text>();
                buyLabel.text = "BUY";
                buyLabel.alignment = TextAnchor.MiddleCenter;

                GameObject soldStamp = new GameObject("SoldStamp", typeof(RectTransform));
                soldStamp.transform.SetParent(slotGO.transform, false);
                Text soldText = soldStamp.AddComponent<Text>();
                soldText.font = GetFont();
                soldText.fontSize = 16;
                soldText.fontStyle = FontStyle.Bold;
                soldText.color = new Color(0.8f, 0.1f, 0.1f, 0.7f);
                soldText.text = "SOLD";
                soldText.alignment = TextAnchor.MiddleCenter;
                RectTransform soldR = soldStamp.GetComponent<RectTransform>();
                soldR.anchorMin = Vector2.zero;
                soldR.anchorMax = Vector2.one;
                soldR.sizeDelta = Vector2.zero;
                soldStamp.SetActive(false);

                marketSlotCards.Add(slotGO);
            }
        }

        MakeUIText(marketPanel.transform, "RefreshNote", 9, FontStyle.Italic,
                   Parchment.WithA(0.4f), new Vector2(0.02f, 0f), new Vector2(0.98f, 0.035f))
            .GetComponent<Text>().text = "Market refreshes next turn";
    }

    public void RefreshMarketUI()
    {
        if (marketPanel == null || GameManager.Instance == null) return;

        FactionData player = GameManager.Instance.GetPlayerFaction();
        if (player == null) return;

        bool shouldShow = marketVisible && GameManager.Instance.currentState == GameState.PLAY_PHASE;
        marketPanel.SetActive(shouldShow);

        if (marketSecretsText != null)
            marketSecretsText.text = $"Secrets available: {player.secrets}";

        if (GameManager.Instance.currentMarket == null) return;

        for (int i = 0; i < marketSlotCards.Count; i++)
        {
            GameObject slotGO = marketSlotCards[i];
            if (slotGO == null) continue;

            if (i >= GameManager.Instance.currentMarket.Length)
            {
                slotGO.SetActive(false);
                continue;
            }

            BlackMarketSystem.MarketSlot slot = GameManager.Instance.currentMarket[i];
            if (slot == null) { slotGO.SetActive(false); continue; }

            slotGO.SetActive(true);
            int idx = i;

            Text iconText = slotGO.transform.Find("IconArea")?.Find("IconText")?.GetComponent<Text>();
            Text costText = slotGO.transform.Find("CostArea")?.Find("CostText")?.GetComponent<Text>();
            Transform buyBtnGO = slotGO.transform.Find("CostArea")?.Find("BuyBtn");
            Button buyBtn = buyBtnGO?.GetComponent<Button>();
            Text buyLabel = buyBtnGO?.Find("Label")?.GetComponent<Text>();
            GameObject soldStamp = slotGO.transform.Find("SoldStamp")?.gameObject;

            Image slotBg = slotGO.GetComponent<Image>();

            int effectiveCost = Mathf.RoundToInt(slot.secretsCost * player.marketDiscount);

            if (slot.purchased)
            {
                if (soldStamp != null) soldStamp.SetActive(true);
                if (buyBtnGO != null) buyBtnGO.gameObject.SetActive(false);
                if (costText != null) costText.text = "SOLD";
                if (iconText != null) iconText.text = "";
                continue;
            }

            if (soldStamp != null) soldStamp.SetActive(false);
            if (buyBtnGO != null) buyBtnGO.gameObject.SetActive(true);

            switch (slot.itemType)
            {
                case BlackMarketSystem.MarketItemType.CARD:
                    if (slotBg != null) slotBg.color = new Color(0.15f, 0.1f, 0.05f);
                    if (iconText != null && slot.card != null)
                        iconText.text = $"<color=#{GetTypeHexColor(slot.card.cardType)}>{slot.card.cardName}</color>\n({slot.card.cardType})";
                    break;
                case BlackMarketSystem.MarketItemType.TROOPS:
                    if (slotBg != null) slotBg.color = new Color(0.1f, 0.2f, 0.1f);
                    if (iconText != null) iconText.text = $"\u2694 +{slot.quantity} TROOPS";
                    if (iconText != null) iconText.color = new Color(0.2f, 0.7f, 0.3f);
                    break;
                case BlackMarketSystem.MarketItemType.INTEL:
                    if (slotBg != null) slotBg.color = new Color(0.15f, 0.12f, 0.05f);
                    if (iconText != null) iconText.text = "\uD83D\uDC41 INTEL";
                    if (iconText != null) iconText.color = Gold;
                    break;
                case BlackMarketSystem.MarketItemType.SABOTAGE_KIT:
                    if (slotBg != null) slotBg.color = new Color(0.2f, 0.08f, 0.08f);
                    if (iconText != null) iconText.text = "\uD83D\uDCA3 SABOTAGE";
                    if (iconText != null) iconText.color = new Color(0.8f, 0.2f, 0.1f);
                    break;
            }

            if (costText != null)
                costText.text = $"{effectiveCost} secrets";

            if (buyBtn != null)
            {
                bool affordable = player.secrets >= effectiveCost && !slot.purchased;
                Image buyImg = buyBtn.GetComponent<Image>();
                if (buyImg != null)
                    buyImg.color = affordable ? new Color(0.2f, 0.5f, 0.2f) : new Color(0.3f, 0.3f, 0.3f);
                buyBtn.interactable = affordable && !slot.purchased;

                buyBtn.onClick.RemoveAllListeners();
                buyBtn.onClick.AddListener(() =>
                {
                    if (slot.purchased) return;

                    if (slot.itemType == BlackMarketSystem.MarketItemType.TROOPS)
                    {
                        ShowTroopTargetSelector(idx);
                    }
                    else
                    {
                        if (BlackMarketSystem.PurchaseMarketSlot(player, slot))
                        {
                            StartCoroutine(GoldFlashAnimation(slotGO));
                            RefreshMarketUI();
                            UpdateAllFactions();
                            UpdatePlayerHandWithAnimation(player.hand);
                        }
                        else
                        {
                            StartCoroutine(ShakeAnimation(slotGO));
                        }
                    }
                });
            }

            if (buyLabel != null)
            {
                bool canAfford = player.secrets >= effectiveCost && !slot.purchased;
                if (slot.itemType == BlackMarketSystem.MarketItemType.CARD && player.hand.Count >= 7)
                    buyLabel.text = "FULL";
                else if (!canAfford)
                    buyLabel.text = "BROKE";
                else
                    buyLabel.text = "BUY";
            }
        }
    }

    void ToggleMarketPanel()
    {
        if (!CanUseActionPanels()) return;

        marketVisible = !marketVisible;
        if (marketVisible && EconomyUI.Instance != null)
            EconomyUI.Instance.Hide();
        marketPanel.SetActive(marketVisible);
        if (marketVisible)
        {
            RefreshMarketUI();
            marketBadge.SetActive(false);
        }
    }

    void OnMarketRefreshed()
    {
        RefreshMarketUI();
        CheckMarketBadge();
    }

    void ShowTroopTargetSelector(int slotIdx)
    {
        if (GameManager.Instance == null) return;
        FactionData player = GameManager.Instance.GetPlayerFaction();
        if (player == null) return;

        GameObject popup = new GameObject("TroopTargetPopup", typeof(RectTransform));
        popup.transform.SetParent(canvas.transform, false);
        Image popBg = popup.AddComponent<Image>();
        popBg.color = new Color(0, 0, 0, 0.9f);
        Anchor(popup.GetComponent<RectTransform>(), 0.25f, 0.25f, 0.75f, 0.75f);

        MakeUIText(popup.transform, "Title", 16, FontStyle.Bold,
                   Gold, new Vector2(0.05f, 0.80f), new Vector2(0.95f, 0.95f))
            .GetComponent<Text>().text = "Select target territory";

        float yPos = 0.70f;
        foreach (TerritoryData t in player.territories)
        {
            if (t == null) continue;
            Button terrBtn = MakeButton(popup.transform, "Terr_" + t.name.Replace(" ", ""),
                new Vector2(0, Screen.height * (yPos - 0.5f)),
                new Vector2(200, 30), $"{t.name} ({t.troops})", Med, Gold);
            TerritoryData captured = t;
            int capturedIdx = slotIdx;
            terrBtn.onClick.AddListener(() =>
            {
                if (GameManager.Instance.currentMarket != null &&
                    capturedIdx < GameManager.Instance.currentMarket.Length)
                {
                    BlackMarketSystem.MarketSlot slot = GameManager.Instance.currentMarket[capturedIdx];
                    if (BlackMarketSystem.PurchaseMarketSlot(player, slot, captured))
                    {
                        RefreshMarketUI();
                        UpdateAllFactions();
                        UpdateTerritoryMap();
                    }
                }
                Destroy(popup);
            });
            yPos -= 0.08f;
        }

        Button cancelBtn = MakeButton(popup.transform, "CancelBtn",
            new Vector2(0, -Screen.height * 0.3f),
            new Vector2(120, 35), "CANCEL", Dark, Med);
        cancelBtn.onClick.AddListener(() => Destroy(popup));
    }

    IEnumerator GoldFlashAnimation(GameObject slotGO)
    {
        if (slotGO == null) yield break;
        Image bg = slotGO.GetComponent<Image>();
        Color original = bg.color;
        bg.color = Gold;
        float elapsed = 0f;
        while (elapsed < 0.3f)
        {
            elapsed += Time.deltaTime;
            bg.color = Color.Lerp(Gold, original, elapsed / 0.3f);
            yield return null;
        }
        bg.color = original;
    }

    IEnumerator ShakeAnimation(GameObject slotGO)
    {
        if (slotGO == null) yield break;
        Vector3 original = slotGO.transform.localPosition;
        float elapsed = 0f;
        while (elapsed < 0.2f)
        {
            elapsed += Time.deltaTime;
            float offset = Mathf.Sin(elapsed * 60f) * 5f;
            slotGO.transform.localPosition = original + new Vector3(offset, 0, 0);
            yield return null;
        }
        slotGO.transform.localPosition = original;
    }

    public void SetMarketBadge(bool show, string text = "!")
    {
        if (marketBadge == null) return;
        marketBadge.SetActive(show);
        if (marketBadgeText != null)
            marketBadgeText.text = text;
    }

    public void CheckMarketBadge()
    {
        if (GameManager.Instance == null || GameManager.Instance.currentMarket == null) return;
        bool hasAffordable = false;
        FactionData player = GameManager.Instance.GetPlayerFaction();
        if (player == null) return;
        foreach (var slot in GameManager.Instance.currentMarket)
        {
            if (slot == null || slot.purchased) continue;
            int cost = Mathf.RoundToInt(slot.secretsCost * player.marketDiscount);
            if (player.secrets >= cost)
            {
                if (slot.itemType != BlackMarketSystem.MarketItemType.CARD || player.hand.Count < 7)
                {
                    hasAffordable = true;
                    break;
                }
            }
        }
        SetMarketBadge(hasAffordable, "!");
    }
}
