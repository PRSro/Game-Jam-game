using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public partial class GameUIManager : MonoBehaviour
{
    void BuildReinforcementPanel(Transform ct)
    {
        reinforcementPanel = new GameObject("ReinforcementPanel", typeof(RectTransform));
        reinforcementPanel.transform.SetParent(ct, false);
        Image rpBg = reinforcementPanel.AddComponent<Image>();
        rpBg.color = new Color(0, 0, 0, 0.85f);
        rpBg.raycastTarget = true;
        Anchor(reinforcementPanel.GetComponent<RectTransform>(), 0.01f, 0.72f, 0.32f, 0.97f);
        reinforcementPanel.SetActive(false);

        GameObject border = new GameObject("Border", typeof(RectTransform));
        border.transform.SetParent(reinforcementPanel.transform, false);
        border.AddComponent<Image>().color = Gold.WithA(0.50f);
        RectTransform bR = border.GetComponent<RectTransform>();
        bR.anchorMin = Vector2.zero;
        bR.anchorMax = Vector2.one;
        bR.sizeDelta = Vector2.zero;

        GameObject inner = new GameObject("Inner", typeof(RectTransform));
        inner.transform.SetParent(reinforcementPanel.transform, false);
        inner.AddComponent<Image>().color = Darkest;
        RectTransform iR = inner.GetComponent<RectTransform>();
        iR.anchorMin = Vector2.zero;
        iR.anchorMax = Vector2.one;
        iR.sizeDelta = new Vector2(-4, -4);

        MakeUIText(reinforcementPanel.transform, "Title", 16, FontStyle.Bold,
                   Gold, new Vector2(0.05f, 0.72f), new Vector2(0.95f, 0.92f))
            .GetComponent<Text>().text = "REINFORCEMENT";

        reinforcementRemainingText = MakeUIText(reinforcementPanel.transform, "Remaining", 13, FontStyle.Normal,
                                                 Parchment, new Vector2(0.05f, 0.45f), new Vector2(0.95f, 0.68f)).GetComponent<Text>();

        MakeUIText(reinforcementPanel.transform, "Instruction", 10, FontStyle.Normal,
                   Parchment.WithA(0.65f), new Vector2(0.05f, 0.52f), new Vector2(0.95f, 0.68f))
            .GetComponent<Text>().text = "Click your territories to place troops";

        reinforcementConfirmBtn = MakeButton(reinforcementPanel.transform, "ConfirmBtn",
                                              new Vector2(0, -10), new Vector2(120, 30), "CONFIRM", Med, Gold);
        reinforcementConfirmBtn.onClick.AddListener(OnReinforcementConfirm);
        reinforcementConfirmBtn.gameObject.SetActive(true);
    }
    public void ShowReinforcementPanel(int remaining)
    {
        if (reinforcementPanel == null) return;
        if (remaining <= 0)
        {
            reinforcementPanel.SetActive(false);
            return;
        }
        reinforcementRemainingText.text = $"Troops to place: {remaining}";
        reinforcementPanel.SetActive(true);
        reinforcementConfirmBtn.GetComponentInChildren<Text>().text =
            remaining > 0 ? $"CONFIRM ({remaining} left)" : "CONFIRM";
        reinforcementConfirmBtn.gameObject.SetActive(true);
        UpdateTerritoryMap();
    }
    public void UpdateReinforcementPanel(int remaining)
    {
        if (reinforcementPanel == null) return;
        reinforcementPanel.SetActive(true);
        if (reinforcementRemainingText != null)
            reinforcementRemainingText.text = $"Troops to place: {remaining}";
        if (reinforcementConfirmBtn != null)
        {
            reinforcementConfirmBtn.GetComponentInChildren<Text>().text =
                remaining > 0 ? $"CONFIRM ({remaining} left)" : "CONFIRM";
            reinforcementConfirmBtn.gameObject.SetActive(true);
        }
        UpdateTerritoryMap();
    }
    void OnReinforcementConfirm()
    {
        reinforcementPanel.SetActive(false);
        if (GameManager.Instance != null)
            GameManager.Instance.IsWaitingForReinforcements = false;
    }
    void BuildFortifyPanel(Transform ct)
    {
        fortifyPanel = new GameObject("FortifyPanel", typeof(RectTransform));
        fortifyPanel.transform.SetParent(ct, false);
        Image fpBg = fortifyPanel.AddComponent<Image>();
        fpBg.color = new Color(0, 0, 0, 0.85f);
        fpBg.raycastTarget = false;
        Anchor(fortifyPanel.GetComponent<RectTransform>(), 0.20f, 0.60f, 0.75f, 0.92f);
        fortifyPanel.SetActive(false);

        fortifyTitleText = MakeUIText(fortifyPanel.transform, "Title", 18, FontStyle.Bold,
            Gold, new Vector2(0.05f, 0.70f), new Vector2(0.95f, 0.95f)).GetComponent<Text>();
        fortifyTitleText.text = "FORTIFY PHASE";

        fortifyInstructionText = MakeUIText(fortifyPanel.transform, "Instruction", 11, FontStyle.Normal,
            Parchment.WithA(0.65f), new Vector2(0.05f, 0.28f), new Vector2(0.95f, 0.65f)).GetComponent<Text>();
        fortifyInstructionText.text = "Click a territory with excess troops, then a connected friendly territory.";

        // ADDED: UPGRADE 3 - fortify count slider
        GameObject sliderRow = new GameObject("SliderRow", typeof(RectTransform));
        sliderRow.transform.SetParent(fortifyPanel.transform, false);
        RectTransform srR = sliderRow.GetComponent<RectTransform>();
        srR.anchorMin = new Vector2(0.30f, 0.22f);
        srR.anchorMax = new Vector2(0.70f, 0.36f);
        srR.sizeDelta = Vector2.zero;

        fortifyCountText = MakeUIText(sliderRow.transform, "CountLabel", 12, FontStyle.Bold,
            Parchment, new Vector2(0f, 0.6f), new Vector2(1f, 1f)).GetComponent<Text>();
        fortifyCountText.text = "Troops to move: 1";
        fortifyCountText.alignment = TextAnchor.MiddleCenter;

        GameObject sliderGO = new GameObject("Slider", typeof(RectTransform));
        sliderGO.transform.SetParent(sliderRow.transform, false);
        fortifySlider = sliderGO.AddComponent<Slider>();
        RectTransform slR = sliderGO.GetComponent<RectTransform>();
        slR.anchorMin = new Vector2(0f, 0f);
        slR.anchorMax = new Vector2(1f, 0.5f);
        slR.sizeDelta = Vector2.zero;
        Image sliderBg = sliderGO.AddComponent<Image>();
        sliderBg.color = new Color(0.2f, 0.12f, 0.04f);
        GameObject fillArea = new GameObject("FillArea", typeof(RectTransform));
        fillArea.transform.SetParent(sliderGO.transform, false);
        RectTransform faR = fillArea.GetComponent<RectTransform>();
        faR.anchorMin = Vector2.zero; faR.anchorMax = Vector2.one;
        faR.sizeDelta = new Vector2(-10, -4);
        GameObject fillImg = new GameObject("Fill", typeof(RectTransform));
        fillImg.transform.SetParent(fillArea.transform, false);
        Image fillImgC = fillImg.AddComponent<Image>();
        fillImgC.color = Gold;
        RectTransform fiR2 = fillImg.GetComponent<RectTransform>();
        fiR2.anchorMin = Vector2.zero; fiR2.anchorMax = new Vector2(1, 1);
        fiR2.sizeDelta = Vector2.zero;
        GameObject handle = new GameObject("Handle", typeof(RectTransform));
        handle.transform.SetParent(sliderGO.transform, false);
        Image handleImg = handle.AddComponent<Image>();
        handleImg.color = Parchment;
        RectTransform haR = handle.GetComponent<RectTransform>();
        haR.sizeDelta = new Vector2(16, 16);
        haR.anchorMin = haR.anchorMax = new Vector2(0.5f, 0.5f);
        fortifySlider.fillRect = fiR2;
        fortifySlider.handleRect = haR;
        fortifySlider.minValue = 1;
        fortifySlider.maxValue = 10;
        fortifySlider.wholeNumbers = true;
        fortifySlider.value = 1;
        fortifySlider.onValueChanged.AddListener(val => { fortifyCountText.text = $"Troops to move: {(int)val}"; selectedFortifyCount = (int)val; });
        sliderRow.SetActive(false);

        fortifySkipBtn = MakeButton(fortifyPanel.transform, "SkipBtn",
            Vector2.zero, new Vector2(100, 40), "SKIP", Med, Gold);
        RectTransform skipR = fortifySkipBtn.GetComponent<RectTransform>();
        skipR.anchorMin = new Vector2(0.05f, 0.05f);
        skipR.anchorMax = new Vector2(0.45f, 0.22f);
        skipR.sizeDelta = Vector2.zero;
        skipR.anchoredPosition = Vector2.zero;
        fortifySkipBtn.onClick.AddListener(OnFortifySkip);

        fortifyConfirmBtn = MakeButton(fortifyPanel.transform, "ConfirmBtn",
            Vector2.zero, new Vector2(100, 40), "CONFIRM", Dark, Med);
        RectTransform confirmR = fortifyConfirmBtn.GetComponent<RectTransform>();
        confirmR.anchorMin = new Vector2(0.55f, 0.05f);
        confirmR.anchorMax = new Vector2(0.95f, 0.22f);
        confirmR.sizeDelta = Vector2.zero;
        confirmR.anchoredPosition = Vector2.zero;
        fortifyConfirmBtn.onClick.AddListener(OnFortifyConfirm);
        fortifyConfirmBtn.gameObject.SetActive(false);
    }
    void ShowFortifyPanel()
    {
        if (fortifyPanel == null) return;
        FactionData p = GameManager.Instance?.GetPlayerFaction();
        bool hasFortifySource = p != null && p.territories.Any(t => t.troops > 1);
        if (!hasFortifySource)
        {
            AddLogMessage("No territories have enough troops to fortify. Skipping.");
            GameManager.Instance.IsWaitingForFortify = false;
            return;
        }
        fortifyPanel.SetActive(true);
        waitingForFortifySource = true;
        waitingForFortifyTarget = false;
        pendingFortifySource = null;
        AddLogMessage("FORTIFY: Click one of your territories with excess troops.");
        UpdateMapClickZones();
    }
    void HideFortifyPanel()
    {
        if (fortifyPanel == null) return;
        fortifyPanel.SetActive(false);
        waitingForFortifySource = false;
        waitingForFortifyTarget = false;
        pendingFortifySource = null;
        pendingFortifyDest = null;
        HidePhaseArrows();
        HideFortifyCountSlider();
        ClearTerritoryHighlights();
    }
    void OnFortifySkip()
    {
        HideFortifyPanel();
        if (GameManager.Instance != null)
            GameManager.Instance.IsWaitingForFortify = false;
    }
    void OnFortifyConfirm()
    {
        if (pendingFortifySource == null || pendingFortifyDest == null) return;
        int count = Mathf.Min(selectedFortifyCount, pendingFortifySource.troops - 1);
        if (count <= 0) { AddLogMessage("Not enough troops to move."); return; }
        if (GameManager.Instance.FortifyTroops(pendingFortifySource, pendingFortifyDest, count))
        {
            HideFortifyPanel();
            UpdateTerritoryMap();
        }
        else
        {
            AddLogMessage("Cannot fortify — territories not connected through friendly territory.");
        }
    }
    void ShowFortifyCountSlider(int maxCount)
    {
        if (fortifySlider == null || fortifyCountText == null) return;
        fortifySlider.maxValue = Mathf.Max(1, maxCount);
        fortifySlider.value = 1;
        selectedFortifyCount = 1;
        fortifyCountText.text = $"Troops to move: 1";
        // sliderRow is child of fortifyPanel, found by name
        Transform sliderRow = fortifyPanel.transform.Find("SliderRow");
        if (sliderRow != null) sliderRow.gameObject.SetActive(true);
        if (fortifyConfirmBtn != null) fortifyConfirmBtn.gameObject.SetActive(true);
    }
    void HideFortifyCountSlider()
    {
        Transform sliderRow = fortifyPanel != null ? fortifyPanel.transform.Find("SliderRow") : null;
        if (sliderRow != null) sliderRow.gameObject.SetActive(false);
        if (fortifyConfirmBtn != null) fortifyConfirmBtn.gameObject.SetActive(false);
    }
    void BuildRegionBonusPanel(Transform ct)
    {
        regionBonusPanel = new GameObject("RegionBonusPanel", typeof(RectTransform));
        regionBonusPanel.transform.SetParent(ct, false);
        Image rpBg = regionBonusPanel.AddComponent<Image>();
        rpBg.color = new Color(0.04f, 0.02f, 0.01f, 0.88f);
        rpBg.raycastTarget = false;
        Anchor(regionBonusPanel.GetComponent<RectTransform>(), 0.01f, 0.06f, 0.30f, 0.12f);

        regionBonusText = MakeUIText(regionBonusPanel.transform, "BonusText", 7, FontStyle.Normal,
            Gold.WithA(0.85f), new Vector2(0.02f, 0f), new Vector2(0.98f, 1f)).GetComponent<Text>();
        regionBonusText.alignment = TextAnchor.MiddleLeft;
        regionBonusText.supportRichText = true;
    }
    void UpdateRegionBonusDisplay()
    {
        if (regionBonusText == null || GameManager.Instance == null) return;
        FactionData player = GameManager.Instance.GetPlayerFaction();
        if (player == null) return;
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        List<string> regions = TerritoryGraph.GetAllRegionNames();
        foreach (string region in regions)
        {
            int bonus = TerritoryGraph.GetRegionBonus(region);
            List<string> terrs = TerritoryGraph.GetRegionTerritories(region);
            string terrStr = string.Join(", ", terrs);

            bool owned = TerritoryGraph.OwnsEntireRegion(region, player.territories);
            string colorTag = owned ? "<color=#44CC44>" : "<color=#C8A040>";
            sb.AppendLine($"{colorTag}{region}</color> ({terrStr}) = +{bonus}");
        }
        regionBonusText.text = sb.ToString().TrimEnd();
    }
    void BuildPhaseBanner(Transform ct)
    {
        phaseBanner = new GameObject("PhaseBanner", typeof(RectTransform));
        phaseBanner.transform.SetParent(ct, false);
        Image bannerBg = phaseBanner.AddComponent<Image>();
        bannerBg.color = new Color(0, 0, 0, 0.82f);
        bannerBg.raycastTarget = false;
        phaseBanner.AddComponent<CanvasGroup>();
        Anchor(phaseBanner.GetComponent<RectTransform>(), 0f, 0.44f, 1f, 0.57f);

        GameObject accent = new GameObject("Accent", typeof(RectTransform));
        accent.transform.SetParent(phaseBanner.transform, false);
        Image accentImg = accent.AddComponent<Image>();
        accentImg.color = Gold;
        accentImg.raycastTarget = false;
        Anchor(accent.GetComponent<RectTransform>(), 0f, 0f, 0.003f, 1f);

        phaseBannerText = MakeUIText(phaseBanner.transform, "BannerText", 36, FontStyle.Bold,
                                      Parchment, new Vector2(0.01f, 0f), Vector2.one).GetComponent<Text>();
        phaseBannerText.alignment = TextAnchor.MiddleLeft;
        phaseBanner.SetActive(false);
    }
    IEnumerator ShowPhaseBanner(string label, Color color, float duration = 1.8f)
    {
        phaseBannerText.text = label;
        phaseBannerText.color = color;

        Image bannerBg = phaseBanner.GetComponent<Image>();
        if (bannerBg != null)
        {
            Color phaseColor = new Color(0.1f, 0.1f, 0.1f, 0.92f);
            string upper = label.ToUpper();
            if (upper.Contains("REINFORCEMENT")) phaseColor = new Color(0.2f, 0.5f, 0.2f, 0.92f);
            else if (upper.Contains("DRAW"))      phaseColor = new Color(0.3f, 0.3f, 0.6f, 0.92f);
            else if (upper.Contains("PLAY"))      phaseColor = new Color(0.5f, 0.4f, 0.1f, 0.92f);
            else if (upper.Contains("RESOLUTION")) phaseColor = new Color(0.5f, 0.2f, 0.1f, 0.92f);
            else if (upper.Contains("FORTIFY"))   phaseColor = new Color(0.2f, 0.4f, 0.5f, 0.92f);
            else if (upper.Contains("ATTACK"))    phaseColor = new Color(0.6f, 0.1f, 0.1f, 0.92f);
            bannerBg.color = phaseColor;
        }

        RectTransform rt = phaseBanner.GetComponent<RectTransform>();
        phaseBanner.SetActive(true);

        for (float t = 0; t < 0.18f; t += Time.deltaTime)
        {
            float x = Mathf.Lerp(-Screen.width, 0f, t / 0.18f);
            rt.anchoredPosition = new Vector2(x, 0f);
            yield return null;
        }
        rt.anchoredPosition = Vector2.zero;
        yield return StartCoroutine(AutoHideBanner(duration));
        phaseBannerCoroutine = null;
    }
    IEnumerator AutoHideBanner(float duration)
    {
        yield return new WaitForSeconds(duration);
        if (phaseBanner == null) yield break;
        CanvasGroup cg = phaseBanner.GetComponent<CanvasGroup>();
        if (cg == null) cg = phaseBanner.AddComponent<CanvasGroup>();
        float t = 0f;
        while (t < 0.35f)
        {
            cg.alpha = 1f - (t / 0.35f);
            t += Time.deltaTime;
            yield return null;
        }
        phaseBanner.SetActive(false);
        cg.alpha = 1f;
    }
    void ShowCombatResultBanner(CombatResult result, TerritoryData source, TerritoryData target)
    {
        if (activeCombatBanner != null) Destroy(activeCombatBanner);

        string outcome = result.attackerWon
            ? $"\u2694 VICTORY! {source.name} \u2192 {target.name} captured!"
            : $"\uD83D\uDEE1 REPELLED! Attack from {source.name} failed.";
        Color bannerColor = result.attackerWon
            ? new Color(0.1f, 0.6f, 0.1f, 0.95f)
            : new Color(0.6f, 0.1f, 0.1f, 0.95f);

        GameObject banner = new GameObject("CombatBanner");
        banner.transform.SetParent(canvas.transform, false);
        RectTransform brt = banner.AddComponent<RectTransform>();
        brt.anchorMin = new Vector2(0f, 0.88f);
        brt.anchorMax = new Vector2(0.735f, 0.96f);
        brt.sizeDelta = Vector2.zero;
        brt.anchoredPosition = Vector2.zero;
        Image bImg = banner.AddComponent<Image>();
        bImg.color = bannerColor;
        Text bTxt = MakeUIText(banner.transform, "BannerText", 14,
            FontStyle.Bold, Color.white,
            new Vector2(0.02f, 0f), new Vector2(0.98f, 1f)).GetComponent<Text>();
        bTxt.text = outcome;
        bTxt.alignment = TextAnchor.MiddleCenter;
        activeCombatBanner = banner;
        Destroy(banner, 2.5f);
    }
    void BuildDiceChoicePopup(Transform ct)
    {
        diceChoicePopup = new GameObject("DiceChoicePopup", typeof(RectTransform));
        diceChoicePopup.transform.SetParent(ct, false);
        Image dcpBg = diceChoicePopup.AddComponent<Image>();
        dcpBg.color = new Color(0, 0, 0, 0.85f);
        dcpBg.raycastTarget = true;
        Anchor(diceChoicePopup.GetComponent<RectTransform>(), 0.3f, 0.30f, 0.7f, 0.55f);
        diceChoicePopup.SetActive(false);

        GameObject dcpBorder = new GameObject("Border", typeof(RectTransform));
        dcpBorder.transform.SetParent(diceChoicePopup.transform, false);
        dcpBorder.AddComponent<Image>().color = Gold.WithA(0.50f);
        FullStretch(dcpBorder.GetComponent<RectTransform>(), 2, 2);

        diceChoiceTitle = MakeUIText(diceChoicePopup.transform, "Title", 22, FontStyle.Bold,
            Gold, new Vector2(0, 0.68f), new Vector2(1, 0.90f)).GetComponent<Text>();
        diceChoiceTitle.text = "CHOOSE ATTACK DICE";

        MakeUIText(diceChoicePopup.transform, "Instruction", 12, FontStyle.Normal,
            Parchment, new Vector2(0, 0.50f), new Vector2(1, 0.65f)).GetComponent<Text>().text = "How many dice will you roll?";

        float btnW = 0.18f;
        float startX = 0.5f - btnW * 1.5f;
        dice1Btn = MakeButton(diceChoicePopup.transform, "Dice1Btn",
            new Vector2(-120, -30), new Vector2(70, 50), "1", Dark, Med);
        dice2Btn = MakeButton(diceChoicePopup.transform, "Dice2Btn",
            new Vector2(0, -30), new Vector2(70, 50), "2", Dark, Med);
        dice3Btn = MakeButton(diceChoicePopup.transform, "Dice3Btn",
            new Vector2(120, -30), new Vector2(70, 50), "3", Dark, Med);

        // Wire dice choice listeners
        if (dice1Btn != null) dice1Btn.onClick.AddListener(() => OnDiceChoiceSelected(1));
        if (dice2Btn != null) dice2Btn.onClick.AddListener(() => OnDiceChoiceSelected(2));
        if (dice3Btn != null) dice3Btn.onClick.AddListener(() => OnDiceChoiceSelected(3));

        // Troop slider
        GameObject sliderRow = new GameObject("TroopSliderRow", typeof(RectTransform));
        sliderRow.transform.SetParent(diceChoicePopup.transform, false);
        RectTransform sr = sliderRow.GetComponent<RectTransform>();
        sr.anchorMin = new Vector2(0.05f, 0.02f);
        sr.anchorMax = new Vector2(0.95f, 0.18f);
        sr.sizeDelta = Vector2.zero;
        sr.anchoredPosition = Vector2.zero;

        troopSliderLabel = MakeUIText(sliderRow.transform, "SliderLabel", 11, FontStyle.Normal,
            Parchment, new Vector2(0f, 0.5f), new Vector2(0.45f, 1f)).GetComponent<Text>();
        troopSliderLabel.text = "Troops: 1";

        GameObject sliderGO = new GameObject("Slider", typeof(RectTransform));
        sliderGO.transform.SetParent(sliderRow.transform, false);
        troopSlider = sliderGO.AddComponent<Slider>();
        troopSlider.minValue = 1;
        troopSlider.maxValue = 5;
        troopSlider.value = 1;
        troopSlider.wholeNumbers = true;
        RectTransform srt = sliderGO.GetComponent<RectTransform>();
        srt.anchorMin = new Vector2(0.50f, 0f);
        srt.anchorMax = new Vector2(1f, 1f);
        srt.sizeDelta = Vector2.zero;
        srt.anchoredPosition = Vector2.zero;

        Image sliderBg = sliderGO.AddComponent<Image>();
        sliderBg.color = new Color(0.2f, 0.2f, 0.2f, 0.8f);

        GameObject fillArea = new GameObject("FillArea", typeof(RectTransform));
        fillArea.transform.SetParent(sliderGO.transform, false);
        RectTransform fa = fillArea.GetComponent<RectTransform>();
        fa.anchorMin = Vector2.zero; fa.anchorMax = Vector2.one;
        fa.sizeDelta = new Vector2(-10, -6);
        fa.anchoredPosition = Vector2.zero;
        Image fillImg = fillArea.AddComponent<Image>();
        fillImg.color = new Color(0.6f, 0.2f, 0.1f, 0.9f);
        troopSlider.fillRect = fa;

        troopSlider.onValueChanged.AddListener((float val) => {
            troopSliderLabel.text = "Troops: " + Mathf.RoundToInt(val);
        });
    }
    void BuildTargetPopup(Transform ct)
    {
        targetPopup = new GameObject("TargetPopup", typeof(RectTransform));
        targetPopup.transform.SetParent(ct, false);
        Image tpBg = targetPopup.AddComponent<Image>();
        tpBg.color = new Color(0, 0, 0, 0.85f);
        tpBg.raycastTarget = false;
        Anchor(targetPopup.GetComponent<RectTransform>(), 0.3f, 0.28f, 0.7f, 0.62f);
        targetPopup.SetActive(false);

        GameObject tpBorder = new GameObject("Border", typeof(RectTransform));
        tpBorder.transform.SetParent(targetPopup.transform, false);
        tpBorder.AddComponent<Image>().color = Gold.WithA(0.50f);
        FullStretch(tpBorder.GetComponent<RectTransform>(), 2, 2);

        MakeUIText(targetPopup.transform, "Title", 28, FontStyle.Bold,
                   Gold, new Vector2(0, 0.68f), new Vector2(1, 0.92f))
        .GetComponent<Text>().text = "SELECT TARGET";

        targetPopupCardName = MakeUIText(targetPopup.transform, "CardName", 18, FontStyle.Normal,
                                         Parchment, new Vector2(0, 0.43f), new Vector2(1, 0.63f)).GetComponent<Text>();

        MakeUIText(targetPopup.transform, "Instruction", 13, FontStyle.Italic,
                   Parchment.WithA(0.55f), new Vector2(0, 0.25f), new Vector2(1, 0.38f))
        .GetComponent<Text>().text = "Click an enemy faction to target them";

        GameObject ctGO = new GameObject("CancelBtn", typeof(RectTransform));
        ctGO.transform.SetParent(targetPopup.transform, false);
        Image ctImg = ctGO.AddComponent<Image>();
        ctImg.color = new Color(0.30f, 0.12f, 0.06f);
        cancelTargetBtn = ctGO.AddComponent<Button>();
        cancelTargetBtn.targetGraphic = ctImg;
        Navigation cnav = new Navigation();
        cnav.mode = Navigation.Mode.None;
        cancelTargetBtn.navigation = cnav;
        Anchor(ctGO.GetComponent<RectTransform>(), 0.3f, 0.03f, 0.7f, 0.16f);
        MakeUIText(ctGO.transform, "Label", 16, FontStyle.Bold,
                   Parchment, Vector2.zero, Vector2.one).GetComponent<Text>().text = "CANCEL";
    }
    void BuildTooltip(Transform ct)
    {
        tooltipPanel = new GameObject("CardTooltip", typeof(RectTransform));
        tooltipPanel.transform.SetParent(ct, false);
        RectTransform ttR = tooltipPanel.GetComponent<RectTransform>();
        ttR.pivot = new Vector2(0.5f, 0f);
        ttR.anchorMin = ttR.anchorMax = Vector2.zero;
        ttR.sizeDelta = new Vector2(200, 150);
        Image ttBg = tooltipPanel.AddComponent<Image>();
        ttBg.color = Dark;
        ttBg.raycastTarget = false;
        tooltipPanel.SetActive(false);

        MakeHRule(tooltipPanel.transform, new Vector2(0.05f, 0.72f), new Vector2(0.95f, 0.74f), Gold.WithA(0.50f))
        .GetComponent<Image>().raycastTarget = false;

        tooltipNameText = MakeUIText(tooltipPanel.transform, "Name", 16, FontStyle.Bold,
                                     Parchment, new Vector2(0.05f, 0.78f), new Vector2(0.95f, 0.98f)).GetComponent<Text>();
        tooltipTypeText = MakeUIText(tooltipPanel.transform, "Type", 11, FontStyle.Bold,
                                     Parchment, new Vector2(0.05f, 0.64f), new Vector2(0.95f, 0.72f)).GetComponent<Text>();
        tooltipPowerText = MakeUIText(tooltipPanel.transform, "Power", 14, FontStyle.Bold,
                                      Gold, new Vector2(0.05f, 0.53f), new Vector2(0.95f, 0.62f)).GetComponent<Text>();
        tooltipDescriptionText = MakeUIText(tooltipPanel.transform, "Description", 12, FontStyle.Normal,
                                            Parchment.WithA(0.65f), new Vector2(0.05f, 0.02f), new Vector2(0.95f, 0.50f)).GetComponent<Text>();
        tooltipDescriptionText.horizontalOverflow = HorizontalWrapMode.Wrap;
    }
    void BuildGameOverPanel(Transform ct)
    {
        gameOverPanel = new GameObject("GameOverPanel", typeof(RectTransform));
        gameOverPanel.transform.SetParent(ct, false);
        gameOverCanvasGroup = gameOverPanel.AddComponent<CanvasGroup>();
        gameOverCanvasGroup.alpha = 0f;
        gameOverCanvasGroup.blocksRaycasts = false;
        gameOverPanel.AddComponent<Image>();
        FullStretch(gameOverPanel.GetComponent<RectTransform>());
        gameOverPanel.SetActive(false);

        gameOverTitleText = MakeUIText(gameOverPanel.transform, "Title", 64, FontStyle.Bold,
                                       Parchment, new Vector2(0, 0.55f), new Vector2(1, 0.78f)).GetComponent<Text>();

        GameObject goDiv = new GameObject("Divider", typeof(RectTransform));
        goDiv.transform.SetParent(gameOverPanel.transform, false);
        gameOverDivider = goDiv.AddComponent<Image>();
        gameOverDivider.color = Gold;
        RectTransform gdR = goDiv.GetComponent<RectTransform>();
        gdR.anchorMin = gdR.anchorMax = new Vector2(0.5f, 0.5f);
        gdR.sizeDelta = new Vector2(300, 2);
        gdR.anchoredPosition = new Vector2(0, 40);

        gameOverSubtitleText = MakeUIText(gameOverPanel.transform, "Subtitle", 28, FontStyle.Normal,
                                          Parchment.WithA(0.65f), new Vector2(0, 0.38f), new Vector2(1, 0.50f)).GetComponent<Text>();

        playAgainButton = MakeButton(gameOverPanel.transform, "PlayAgainBtn",
                                     new Vector2(0, -60), new Vector2(200, 60), "PLAY AGAIN", Dark, Med);
        quitButton = MakeButton(gameOverPanel.transform, "QuitBtn",
                                new Vector2(0, -140), new Vector2(200, 60), "QUIT", Dark, Med);
    }
    void BuildEventPopup(Transform ct)
    {
        eventOverlay = new GameObject("EventOverlay");
        eventOverlay.transform.SetParent(ct, false);
        RectTransform ovR = eventOverlay.AddComponent<RectTransform>();
        ovR.anchorMin = Vector2.zero; ovR.anchorMax = Vector2.one;
        ovR.sizeDelta = Vector2.zero;
        Image ovImg = eventOverlay.AddComponent<Image>();
        ovImg.color = new Color(0f, 0f, 0f, 0.65f);
        ovImg.raycastTarget = true;
        eventOverlay.SetActive(false);

        eventPopup = new GameObject("EventPopup", typeof(RectTransform));
        eventPopup.transform.SetParent(ct, false);
        Image epBg = eventPopup.AddComponent<Image>();
        epBg.color = new Color(0.04f, 0.02f, 0.01f, 0.94f);
        epBg.raycastTarget = true;
        FullStretch(eventPopup.GetComponent<RectTransform>());
        eventPopup.SetActive(false);

        GameObject epBorder = new GameObject("Border", typeof(RectTransform));
        epBorder.transform.SetParent(eventPopup.transform, false);
        epBorder.AddComponent<Image>().color = Gold.WithA(0.40f);
        RectTransform ebR = epBorder.GetComponent<RectTransform>();
        ebR.anchorMin = new Vector2(0.2f, 0.25f);
        ebR.anchorMax = new Vector2(0.8f, 0.80f);
        ebR.sizeDelta = Vector2.zero;

        GameObject epInner = new GameObject("Inner", typeof(RectTransform));
        epInner.transform.SetParent(eventPopup.transform, false);
        epInner.AddComponent<Image>().color = Darkest;
        RectTransform eiR = epInner.GetComponent<RectTransform>();
        eiR.anchorMin = new Vector2(0.21f, 0.26f);
        eiR.anchorMax = new Vector2(0.79f, 0.79f);
        eiR.sizeDelta = Vector2.zero;

        eventPopupTitleText = MakeUIText(eventPopup.transform, "PopupTitle", 13, FontStyle.Bold,
                                         Gold, new Vector2(0.22f, 0.72f), new Vector2(0.78f, 0.78f)).GetComponent<Text>();
        eventPopupTitleText.text = "HISTORICAL EVENT";

        eventPopupNameText = MakeUIText(eventPopup.transform, "PopupName", 32, FontStyle.Bold,
                                        Parchment, new Vector2(0.22f, 0.58f), new Vector2(0.78f, 0.70f)).GetComponent<Text>();

        eventPopupDescText = MakeUIText(eventPopup.transform, "PopupDesc", 24, FontStyle.Normal,
                                        Parchment.WithA(0.70f), new Vector2(0.25f, 0.40f), new Vector2(0.75f, 0.55f)).GetComponent<Text>();
        eventPopupDescText.horizontalOverflow = HorizontalWrapMode.Wrap;

        GameObject dimGO = new GameObject("DismissBtn", typeof(RectTransform));
        dimGO.transform.SetParent(eventPopup.transform, false);
        Image dimImg = dimGO.AddComponent<Image>();
        dimImg.color = Med;
        eventDismissBtn = dimGO.AddComponent<Button>();
        eventDismissBtn.targetGraphic = dimImg;
        Navigation dNav = new Navigation();
        dNav.mode = Navigation.Mode.None;
        eventDismissBtn.navigation = dNav;
        RectTransform dimR = dimGO.GetComponent<RectTransform>();
        dimR.anchorMin = new Vector2(0.35f, 0.28f);
        dimR.anchorMax = new Vector2(0.65f, 0.35f);
        dimR.sizeDelta = Vector2.zero;
        MakeUIText(dimGO.transform, "Label", 18, FontStyle.Bold,
                   Parchment, Vector2.zero, Vector2.one).GetComponent<Text>().text = "DISMISS";

        GameObject choiceAGO = new GameObject("ChoiceABtn", typeof(RectTransform));
        choiceAGO.transform.SetParent(eventPopup.transform, false);
        Image choiceAImg = choiceAGO.AddComponent<Image>();
        choiceAImg.color = Med;
        eventChoiceABtn = choiceAGO.AddComponent<Button>();
        eventChoiceABtn.targetGraphic = choiceAImg;
        RectTransform choiceAR = choiceAGO.GetComponent<RectTransform>();
        choiceAR.anchorMin = new Vector2(0.22f, 0.28f);
        choiceAR.anchorMax = new Vector2(0.48f, 0.35f);
        choiceAR.sizeDelta = Vector2.zero;
        MakeUIText(choiceAGO.transform, "Label", 15, FontStyle.Bold,
                   Parchment, Vector2.zero, Vector2.one);
        choiceAGO.SetActive(false);

        GameObject choiceBGO = new GameObject("ChoiceBBtn", typeof(RectTransform));
        choiceBGO.transform.SetParent(eventPopup.transform, false);
        Image choiceBImg = choiceBGO.AddComponent<Image>();
        choiceBImg.color = Med;
        eventChoiceBBtn = choiceBGO.AddComponent<Button>();
        eventChoiceBBtn.targetGraphic = choiceBImg;
        RectTransform choiceBR = choiceBGO.GetComponent<RectTransform>();
        choiceBR.anchorMin = new Vector2(0.52f, 0.28f);
        choiceBR.anchorMax = new Vector2(0.78f, 0.35f);
        choiceBR.sizeDelta = Vector2.zero;
        MakeUIText(choiceBGO.transform, "Label", 15, FontStyle.Bold,
                   Parchment, Vector2.zero, Vector2.one);
        choiceBGO.SetActive(false);
    }
    void SubscribeToEvents()
    {
        if (eventsSubscribed) return;

        endTurnButton.onClick.AddListener(() => GameManager.Instance?.EndPlayerTurn());
        playAgainButton.onClick.AddListener(() => StartCoroutine(FadeOutAndRestart()));
        quitButton.onClick.AddListener(() => Application.Quit());
        cancelTargetBtn.onClick.AddListener(ExitTargetMode);
        combatPopupDismissBtn.onClick.AddListener(() => combatPopup.SetActive(false));
        if (eventChoiceABtn != null) eventChoiceABtn.onClick.AddListener(() => ResolveEventChoice(true));
        if (eventChoiceBBtn != null) eventChoiceBBtn.onClick.AddListener(() => ResolveEventChoice(false));
        // ADDED: UPGRADE 2 - dice choice buttons
        dice1Btn.onClick.AddListener(() => OnDiceChoiceSelected(1));
        dice2Btn.onClick.AddListener(() => OnDiceChoiceSelected(2));
        dice3Btn.onClick.AddListener(() => OnDiceChoiceSelected(3));

        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnLogMessage += AddLogMessage;
            GameManager.Instance.OnGameOver += ShowGameOver;
            GameManager.Instance.OnFactionEliminated += OnFactionEliminated;
            GameManager.Instance.OnTurnChanged += UpdateTurnCounter;
            GameManager.Instance.OnStateChanged += OnGameStateChanged;
            GameManager.Instance.OnYearChanged += UpdateYearDisplay;
            GameManager.Instance.OnSubTurnChanged += UpdateSubTurnDisplay;
            GameManager.Instance.OnHistoricalEventTriggered += ShowEventPopup;
            GameManager.Instance.OnReinforcementPhase += OnReinforcementPhaseChanged;
            GameManager.Instance.OnCombatResolved += OnCombatResolved;
            GameManager.Instance.OnPhaseTimerUpdate += OnPhaseTimerUpdate;
            GameManager.Instance.OnCardPlayed += OnAnyCardPlayed;
            GameManager.Instance.OnTurnChanged += OnTurnChangedUpdateRegionBonus;
            GameManager.Instance.OnMarketRefresh += OnMarketRefreshed;
            GameManager.Instance.OnGoldChanged += OnGoldChanged;
        }
        MapLayerController.OnMapBuilt += OnMapLayerBuilt;

        eventDismissBtn.onClick.AddListener(DismissEventPopup);
        eventsSubscribed = true;
    }
    void UnsubscribeFromEvents()
    {
        if (!eventsSubscribed) return;

        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnLogMessage -= AddLogMessage;
            GameManager.Instance.OnGameOver -= ShowGameOver;
            GameManager.Instance.OnFactionEliminated -= OnFactionEliminated;
            GameManager.Instance.OnTurnChanged -= UpdateTurnCounter;
            GameManager.Instance.OnStateChanged -= OnGameStateChanged;
            GameManager.Instance.OnYearChanged -= UpdateYearDisplay;
            GameManager.Instance.OnSubTurnChanged -= UpdateSubTurnDisplay;
            GameManager.Instance.OnHistoricalEventTriggered -= ShowEventPopup;
            GameManager.Instance.OnReinforcementPhase -= OnReinforcementPhaseChanged;
            GameManager.Instance.OnCombatResolved -= OnCombatResolved;
            GameManager.Instance.OnPhaseTimerUpdate -= OnPhaseTimerUpdate;
            GameManager.Instance.OnCardPlayed -= OnAnyCardPlayed;
            GameManager.Instance.OnTurnChanged -= OnTurnChangedUpdateRegionBonus;
            GameManager.Instance.OnMarketRefresh -= OnMarketRefreshed;
            GameManager.Instance.OnGoldChanged -= OnGoldChanged;
        }
        MapLayerController.OnMapBuilt -= OnMapLayerBuilt;

        eventsSubscribed = false;
    }
    void OnTurnChangedUpdateRegionBonus(int turn)
    {
        UpdateRegionBonusDisplay();
    }
    void OnReinforcementPhaseChanged(int remaining)
    {
        if (remaining > 0)
            ShowReinforcementPanel(remaining);
        else
            UpdateReinforcementPanel(0);
        UpdateTerritoryMap();
        UpdateMapClickZones();
    }
    void OnCombatResolved(CombatResult result, TerritoryData source, TerritoryData target)
    {
        ShowCombatPopup(result, source, target);
        ShowCombatResultBanner(result, source, target);
        if (result.territoryCaptured) StartCoroutine(ShakeCamera());
        UpdateTerritoryMap();
    }
    void OnGoldChanged(FactionData faction)
    {
        if (faction == GameManager.Instance?.GetPlayerFaction())
            RefreshMarketUI();
    }
    void UpdateSubTurnDisplay(int subTurn)
    {
        if (subTurnText == null) return;
        int maxSt = GameManager.MAX_SUB_TURNS;
        int pct = Mathf.RoundToInt((float)subTurn / maxSt * 100f);
        subTurnText.text = $"{subTurn}/{maxSt} days ({pct}%)";
        subTurnText.color = pct < 50
        ? Parchment.WithA(0.45f)
        : pct < 85
        ? Gold.WithA(0.65f)
        : new Color(0.80f, 0.30f, 0.10f);
    }
    void ShowEventPopup(string eventName, string description)
    {
        if (eventPopup == null) return;
        eventPopupNameText.text = eventName;
        eventPopupDescText.text = description;
        HistoricalEvent activeEvent = HistoricalEventManager.ActiveEvent;
        bool choiceEvent = activeEvent != null && activeEvent.requiresPlayerChoice;
        if (eventDismissBtn != null) eventDismissBtn.gameObject.SetActive(!choiceEvent);
        if (eventChoiceABtn != null)
        {
            eventChoiceABtn.gameObject.SetActive(choiceEvent);
            Text label = eventChoiceABtn.transform.Find("Label")?.GetComponent<Text>();
            if (label != null) label.text = activeEvent != null ? activeEvent.choiceALabel : "CHOICE A";
        }
        if (eventChoiceBBtn != null)
        {
            eventChoiceBBtn.gameObject.SetActive(choiceEvent);
            Text label = eventChoiceBBtn.transform.Find("Label")?.GetComponent<Text>();
            if (label != null) label.text = activeEvent != null ? activeEvent.choiceBLabel : "CHOICE B";
        }
        if (eventOverlay != null) eventOverlay.SetActive(true);
        eventPopup.SetActive(true);
        EnableCardInteractions(false);
    }
    void ResolveEventChoice(bool isChoiceA)
    {
        if (GameManager.Instance != null)
            HistoricalEventManager.ResolveChoice(GameManager.Instance, isChoiceA);
        DismissEventPopup();
    }
    void DismissEventPopup()
    {
        if (eventPopup == null) return;
        if (eventOverlay != null) eventOverlay.SetActive(false);
        eventPopup.SetActive(false);
        if (GameManager.Instance != null)
            GameManager.Instance.IsWaitingForEventDismiss = false;
    }
    void UpdateTurnCounter(int turn)
    {
        if (turnCounterText != null)
            turnCounterText.text = $"Turn {turn} | {GameManager.Instance.CurrentYear} AD";
        StartCoroutine(PulseTurnCounter());
    }
    IEnumerator PulseTurnCounter()
    {
        if (turnCounterText == null) yield break;
        RectTransform rt = turnCounterText.GetComponent<RectTransform>();
        float t = 0f;
        while (t < 0.3f) {
            t += Time.deltaTime;
            float s = 1f + Mathf.Sin(t / 0.3f * Mathf.PI) * 0.15f;
            rt.localScale = Vector3.one * s;
            yield return null;
        }
        rt.localScale = Vector3.one;
    }
    void UpdateYearDisplay(int year)
    {
        if (yearProgressText == null || GameManager.Instance == null) return;
        int turnsLeft = GameManager.MAX_TURNS - GameManager.Instance.currentTurn;
        int yearsLeft = GameManager.END_YEAR - year;
        yearProgressText.text = $"{turnsLeft} turns | {yearsLeft} years to {GameManager.END_YEAR} AD";
        yearProgressText.color = turnsLeft < 50 ? new Color(0.85f, 0.40f, 0.10f) : Parchment.WithA(0.65f);
    }
    public void OnGameStateChanged(GameState state)
    {
        ApplyPhaseVisibility(state);

        switch (state)
        {
            case GameState.DRAW_PHASE:
                AddLogMessage("\u2500\u2500 DRAW PHASE: Cards are being dealt. Wait for PLAY PHASE to act.");
                break;
            case GameState.PLAY_PHASE:
                AddLogMessage("\u2500\u2500 PLAY PHASE: Click a card to play it, or click END TURN.");
                break;
            case GameState.REINFORCEMENT_PHASE:
                AddLogMessage("\u2500\u2500 REINFORCEMENT PHASE: Click your territories on the map to place troops, then CONFIRM.");
                break;
            case GameState.ATTACK_PHASE:
                AddLogMessage("\u2500\u2500 ATTACK PHASE: Click one of your territories (with 2+ troops) to attack from.");
                break;
            case GameState.FORTIFY_PHASE:
                AddLogMessage("\u2500\u2500 FORTIFY PHASE: Move troops between adjacent territories, or END TURN.");
                break;
            case GameState.RESOLUTION_PHASE:
                AddLogMessage("\u2500\u2500 RESOLUTION: Cards are being resolved...");
                break;
        }

        // When entering DRAW_PHASE, refresh the hand and enforce sibling order
        // so HandArea renders above market/probability panels.
        if (state == GameState.DRAW_PHASE || state == GameState.PLAY_PHASE)
        {
            RefreshHandUI();
            EnforceDrawOrder();
        }
        UpdateEndTurnButtonState(state);
        UpdateCardsRemaining();

        HideAttackArrow();

        switch (state)
        {
            case GameState.REINFORCEMENT_PHASE:
                EnterReinforcementPhaseUI();
                break;
            case GameState.DRAW_PHASE:
                EnterDrawPhaseUI();
                break;
            case GameState.PLAY_PHASE:
                EnterPlayPhaseUI();
                break;
            case GameState.RESOLUTION_PHASE:
                EnterResolutionPhaseUI();
                break;
            case GameState.ATTACK_PHASE:
                EnterAttackPhaseUI();
                break;
            case GameState.FORTIFY_PHASE:
                EnterFortifyPhaseUI();
                break;
            case GameState.GAME_OVER:
                EnterGameOverPhaseUI();
                break;
        }
    }
    void EnterReinforcementPhaseUI()
    {
        ShowPhase("\u2694  REINFORCEMENT PHASE \u2014 Click map to place troops", new Color(0.55f, 0.35f, 0.05f), 6f);
        UpdateTerritoryMap();
    }
    void EnterDrawPhaseUI()
    {
        ShowPhase("\u2726  DRAW PHASE", Gold);
        RefreshProbabilityForCurrentPlayer();
    }
    void EnterPlayPhaseUI()
    {
        ShowPhase("\u25B6  PLAY PHASE", new Color(0.3f, 0.7f, 0.3f));
        RefreshProbabilityForCurrentPlayer();
        UpdateTerritoryMap();
    }
    void EnterResolutionPhaseUI()
    {
        ShowPhase("\u25CF  RESOLUTION", new Color(0.8f, 0.2f, 0.1f));
        if (probabilityPanel != null) probabilityPanel.SetActive(false);
    }
    void EnterAttackPhaseUI()
    {
        ShowPhase("\u2694  ATTACK PHASE", new Color(0.8f, 0.2f, 0.1f));
        if (probabilityPanel != null) probabilityPanel.SetActive(false);
    }
    void EnterFortifyPhaseUI()
    {
        ShowPhase("\u27F3  FORTIFY PHASE", new Color(0.6f, 0.4f, 0.1f));
        if (probabilityPanel != null) probabilityPanel.SetActive(false);
        ShowFortifyPanel();
    }
    void EnterGameOverPhaseUI()
    {
        ShowPhase("\u2605  GAME OVER", new Color(0.5f, 0.0f, 0.5f));
    }
    void ShowPhase(string label, Color color, float duration = 1.8f)
    {
        if (phaseBannerCoroutine != null)
        {
            StopCoroutine(phaseBannerCoroutine);
            phaseBannerCoroutine = null;
        }
        if (phaseBanner != null) phaseBanner.SetActive(false);
        phaseBannerCoroutine = StartCoroutine(ShowPhaseBanner(label, color, duration));
    }
    void RefreshProbabilityForCurrentPlayer()
    {
        if (GameManager.Instance == null) return;
        FactionData player = GameManager.Instance.GetPlayerFaction();
        if (player == null) return;

        var weights = CardProbabilitySystem.GetAdjustedWeights(
            player,
            GameManager.Instance.factions,
            GameManager.Instance.territories,
            GameManager.Instance.currentTurn);
        UpdateProbabilityDisplay(weights);
    }
    void ApplyPhaseVisibility(GameState state)
    {
        bool gameOver = state == GameState.GAME_OVER;
        bool shellVisible = !gameOver;
        bool drawPhase = state == GameState.DRAW_PHASE;
        bool playPhase = state == GameState.PLAY_PHASE;
        bool reinforcePhase = state == GameState.REINFORCEMENT_PHASE;
        bool resolutionPhase = state == GameState.RESOLUTION_PHASE;
        bool fortifyPhase = state == GameState.FORTIFY_PHASE;
        bool mapVisible = shellVisible;
        bool attackPhase = state == GameState.ATTACK_PHASE;
        bool tacticalMapPhase = reinforcePhase || playPhase || resolutionPhase || fortifyPhase;

        SetActiveIfExists(topBar, shellVisible);
        SetActiveIfExists(rightPanelBg, shellVisible);
        SetActiveIfExists(mapAreaBg, mapVisible);
        SetActiveIfExists(mapFrame, mapVisible);
        SetActiveIfExists(territoryMapPanel, mapVisible);
        SetActiveIfExists(mapClickZonesRoot, shellVisible);
        SetActiveIfExists(factionArea, shellVisible);
        SetActiveIfExists(logArea, shellVisible);
        SetActiveIfExists(handArea, reinforcePhase || drawPhase || playPhase);
        SetActiveIfExists(playedArea, playPhase || resolutionPhase);
        SetActiveIfExists(endTurnRoot, playPhase || fortifyPhase);
        SetActiveIfExists(cardsRemainingRoot, drawPhase || playPhase);
        SetActiveIfExists(regionBonusPanel, reinforcePhase || playPhase || fortifyPhase);
        bool attackSelection = waitingForTerritoryAttackSource || waitingForTerritoryAttackTarget;
        if (probabilityPanel != null)
            probabilityPanel.SetActive((drawPhase || playPhase) && !attackSelection);

        if (marketToggleBtn != null) marketToggleBtn.SetActive(playPhase);
        if (economyToggleButton != null) economyToggleButton.gameObject.SetActive(playPhase);

        if (!playPhase)
        {
            marketVisible = false;
            if (marketPanel != null) marketPanel.SetActive(false);
            if (EconomyUI.Instance != null) EconomyUI.Instance.Hide();
            HideTooltip();
            ExitTargetMode();
            ExitTerritoryAttackMode();
        }

        if (reinforcePhase && factionArea != null)
            factionArea.transform.SetAsLastSibling();
        if (reinforcePhase && reinforcementPanel != null)
            reinforcementPanel.transform.SetAsLastSibling();
        if (reinforcePhase && mapClickZonesRoot != null)
            mapClickZonesRoot.transform.SetAsLastSibling();

        if (!reinforcePhase && reinforcementPanel != null)
            reinforcementPanel.SetActive(false);

        if (!fortifyPhase)
            HideFortifyPanel();

        if (!resolutionPhase && combatPopup != null)
        {
            if (combatAutoDismiss != null)
            {
                StopCoroutine(combatAutoDismiss);
                combatAutoDismiss = null;
            }
            combatPopup.SetActive(false);
        }

        SetActiveIfExists(expandBtnRoot, playPhase);
        if (playPhase && endTurnRoot != null && !endTurnRoot.activeSelf)
            endTurnRoot.SetActive(true);

        if (gameOver)
        {
            HideAttackArrow();
            HideTerritoryTooltip();
            HideAttackStatus();
        }

        UpdateMapClickZones();
    }
    bool CanUseActionPanels()
    {
        return GameManager.Instance != null && GameManager.Instance.currentState == GameState.PLAY_PHASE;
    }
    void SetActiveIfExists(GameObject go, bool active)
    {
        if (go != null && go.activeSelf != active)
            go.SetActive(active);
    }
    void UpdateEndTurnButtonState(GameState state)
    {
        bool interactable = state == GameState.PLAY_PHASE || state == GameState.FORTIFY_PHASE;
        endTurnButton.interactable = interactable;
        if (endTurnButtonImage == null) return;

        if (state == GameState.PLAY_PHASE)
        {
            bool maxed = GameManager.Instance != null &&
            GameManager.Instance.CardsPlayedThisTurn >= GameManager.Instance.MaxCardsPerTurn;
            endTurnButtonImage.color = maxed
            ? new Color(0.38f, 0.05f, 0.03f)
            : new Color(0.48f, 0.08f, 0.04f);
            if (endTurnLabel != null) endTurnLabel.text = maxed ? "END TURN" : "END TURN";
        }
        else if (state == GameState.FORTIFY_PHASE)
        {
            endTurnButtonImage.color = new Color(0.35f, 0.20f, 0.05f);
            if (endTurnLabel != null) endTurnLabel.text = "SKIP FORTIFY";
        }
        else
        {
            endTurnButtonImage.color = new Color(0.15f, 0.06f, 0.03f);
            if (endTurnLabel != null)
                endTurnLabel.text = state == GameState.RESOLUTION_PHASE ? "RESOLVING..."
                : state == GameState.DRAW_PHASE ? "DRAWING..."
                : state == GameState.REINFORCEMENT_PHASE ? "REINFORCING..."
                : "END TURN";
        }
    }
    public void OnPhaseTimerUpdate(float timeLeft)
    {
        if (phaseTimerBar == null) return;
        if (timeLeft <= 0f)
        {
            phaseTimerBar.gameObject.SetActive(false);
            return;
        }
        phaseTimerBar.gameObject.SetActive(true);
        float pct = timeLeft / GameManager.PHASE_TIME_LIMIT;
        phaseTimerBar.rectTransform.anchorMax = new Vector2(pct * 0.99f + 0.01f, 0.06f);
        float urgency = Mathf.Clamp01(1f - (timeLeft / 10f));
        phaseTimerBar.color = Color.Lerp(
            new Color(0.75f, 0.45f, 0.08f, 0.75f),
            new Color(0.55f, 0.07f, 0.05f, 0.9f),
            urgency);
    }
    IEnumerator PulseEndTurnButton()
    {
        if (endTurnButton == null) yield break;
        Image btnImg = endTurnButton.GetComponent<Image>();
        if (btnImg == null) yield break;
        Color original = btnImg.color;
        Color pulse = new Color(0.85f, 0.65f, 0.10f);
        for (int i = 0; i < 3; i++)
        {
            float t = 0f;
            while (t < 0.3f) {
                t += Time.deltaTime;
                btnImg.color = Color.Lerp(original, pulse, Mathf.Sin(t/0.3f * Mathf.PI));
                yield return null;
            }
            btnImg.color = original;
            yield return new WaitForSeconds(0.2f);
        }
    }
    void ShowGameOver(bool playerWon)
    {
        HideTooltip();
        FactionData winner = GameManager.Instance.factions.Find(f => !f.isEliminated);
        FactionData playerFaction = GameManager.Instance.GetPlayerFaction();
        string factionName = playerFaction != null ? playerFaction.factionName : "";
        Image panelBg = gameOverPanel.GetComponent<Image>();
        if (playerWon)
        {
            panelBg.color = winner != null
                ? new Color(winner.factionColor.r * 0.3f, winner.factionColor.g * 0.3f,
                            winner.factionColor.b * 0.3f, 0.95f)
                : Darkest;
            gameOverTitleText.text = "VICTORY";
            gameOverTitleText.color = Gold;
            int owned = winner != null
                ? GameManager.Instance.territories.Count(t => t.controlledBy == winner.factionId)
                : 0;
            gameOverSubtitleText.text = $"{factionName} rules the shadows of Europe — {owned} territories";
            gameOverSubtitleText.color = Parchment.WithA(0.65f);
        }
        else
        {
            panelBg.color = winner != null
                ? new Color(winner.factionColor.r * 0.3f, winner.factionColor.g * 0.3f,
                            winner.factionColor.b * 0.3f, 0.95f)
                : new Color(0.08f, 0.01f, 0.01f);
            gameOverTitleText.text = "ELIMINATED";
            gameOverTitleText.color = new Color(0.80f, 0.10f, 0.05f);
            int owned = winner != null
                ? GameManager.Instance.territories.Count(t => t.controlledBy == winner.factionId)
                : 0;
            gameOverSubtitleText.text = winner != null
                ? $"{winner.factionName} wins with {owned} territories"
                : "The shadows swallow you whole";
            gameOverSubtitleText.color = Parchment.WithA(0.50f);
        }
        gameOverDivider.gameObject.SetActive(true);
        gameOverCanvasGroup.alpha = 0f;
        gameOverCanvasGroup.blocksRaycasts = true;
        gameOverPanel.SetActive(true);
        StartCoroutine(FadeInGameOver());
    }
    IEnumerator FadeInGameOver()
    {
        for (float e = 0; e < 0.5f; e += Time.deltaTime)
        {
            gameOverCanvasGroup.alpha = Mathf.Lerp(0f, 1f, e / 0.5f);
            yield return null;
        }
        gameOverCanvasGroup.alpha = 1f;
    }
    IEnumerator FadeOutAndRestart()
    {
        for (float e = 0; e < 0.3f; e += Time.deltaTime)
        {
            gameOverCanvasGroup.alpha = Mathf.Lerp(1f, 0f, e / 0.3f);
            yield return null;
        }
        gameOverCanvasGroup.alpha = 0f;
        gameOverCanvasGroup.blocksRaycasts = false;
        gameOverPanel.SetActive(false);
        GameManager.Instance.RestartGame();
    }
    void BuildProbabilityPanel(Transform ct)
    {
        probabilityPanel = new GameObject("ProbabilityPanel", typeof(RectTransform));
        probabilityPanel.transform.SetParent(ct, false);
        Image ppBg = probabilityPanel.AddComponent<Image>();
        ppBg.color = new Color(0.04f, 0.02f, 0.01f, 0.82f);
        ppBg.raycastTarget = false;
        RectTransform probabilityRect = probabilityPanel.GetComponent<RectTransform>();
        Anchor(probabilityRect, 0.00f, 0.68f, 0.18f, 1.00f);
        probabilityRect.pivot = new Vector2(0f, 1f);
        probabilityRect.anchoredPosition = Vector2.zero;

        MakeUIText(probabilityPanel.transform, "Title", 9, FontStyle.Bold,
                   Gold, new Vector2(0.05f, 0.90f), new Vector2(0.95f, 0.99f))
            .GetComponent<Text>().text = "DRAW ODDS";

        MakeHRule(probabilityPanel.transform, new Vector2(0.05f, 0.86f), new Vector2(0.95f, 0.87f),
                  Gold.WithA(0.30f));

        float rowHeight = 0.12f;
        float startY = 0.80f;
        CardType[] allTypes = new CardType[] {
            CardType.ATTACK, CardType.DEFENSE, CardType.INFLUENCE,
            CardType.SABOTAGE, CardType.FARMING, CardType.BLACK_MARKET
        };

        Color[] typeColors = new Color[] {
            new Color(0.8f, 0.2f, 0.2f),
            new Color(0.2f, 0.4f, 0.9f),
            new Color(0.8f, 0.7f, 0.1f),
            new Color(0.5f, 0.1f, 0.7f),
            new Color(0.2f, 0.7f, 0.3f),
            new Color(0.6f, 0.4f, 0.1f)
        };

        for (int i = 0; i < allTypes.Length; i++)
        {
            CardType type = allTypes[i];
            Color color = typeColors[i];
            float yMin = startY - (i + 1) * rowHeight;
            float yMax = startY - i * rowHeight;

            GameObject row = new GameObject("Row_" + type, typeof(RectTransform));
            row.transform.SetParent(probabilityPanel.transform, false);
            Anchor(row.GetComponent<RectTransform>(), 0.02f, yMin, 0.98f, yMax);

            GameObject dot = new GameObject("Dot", typeof(RectTransform));
            dot.transform.SetParent(row.transform, false);
            Image dotImg = dot.AddComponent<Image>();
            dotImg.color = color;
            dotImg.raycastTarget = false;
            RectTransform dotR = dot.GetComponent<RectTransform>();
            dotR.anchorMin = new Vector2(0f, 0.2f);
            dotR.anchorMax = new Vector2(0f, 0.8f);
            dotR.sizeDelta = new Vector2(8, 0);
            dotR.anchoredPosition = new Vector2(4, 0);

            Text labelText = MakeUIText(row.transform, "Label", 8, FontStyle.Bold,
                Parchment, new Vector2(0.12f, 0f), new Vector2(0.48f, 1f)).GetComponent<Text>();
            labelText.text = type.ToString();
            labelText.alignment = TextAnchor.MiddleLeft;

            GameObject barBg = new GameObject("BarBg", typeof(RectTransform));
            barBg.transform.SetParent(row.transform, false);
            Image barBgImg = barBg.AddComponent<Image>();
            barBgImg.color = new Color(0.05f, 0.03f, 0.01f);
            barBgImg.raycastTarget = false;
            RectTransform barBgR = barBg.GetComponent<RectTransform>();
            barBgR.anchorMin = new Vector2(0.50f, 0.15f);
            barBgR.anchorMax = new Vector2(0.92f, 0.85f);
            barBgR.sizeDelta = Vector2.zero;

            GameObject barFill = new GameObject("BarFill", typeof(RectTransform));
            barFill.transform.SetParent(barBg.transform, false);
            Image barFillImg = barFill.AddComponent<Image>();
            barFillImg.color = color;
            barFillImg.raycastTarget = false;
            RectTransform barFillR = barFill.GetComponent<RectTransform>();
            barFillR.anchorMin = Vector2.zero;
            barFillR.anchorMax = new Vector2(0f, 1f);
            barFillR.sizeDelta = Vector2.zero;

            row.GetComponent<RectTransform>().sizeDelta = Vector2.zero;
            probabilityRows[type] = row;
        }

        probabilityPanel.SetActive(false);
    }
    public void UpdateProbabilityDisplay(Dictionary<CardType, float> weights)
    {
        if (probabilityPanel == null) return;

        bool isDrawOrPlay = GameManager.Instance != null &&
            (GameManager.Instance.currentState == GameState.DRAW_PHASE ||
             GameManager.Instance.currentState == GameState.PLAY_PHASE) &&
            !waitingForTerritoryAttackSource &&
            !waitingForTerritoryAttackTarget;
        probabilityPanel.SetActive(isDrawOrPlay);

        if (!isDrawOrPlay || weights == null) return;

        foreach (var kvp in probabilityRows)
        {
            CardType type = kvp.Key;
            GameObject row = kvp.Value;
            if (row == null) continue;

            float pct = weights.ContainsKey(type) ? weights[type] : 0f;

            Text pctText = row.transform.Find("Label")?.GetComponent<Text>();
            if (pctText != null)
                pctText.text = $"{type.ToString()} {Mathf.RoundToInt(pct)}%";

            Transform barBg = row.transform.Find("BarBg");
            if (barBg == null) continue;
            Transform barFill = barBg.Find("BarFill");
            if (barFill == null) continue;

            RectTransform barFillR = barFill.GetComponent<RectTransform>();
            float targetWidth = pct / 100f;
            if (probabilityBarAnim != null) StopCoroutine(probabilityBarAnim);
            probabilityBarAnim = StartCoroutine(AnimateBarWidth(barFillR, targetWidth));
        }

        CardType dominant = weights.OrderByDescending(kv => kv.Value).First().Key;
        float dominantWeight = weights[dominant];
        probabilityHistory.Add(dominantWeight);
        if (probabilityHistory.Count > 10)
            probabilityHistory.RemoveAt(0);
        Color lineColor = GetTypeColor(dominant);
        UpdateSparklineChart(lineColor);
    }
    IEnumerator AnimateBarWidth(RectTransform bar, float target)
    {
        float start = bar.anchorMax.x;
        float elapsed = 0f;
        float duration = 0.3f;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            bar.anchorMax = new Vector2(Mathf.Lerp(start, target, t), 1f);
            yield return null;
        }
        bar.anchorMax = new Vector2(target, 1f);
    }
}
