using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public partial class GameUIManager : MonoBehaviour
{
    void BuildTerritoryMapPanel(Transform ct)
    {
        territoryMapPanel = new GameObject("TerritoryMapPanel", typeof(RectTransform));
        territoryMapPanel.transform.SetParent(ct, false);
        Image tpBg = territoryMapPanel.AddComponent<Image>();
        tpBg.color = Color.clear;
        tpBg.raycastTarget = false;
        Anchor(territoryMapPanel.GetComponent<RectTransform>(), MapAnchorMin.x, MapAnchorMin.y, MapAnchorMax.x, MapAnchorMax.y);

        GameObject zoomOverlay = new GameObject("ZoomOverlay", typeof(RectTransform));
        zoomOverlay.transform.SetParent(ct, false);
        Image zoImg = zoomOverlay.AddComponent<Image>();
        zoImg.color = Color.clear;
        zoImg.raycastTarget = false;
        Anchor(zoomOverlay.GetComponent<RectTransform>(), MapAnchorMin.x, MapAnchorMin.y, MapAnchorMax.x, MapAnchorMax.y);
        ZoomController zoomCtrl = zoomOverlay.AddComponent<ZoomController>();
        zoomCtrl.Setup(canvas, null);
        StartCoroutine(AssignZoomTarget(zoomCtrl));
    }
    IEnumerator AssignZoomTarget(ZoomController zoomCtrl)
    {
        while (MapLayerController.Instance == null || MapLayerController.Instance.MapImage == null)
            yield return null;
        zoomCtrl.SetTarget(MapLayerController.Instance.MapImage.GetComponent<RectTransform>());
    }
    void CreateTerritoryMapEntry(Transform parent, string territoryName, string region)
    {
        if (_lastSidebarRegion != region)
        {
            _lastSidebarRegion = region;
            Text regionLabel = MakeUIText(parent, "Region_" + region, 9, FontStyle.Bold,
                Gold.WithA(0.5f), new Vector2(0.03f, 0f), new Vector2(0.97f, 1f)).GetComponent<Text>();
            regionLabel.text = "— " + region.ToUpper() + " —";
            LayoutElement regionLayout = regionLabel.gameObject.AddComponent<LayoutElement>();
            regionLayout.preferredHeight = 18;
        }
        GameObject entry = new GameObject("Terr_" + territoryName.Replace(" ", ""), typeof(RectTransform));
        entry.transform.SetParent(parent, false);
        entry.AddComponent<Image>().color = Dark;
        entry.GetComponent<Image>().raycastTarget = false;

        RectTransform eR = entry.GetComponent<RectTransform>();
        eR.sizeDelta = new Vector2(0, 22);
        LayoutElement entryLayout = entry.AddComponent<LayoutElement>();
        entryLayout.preferredHeight = 22;

        GameObject colorDot = new GameObject("ColorDot", typeof(RectTransform));
        colorDot.transform.SetParent(entry.transform, false);
        Image dotImg = colorDot.AddComponent<Image>();
        dotImg.color = Color.gray;
        dotImg.raycastTarget = false;
        RectTransform dotR = colorDot.GetComponent<RectTransform>();
        dotR.anchorMin = new Vector2(0.03f, 0.15f);
        dotR.anchorMax = new Vector2(0.03f, 0.85f);
        dotR.sizeDelta = new Vector2(6, 0);
        dotR.anchoredPosition = Vector2.zero;

        Text nameText = MakeUIText(entry.transform, "Name", 11, FontStyle.Bold,
                                   Parchment, new Vector2(0.12f, 0.45f), new Vector2(0.75f, 0.95f)).GetComponent<Text>();
        nameText.text = territoryName;
        nameText.alignment = TextAnchor.LowerLeft;

        Text troopsText = MakeUIText(entry.transform, "Troops", 10, FontStyle.Bold,
                                     Gold, new Vector2(0.73f, 0.05f), new Vector2(0.98f, 0.55f)).GetComponent<Text>();
        troopsText.text = "";
        troopsText.alignment = TextAnchor.MiddleRight;

        if (GameManager.Instance != null && GameManager.Instance.territories != null)
        {
            TerritoryData tData = GameManager.Instance.territories.Find(t => t.name == territoryName);
            if (tData != null)
            {
                UpdateTerritoryMapEntry(entry, tData);
            }
        }

        territoryMapEntries[territoryName] = entry;
    }
    void UpdateTerritoryMapEntry(GameObject entry, TerritoryData tData)
    {
        if (entry == null) return;

        Image dotImg = entry.transform.Find("ColorDot")?.GetComponent<Image>();
        Text troopsText = entry.transform.Find("Troops")?.GetComponent<Text>();

        Color ownerColor = Color.gray;
        if (tData.controlledBy >= 0 && tData.controlledBy < GameManager.Instance.factions.Count)
            ownerColor = GameManager.Instance.factions[tData.controlledBy].factionColor;

        if (dotImg != null)
            dotImg.color = ownerColor;

        if (troopsText != null)
        {
            if (tData.controlledBy >= 0)
            {
                troopsText.text = tData.troops.ToString();
                troopsText.color = tData.troops >= 20 ? new Color(0.9f, 0.2f, 0.2f)
                    : tData.troops >= 10 ? new Color(0.9f, 0.6f, 0.1f)
                    : tData.troops >= 5 ? new Color(0.8f, 0.8f, 0.3f)
                    : new Color(0.7f, 0.7f, 0.5f);
            }
            else
                troopsText.text = "-";
        }

        if (previousTroopCounts.TryGetValue(tData.name, out int prev) && prev != tData.troops)
            StartCoroutine(PulseTerritoryEntry(entry));
        previousTroopCounts[tData.name] = tData.troops;

        Button btn = entry.GetComponent<Button>();
        if (btn == null)
        {
            btn = entry.AddComponent<Button>();
            btn.targetGraphic = entry.GetComponent<Image>();
            Navigation nav = new Navigation();
            nav.mode = Navigation.Mode.None;
            btn.navigation = nav;
        }

        TerritoryData captured = tData;
        btn.onClick.RemoveAllListeners();
        btn.onClick.AddListener(() => OnTerritoryClicked(captured));

        TerritoryClickHandler rch = entry.GetComponent<TerritoryClickHandler>();
        if (rch == null)
        {
            rch = entry.AddComponent<TerritoryClickHandler>();
            rch.onRightClick = OnTerritoryRightClicked;
        }
        rch.territory = captured;
    }
    void OnDiceChoiceSelected(int diceCount)
    {
        if (pendingAttackSourceTerritory == null)
        {
            ExitTerritoryAttackMode();
            return;
        }

        int maxDice = Mathf.Clamp(pendingAttackSourceTerritory.troops - 1, 1, 3);
        GameManager.Instance.pendingAttackerDiceCount = Mathf.Clamp(diceCount, 1, maxDice);
        GameManager.Instance.pendingAttackerTroopCount = troopSlider != null ? Mathf.RoundToInt(troopSlider.value) : 1;
        diceChoicePopup.SetActive(false);
        CardData card = pendingCard;
        TerritoryData source = pendingAttackSourceTerritory;
        EnterTerritoryAttackTargetMode(card, source);
    }
    void ConfigureDiceChoiceButtons(TerritoryData source)
    {
        int maxDice = source != null ? Mathf.Clamp(source.troops - 1, 1, 3) : 1;
        if (dice1Btn != null) dice1Btn.interactable = maxDice >= 1;
        if (dice2Btn != null) dice2Btn.interactable = maxDice >= 2;
        if (dice3Btn != null) dice3Btn.interactable = maxDice >= 3;

        if (troopSlider != null)
        {
            int maxTroops = source != null ? Mathf.Clamp(source.troops - 1, 1, 5) : 1;
            troopSlider.maxValue = maxTroops;
            troopSlider.value = Mathf.Min(troopSlider.value, maxTroops);
        }
    }
    void OnTerritoryClicked(TerritoryData territory)
    {
        if (territory == null || GameManager.Instance == null) return;

        if (GameManager.Instance.IsWaitingForReinforcements)
        {
            FactionData player = GameManager.Instance.GetPlayerFaction();
            if (player != null && territory.controlledBy == player.factionId)
            {
                GameManager.Instance.AssignReinforcementToTerritory(territory, 1);
            }
            else
            {
                AddLogMessage("You can only reinforce territories you already control.");
            }
            return;
        }

        if (GameManager.Instance.currentState == GameState.FORTIFY_PHASE)
        {
            FactionData player = GameManager.Instance.GetPlayerFaction();
            if (player == null) return;
            if (waitingForFortifySource)
            {
                if (territory.controlledBy == player.factionId && territory.troops > 1)
                {
                    pendingFortifySource = territory;
                    waitingForFortifySource = false;
                    waitingForFortifyTarget = true;
                    ClearTerritoryHighlights();
                    ShowFortifyPathArrows(territory, player.factionId);
                    if (territoryMapEntries.ContainsKey(territory.name))
                    {
                        Image bg = territoryMapEntries[territory.name].GetComponent<Image>();
                        if (bg != null) bg.color = new Color(0.20f, 0.40f, 0.20f);
                    }
                    AddLogMessage($"Select a friendly territory to move troops to from {territory.name}...");
                    if (fortifyInstructionText != null)
                        fortifyInstructionText.text = $"Select destination from {territory.name}";
                }
                else
                {
                    AddLogMessage("Select a territory you own with at least 2 troops.");
                }
                return;
            }
            // ADDED: UPGRADE 3 - show slider for troop count instead of moving all
            if (waitingForFortifyTarget)
            {
                if (IsValidFortifyDestination(pendingFortifySource, territory, player.factionId))
                {
                    pendingFortifyDest = territory;
                    waitingForFortifyTarget = false;
                    int maxMove = pendingFortifySource.troops - 1;
                    fortifyInstructionText.text = $"Move how many troops from {pendingFortifySource.name} to {territory.name}?";
                    ShowFortifyCountSlider(maxMove);
                }
                else
                {
                    AddLogMessage("Select a different friendly territory.");
                }
                return;
            }
        }

        if (waitingForNeutralExpandSource)
        {
            FactionData player = GameManager.Instance.GetPlayerFaction();
            if (territory.controlledBy == player.factionId && territory.troops >= 10)
            {
                pendingExpandSource = territory;
                waitingForNeutralExpandSource = false;
                waitingForNeutralExpandTarget = true;
                AddLogMessage($"EXPAND: Select an adjacent neutral territory to claim from {territory.name}.");
                UpdateMapClickZones();
            }
            else AddLogMessage("Select a territory you own with at least 10 troops.");
            return;
        }

        if (waitingForNeutralExpandTarget)
        {
            if (territory.controlledBy == -1 &&
                TerritoryGraph.AreAdjacent(pendingExpandSource.name, territory.name))
            {
                bool ok = GameManager.Instance.ExpandToNeutral(pendingExpandSource, territory);
                AddLogMessage(ok ? $"Expanded into {territory.name}!" : "Expansion failed.");
                if (ok) UpdateTerritoryMap();
            }
            else if (territory.controlledBy != -1)
                AddLogMessage("Select a neutral (unowned) territory.");
            else
                AddLogMessage($"{territory.name} is not adjacent to {pendingExpandSource?.name}.");

            waitingForNeutralExpandTarget = false;
            pendingExpandSource = null;
            UpdateMapClickZones();
            return;
        }

        if (waitingForTerritoryAttackSource)
        {
            FactionData player = GameManager.Instance.GetPlayerFaction();
            if (player != null && territory.controlledBy == player.factionId && territory.troops > 1)
            {
                pendingAttackSourceTerritory = territory;
                waitingForTerritoryAttackSource = false;
                diceChoiceTitle.text = $"ATTACK FROM {territory.name}";
                ConfigureDiceChoiceButtons(territory);
                diceChoicePopup.SetActive(true);
                ShowAttackStatus($"Choose attack dice for {territory.name}");
                return;
            }

            AddLogMessage("Select a territory you own with at least 2 troops.");
            return;
        }

        if (waitingForTerritoryAttackTarget)
        {
            FactionData player = GameManager.Instance.GetPlayerFaction();
            if (territory.controlledBy != player.factionId)
            {
                // Adjacency guard — mirrors AttackPhaseUI fix
                List<string> adjCheck = ProvinceGraph.GetAttackNeighbours(pendingAttackSourceTerritory.name);
                if (!adjCheck.Contains(territory.name))
                {
                    AddLogMessage($"{territory.name} is not adjacent to {pendingAttackSourceTerritory.name}.");
                    return;
                }

                CardData card = pendingCard;
                TerritoryData source = pendingAttackSourceTerritory;
                int chosenDice = GameManager.Instance.pendingAttackerDiceCount;
                ExitTerritoryAttackMode();
                GameManager.Instance.pendingAttackerDiceCount = chosenDice;
                if (card != null)
                    StartCoroutine(AnimateCardPlay(card, pendingCardPosition));
                GameManager.Instance.PlayTerritoryAttackCard(card, source, territory);
                ShowAttackArrow(source, territory);
                if (TerritoryGraphRenderer.Instance != null)
                    TerritoryGraphRenderer.Instance.ShowPendingAttack(source.name, territory.name);
            }
            else
            {
                AddLogMessage("Select an enemy or neutral territory to attack.");
            }
            return;
        }
    }
    public void UpdateTerritoryMap()
    {
        foreach (var kvp in territoryMapEntries)
        {
            TerritoryData tData = GameManager.Instance.territories.Find(t => t.name == kvp.Key);
            if (tData != null)
                UpdateTerritoryMapEntry(kvp.Value, tData);
        }
        UpdateMapClickZones();
        if (TerritoryGraphRenderer.Instance != null)
            TerritoryGraphRenderer.Instance.RedrawArrows();
    }
    Vector2 TerritoryUvToAnchor(Vector2 rawUV)
    {
        return new Vector2(
            Mathf.Clamp01(rawUV.x),
            1f - Mathf.Clamp01(rawUV.y));
    }
    void AssignMapClickZonesParent()
    {
        CanvasGroup cg = mapClickZonesRoot.AddComponent<CanvasGroup>();
        cg.blocksRaycasts = true;
        cg.interactable = true;
        cg.ignoreParentGroups = true;
    }
    void BuildTerritorySidebar(Transform ct)
    {
        GameObject tabContainer = new GameObject("TerritoryTabContainer", typeof(RectTransform));
        tabContainer.transform.SetParent(ct, false);

        GameObject sidePanel = new GameObject("TerritorySidebar", typeof(RectTransform));
        sidePanel.transform.SetParent(tabContainer.transform, false);
        Image spBg = sidePanel.AddComponent<Image>();
        spBg.color = new Color(0.06f, 0.03f, 0.015f, 0.92f);
        spBg.raycastTarget = false;
        RectTransform sideRect = sidePanel.GetComponent<RectTransform>();
        Anchor(sideRect, 0.00f, 0.06f, 0.42f, 0.46f);
        sideRect.pivot = new Vector2(0f, 0f);

        Text sideTitle = MakeUIText(sidePanel.transform, "SideTitle", 12, FontStyle.Bold,
            Gold, new Vector2(0.02f, 0.85f), new Vector2(0.98f, 1f)).GetComponent<Text>();
        sideTitle.text = "TERRITORIES";

        GameObject svGO = new GameObject("ScrollView", typeof(RectTransform));
        svGO.transform.SetParent(sidePanel.transform, false);
        ScrollRect sr = svGO.AddComponent<ScrollRect>();
        Image svBg = svGO.AddComponent<Image>();
        svBg.color = new Color(0.04f, 0.02f, 0.01f, 0.85f);
        svBg.raycastTarget = false;
        Anchor(svGO.GetComponent<RectTransform>(), 0, 0, 1, 0.82f);

        GameObject vp = new GameObject("Viewport", typeof(RectTransform));
        vp.transform.SetParent(svGO.transform, false);
        vp.AddComponent<Mask>();
        vp.AddComponent<Image>().color = Color.clear;
        FullStretch(vp.GetComponent<RectTransform>());

        GameObject content = new GameObject("Content", typeof(RectTransform));
        content.transform.SetParent(vp.transform, false);
        RectTransform cR = content.GetComponent<RectTransform>();
        cR.anchorMin = new Vector2(0, 1);
        cR.anchorMax = new Vector2(1, 1);
        cR.pivot = new Vector2(0.5f, 1f);
        cR.sizeDelta = Vector2.zero;
        ContentSizeFitter csf = content.AddComponent<ContentSizeFitter>();
        csf.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
        VerticalLayoutGroup vlgContent = content.AddComponent<VerticalLayoutGroup>();
        vlgContent.childForceExpandWidth = true;
        vlgContent.childControlHeight = true;
        vlgContent.spacing = 1;
        vlgContent.padding = new RectOffset(2, 2, 2, 2);

        sr.viewport = vp.GetComponent<RectTransform>();
        sr.content = cR;
        sr.vertical = true;
        sr.horizontal = false;
        sr.movementType = ScrollRect.MovementType.Clamped;

        territoryMapEntries.Clear();
        _lastSidebarRegion = null;
        List<string> allRegions = TerritoryGraph.GetAllRegionNames();
        foreach (string region in allRegions)
        {
            List<string> terrNames = TerritoryGraph.GetRegionTerritories(region);
            foreach (string name in terrNames)
                CreateTerritoryMapEntry(content.transform, name, region);
        }

        sidePanel.SetActive(false);

        Button toggleBtn = MakeButton(tabContainer.transform, "TerritoryToggleBtn",
            Vector2.zero, new Vector2(100, 28), "TERRITORIES ▾",
            new Color(0.15f, 0.10f, 0.05f, 0.8f),
            new Color(0.25f, 0.18f, 0.10f, 0.9f));
        RectTransform tR = toggleBtn.GetComponent<RectTransform>();
        tR.anchorMin = new Vector2(0.00f, 0.46f);
        tR.anchorMax = new Vector2(0.14f, 0.51f);
        tR.sizeDelta = Vector2.zero;
        tR.anchoredPosition = Vector2.zero;
        toggleBtn.GetComponentInChildren<Text>().fontSize = 11;
        toggleBtn.onClick.AddListener(() =>
        {
            sidePanel.SetActive(!sidePanel.activeSelf);
            toggleBtn.GetComponentInChildren<Text>().text = sidePanel.activeSelf ? "TERRITORIES ▴" : "TERRITORIES ▾";
        });
    }
    void BuildMapClickZones(Transform ct)
    {
        mapClickZonesRoot = new GameObject("MapClickZones", typeof(RectTransform));
        mapClickZonesRoot.transform.SetParent(ct, false);
        Anchor(mapClickZonesRoot.GetComponent<RectTransform>(),
            MapAnchorMin.x, MapAnchorMin.y, MapAnchorMax.x, MapAnchorMax.y);
        AssignMapClickZonesParent();

        territoryMapPositions = BuildTerritoryMapPositions();
        if (territoryMapPositions.Count == 0) return;

        foreach (var kvp in territoryMapPositions)
        {
            string terrName = kvp.Key;
            Vector2 pos = kvp.Value;

            GameObject zone = new GameObject("MapBtn_" + terrName.Replace(" ", ""), typeof(RectTransform));
            zone.transform.SetParent(mapClickZonesRoot.transform, false);

            Image zoneImg = zone.AddComponent<Image>();
            zoneImg.color = Color.clear;
            zoneImg.raycastTarget = true;

            Button zoneBtn = zone.AddComponent<Button>();
            zoneBtn.targetGraphic = zoneImg;
            Navigation nav = new Navigation { mode = Navigation.Mode.None };
            zoneBtn.navigation = nav;

            RectTransform zoneR = zone.GetComponent<RectTransform>();
            zoneR.anchorMin = zoneR.anchorMax = pos;
            zoneR.pivot = new Vector2(0.5f, 0.5f);
            zoneR.sizeDelta = new Vector2(60, 60);
            zoneR.anchoredPosition = Vector2.zero;

            Text nameLabel = MakeUIText(zone.transform, "Label", 8, FontStyle.Bold,
                                         Parchment.WithA(0.75f), new Vector2(0f, 1f), new Vector2(1f, 1f)).GetComponent<Text>();
            RectTransform nlR = nameLabel.GetComponent<RectTransform>();
            nlR.pivot = new Vector2(0.5f, 0f);
            nlR.sizeDelta = new Vector2(0, 16);
            nlR.anchoredPosition = Vector2.zero;
            nameLabel.text = terrName;
            nameLabel.alignment = TextAnchor.UpperCenter;
            nameLabel.raycastTarget = false;

            GameObject badgeGO = new GameObject("TroopBadge", typeof(RectTransform));
            badgeGO.transform.SetParent(zone.transform, false);
            Image badgeBg = badgeGO.AddComponent<Image>();
            badgeBg.raycastTarget = false;
            RectTransform badgeR = badgeGO.GetComponent<RectTransform>();
            badgeR.anchorMin = badgeR.anchorMax = new Vector2(0.5f, 0.5f);
            badgeR.sizeDelta = new Vector2(28, 18);
            badgeR.anchoredPosition = Vector2.zero;

            Text badgeText = MakeUIText(badgeGO.transform, "Count", 9, FontStyle.Bold,
                                         Parchment, Vector2.zero, Vector2.one).GetComponent<Text>();
            badgeText.raycastTarget = false;

            GameObject ringGO = new GameObject("PhaseRing", typeof(RectTransform));
            ringGO.transform.SetParent(zone.transform, false);
            Image ringImg = ringGO.AddComponent<Image>();
            ringImg.sprite = GetPhaseCircleSprite();
            ringImg.color = Color.clear;
            ringImg.raycastTarget = false;
            RectTransform ringR = ringGO.GetComponent<RectTransform>();
            ringR.anchorMin = ringR.anchorMax = new Vector2(0.5f, 0.5f);
            ringR.sizeDelta = new Vector2(72, 72);
            ringR.anchoredPosition = Vector2.zero;

            string captured = terrName;
            zoneBtn.onClick.AddListener(() => OnMapTerritoryClicked(captured));

            TerritoryClickHandler rch = zone.AddComponent<TerritoryClickHandler>();
            rch.territory = GameManager.Instance?.territories.Find(t => t.name == captured);
            rch.onRightClick = OnTerritoryRightClicked;

            mapClickButtons[terrName] = zoneBtn;
            mapClickZoneButtons[terrName] = zoneBtn;
        }
    }
    void UpdateMapClickZones()
    {
        if (GameManager.Instance?.territories == null) return;
        FactionData player = GameManager.Instance.GetPlayerFaction();

        foreach (var kvp in mapClickButtons)
        {
            Button btn = kvp.Value;
            if (btn == null) continue;

            TerritoryData tData = GameManager.Instance.territories.Find(t => t.name == kvp.Key);
            if (tData == null) continue;

            TerritoryClickHandler clickHandler = btn.GetComponent<TerritoryClickHandler>();
            if (clickHandler != null)
            {
                clickHandler.territory = tData;
                clickHandler.onRightClick = OnTerritoryRightClicked;
            }

            Transform badge = btn.transform.Find("TroopBadge");
            if (badge != null)
            {
                Image badgeBg = badge.GetComponent<Image>();
                Text badgeText = badge.GetComponentInChildren<Text>();

                Color ownerColor = Color.gray;
                if (tData.controlledBy >= 0 && tData.controlledBy < GameManager.Instance.factions.Count)
                    ownerColor = GameManager.Instance.factions[tData.controlledBy].factionColor;

                if (badgeBg != null)
                {
                    if (tData.controlledBy >= 0)
                        badgeBg.color = new Color(ownerColor.r * 0.6f, ownerColor.g * 0.6f, ownerColor.b * 0.6f, 0.9f);
                    else
                        badgeBg.color = new Color(0.2f, 0.2f, 0.2f, 0.7f);
                }

                if (badgeText != null)
                    badgeText.text = tData.troops > 0 ? tData.troops.ToString() : "-";

                if (!mapTroopCache.TryGetValue(kvp.Key, out int prev) || prev != tData.troops)
                {
                    mapTroopCache[kvp.Key] = tData.troops;
                    StartCoroutine(PulseBadge(badge.gameObject));
                }
            }

            Image zoneImg = btn.GetComponent<Image>();
            if (zoneImg == null) continue;
            Image ringImg = btn.transform.Find("PhaseRing")?.GetComponent<Image>();
            if (ringImg != null) ringImg.color = Color.clear;

            if (GameManager.Instance.IsWaitingForReinforcements)
            {
                bool owned = player != null && tData.controlledBy == player.factionId;
                zoneImg.color = owned ? new Color(0.3f, 0.5f, 0.9f, 0.20f) : Color.clear;
                if (ringImg != null && owned)
                    ringImg.color = new Color(0.25f, 0.65f, 1.0f, 0.85f);
            }
            else if (waitingForTerritoryAttackSource)
            {
                bool valid = player != null && tData.controlledBy == player.factionId && tData.troops > 1;
                zoneImg.color = valid ? new Color(0.1f, 0.7f, 0.1f, 0.30f) : Color.clear;
                if (ringImg != null)
                    ringImg.color = valid ? new Color(0.9f, 0.65f, 0.1f, 0.85f) : Color.clear;

                Transform attackBadge = btn.transform.Find("TroopBadge");
                if (attackBadge != null)
                {
                    Image badgeBg = attackBadge.GetComponent<Image>();
                    if (badgeBg != null)
                        badgeBg.color = valid
                            ? new Color(0.15f, 0.70f, 0.15f, 1.0f)
                            : new Color(0.25f, 0.25f, 0.25f, 0.6f);
                }
            }
            else if (waitingForTerritoryAttackTarget && pendingAttackSourceTerritory != null)
            {
                bool isTarget = tData.controlledBy != player.factionId;
                bool isSource = tData.name == pendingAttackSourceTerritory.name;
                zoneImg.color = isTarget ? new Color(0.8f, 0.2f, 0.1f, 0.30f) : Color.clear;
                if (ringImg != null)
                    ringImg.color = isTarget ? new Color(1.0f, 0.25f, 0.1f, 0.90f) : Color.clear;

                Transform targetBadge = btn.transform.Find("TroopBadge");
                if (targetBadge != null)
                {
                    Image badgeBg = targetBadge.GetComponent<Image>();
                    if (badgeBg != null)
                        badgeBg.color = isTarget
                            ? new Color(0.75f, 0.15f, 0.08f, 1.0f)
                            : isSource
                                ? new Color(0.1f, 0.55f, 0.75f, 1.0f)
                                : new Color(0.25f, 0.25f, 0.25f, 0.6f);
                }
            }
            else if (GameManager.Instance.currentState == GameState.FORTIFY_PHASE)
            {
                if (waitingForFortifySource)
                {
                    bool valid = player != null && tData.controlledBy == player.factionId && tData.troops > 1;
                    zoneImg.color = valid ? new Color(0.3f, 0.7f, 0.3f, 0.25f) : Color.clear;
                    if (ringImg != null && valid)
                        ringImg.color = new Color(0.35f, 0.9f, 0.35f, 0.85f);
                }
                else if (waitingForFortifyTarget && pendingFortifySource != null)
                {
                    bool valid = player != null && IsValidFortifyDestination(pendingFortifySource, tData, player.factionId);
                    zoneImg.color = valid ? new Color(0.3f, 0.5f, 0.3f, 0.25f) : Color.clear;
                    if (ringImg != null && valid)
                        ringImg.color = new Color(0.35f, 0.9f, 0.35f, 0.85f);
                }
                else if (waitingForNeutralExpandSource)
                {
                    bool valid = player != null && tData.controlledBy == player.factionId && tData.troops >= 10;
                    zoneImg.color = valid ? new Color(0.15f, 0.75f, 0.15f, 0.35f) : Color.clear;
                }
                else if (waitingForNeutralExpandTarget && pendingExpandSource != null)
                {
                    bool valid = tData.controlledBy == -1 && TerritoryGraph.AreAdjacent(pendingExpandSource.name, tData.name);
                    zoneImg.color = valid ? new Color(0.45f, 0.85f, 0.25f, 0.40f) : Color.clear;
                }
                else
                {
                    zoneImg.color = Color.clear;
                }
            }
            else if (GameManager.Instance.currentState == GameState.ATTACK_PHASE)
            {
                zoneImg.color = new Color(0, 0, 0, 0.08f);
            }
            else
            {
                zoneImg.color = new Color(0, 0, 0, 0.06f);
                if (badge != null)
                {
                    Image badgeBg = badge.GetComponent<Image>();
                    if (badgeBg != null && tData.controlledBy >= 0)
                    {
                        Color ownerColor = tData.controlledBy < GameManager.Instance.factions.Count
                            ? GameManager.Instance.factions[tData.controlledBy].factionColor
                            : Color.gray;
                        badgeBg.color = new Color(ownerColor.r * 0.6f, ownerColor.g * 0.6f,
                                                  ownerColor.b * 0.6f, 0.9f);
                    }
                }
            }
        }
    }
    void OnMapTerritoryClicked(string territoryName)
    {
        TerritoryData territory = GameManager.Instance?.territories.Find(t => t.name == territoryName);
        if (territory != null)
            OnTerritoryClicked(territory);
    }
    IEnumerator PulseTerritoryEntry(GameObject entry)
    {
        if (entry == null) yield break;
        float duration = 0.15f;
        for (float t = 0; t < duration; t += Time.deltaTime)
        {
            float s = 1f + 0.15f * (1f - t / duration);
            entry.transform.localScale = new Vector3(s, s, 1f);
            yield return null;
        }
        entry.transform.localScale = Vector3.one;
    }
    void OnTerritoryRightClicked(TerritoryData territory)
    {
        if (territory == null) return;
        if (GameManager.Instance.IsWaitingForReinforcements)
        {
            FactionData player = GameManager.Instance.GetPlayerFaction();
            if (territory.controlledBy == player.factionId)
                GameManager.Instance.AssignReinforcementToTerritory(territory, player.pendingReinforcements);
        }
    }
    public Vector2 ScreenToMapUV(Vector2 screenPos)
    {
        Vector2 viewPos = new Vector2(screenPos.x / Screen.width, screenPos.y / Screen.height);
        float mapLeft = MapAnchorMin.x;
        float mapRight = MapAnchorMax.x;
        float mapBot = MapAnchorMin.y;
        float mapTop = MapAnchorMax.y;
        float uvX = (viewPos.x - mapLeft) / (mapRight - mapLeft);
        float uvY = (viewPos.y - mapBot) / (mapTop - mapBot);
        return new Vector2(uvX, uvY);
    }
    public void OnProvinceClicked(ProvinceData province)
    {
        if (province == null) return;
        Debug.Log($"[GameUIManager] Province clicked: {province.provinceName}");
    }
    void OnExpandButtonClicked()
    {
        if (GameManager.Instance?.currentState != GameState.PLAY_PHASE) return;
        if (!GameManager.Instance.CanPlayMoreCards())
        {
            AddLogMessage("No card slots remaining for expansion this turn.");
            return;
        }
        waitingForNeutralExpandSource = true;
        waitingForNeutralExpandTarget = false;
        pendingExpandSource = null;
        AddLogMessage("EXPAND: Select one of your territories with 10+ troops.");
        UpdateMapClickZones();
    }
    void OnMapLayerBuilt()
    {
        if (canvas == null) return;

        if (mapAreaBg != null) mapAreaBg.transform.SetSiblingIndex(0);
        MapLayerController.Instance?.PlaceBehindGameplayMap();

        Transform ct = canvas.transform;
        ZoomController zoomCtrl = canvas.GetComponentInChildren<ZoomController>();
        if (zoomCtrl != null && MapLayerController.Instance?.MapImage != null)
            zoomCtrl.SetTarget(MapLayerController.Instance.MapImage.rectTransform);

        Transform clickZones = mapClickZonesRoot != null ? mapClickZonesRoot.transform : ct.Find("MapClickZones");
        if (clickZones != null && MapLayerController.Instance?.MapImage != null)
        {
            clickZones.SetParent(MapLayerController.Instance.MapImage.transform, false);
            RectTransform czR = clickZones.GetComponent<RectTransform>();
            czR.anchorMin = Vector2.zero;
            czR.anchorMax = Vector2.one;
            czR.sizeDelta = Vector2.zero;
            czR.anchoredPosition = Vector2.zero;
        }

        Transform handAreaT = ct.Find("HandArea");
        if (handAreaT != null) handAreaT.SetAsLastSibling();
        if (probabilityPanel != null) probabilityPanel.transform.SetAsLastSibling();
        if (damageFlashOverlay != null) damageFlashOverlay.transform.SetAsLastSibling();
        EnforceDrawOrder();
    }
    void EnterTerritoryAttackSourceMode(CardData card)
    {
        if (GameManager.Instance != null && GameManager.Instance.IsWaitingForAttackSelection)
        {
            AddLogMessage("Use the attack phase map instead of a card during ATTACK PHASE.");
            return;
        }
        pendingCard = card;
        pendingCardPosition = GetCardWorldPosition(card);
        isSelectingTarget = true;
        waitingForTerritoryAttackSource = true;
        waitingForTerritoryAttackTarget = false;
        pendingAttackSourceTerritory = null;

        if (TerritoryGraphRenderer.Instance != null)
            TerritoryGraphRenderer.Instance.ClearHighlight();

        FactionData player = GameManager.Instance.GetPlayerFaction();
        ShowAttackStatus("⚔ TAP a GREEN territory to attack from (needs 2+ troops)");
        AddLogMessage("⚔ ATTACK: Click one of your GREEN territories (need 2+ troops) to begin.");
        if (probabilityPanel != null) probabilityPanel.SetActive(false);
        UpdateMapClickZones();
        HighlightValidAttackSources(player);
        ShowPhase("\u2694  ATTACK PHASE", new Color(0.8f, 0.2f, 0.1f));
    }
    void HighlightValidAttackSources(FactionData player)
    {
        if (player == null || GameManager.Instance == null) return;
        foreach (var kvp in territoryMapEntries)
        {
            TerritoryData tData = GameManager.Instance.territories.Find(t => t.name == kvp.Key);
            if (tData == null || tData.controlledBy != player.factionId) continue;
            Image bg = kvp.Value.GetComponent<Image>();
            if (bg == null) continue;
            if (tData.troops > 1)
                bg.color = new Color(0.1f, 0.7f, 0.1f, 0.9f);
            else
                bg.color = new Color(0.4f, 0.4f, 0.1f, 0.6f);
        }

        foreach (var kvp in mapClickButtons)
        {
            TerritoryData tData = GameManager.Instance.territories.Find(t => t.name == kvp.Key);
            if (tData == null) continue;
            Transform badge = kvp.Value.transform.Find("TroopBadge");
            if (badge == null) continue;
            Image badgeBg = badge.GetComponent<Image>();
            if (badgeBg == null) continue;
            bool valid = player != null && tData.controlledBy == player.factionId && tData.troops > 1;
            badgeBg.color = valid
                ? new Color(0.15f, 0.72f, 0.15f, 1.0f)
                : new Color(0.22f, 0.22f, 0.22f, 0.55f);
        }
    }
    void ClearTerritoryHighlights()
    {
        foreach (var kvp in territoryMapEntries)
        {
            Image bg = kvp.Value.GetComponent<Image>();
            if (bg != null) bg.color = Dark;
        }
        UpdateMapClickZones();
        foreach (var kvp in mapClickZoneButtons)
        {
            Image img = kvp.Value.GetComponent<Image>();
            if (img != null) img.color = Color.clear;
        }

        foreach (var kvp in mapClickButtons)
        {
            TerritoryData tData = GameManager.Instance?.territories?.Find(t => t.name == kvp.Key);
            if (tData == null) continue;
            Transform badge = kvp.Value.transform.Find("TroopBadge");
            if (badge == null) continue;
            Image badgeBg = badge.GetComponent<Image>();
            if (badgeBg == null) continue;
            Color ownerColor = tData.controlledBy >= 0 && tData.controlledBy < GameManager.Instance.factions.Count
                ? GameManager.Instance.factions[tData.controlledBy].factionColor : Color.gray;
            badgeBg.color = tData.controlledBy >= 0
                ? new Color(ownerColor.r * 0.6f, ownerColor.g * 0.6f, ownerColor.b * 0.6f, 0.9f)
                : new Color(0.2f, 0.2f, 0.2f, 0.7f);
        }
    }
    void ShowAttackArrow(TerritoryData source, TerritoryData target)
    {
        HideAttackArrow();
        if (territoryMapPositions == null || !territoryMapPositions.ContainsKey(source.name) || !territoryMapPositions.ContainsKey(target.name))
            return;

        attackArrow = DrawMapArrow("AttackArrow", source.name, target.name, Gold, 6f);
    }
    void HideAttackArrow()
    {
        if (attackArrow != null)
        {
            Destroy(attackArrow);
            attackArrow = null;
        }
    }
    void ShowAttackOptionArrows(TerritoryData source, List<TerritoryData> targets)
    {
        HidePhaseArrows();
        if (source == null || targets == null) return;

        foreach (TerritoryData target in targets)
        {
            if (target == null) continue;
            GameObject arrow = DrawMapArrow("AttackOptionArrow", source.name, target.name,
                new Color(1.0f, 0.25f, 0.1f, 0.85f), 4f);
            if (arrow != null) phaseArrows.Add(arrow);
        }
    }
    void ShowFortifyPathArrows(TerritoryData source, int factionId)
    {
        HidePhaseArrows();
        if (source == null || GameManager.Instance == null) return;

        foreach (TerritoryData target in GameManager.Instance.territories)
        {
            if (target == null || !IsValidFortifyDestination(source, target, factionId)) continue;
            GameObject arrow = DrawMapArrow("FortifyPathArrow", source.name, target.name,
                new Color(0.25f, 0.9f, 0.35f, 0.75f), 3f);
            if (arrow != null) phaseArrows.Add(arrow);
        }
    }
    GameObject DrawMapArrow(string name, string sourceName, string targetName, Color color, float thickness)
    {
        if (territoryMapPositions == null ||
            !territoryMapPositions.ContainsKey(sourceName) ||
            !territoryMapPositions.ContainsKey(targetName))
            return null;

        Vector2 srcPos = territoryMapPositions[sourceName];
        Vector2 tgtPos = territoryMapPositions[targetName];
        RectTransform arrowParent = mapClickZonesRoot != null
            ? mapClickZonesRoot.GetComponent<RectTransform>()
            : canvas.GetComponent<RectTransform>();
        Vector2 parentSize = arrowParent != null ? arrowParent.rect.size : new Vector2(1920f, 1080f);
        if (parentSize.x <= 1f || parentSize.y <= 1f)
            parentSize = new Vector2(1920f, 1080f);
        Vector2 pixelDir = new Vector2((tgtPos.x - srcPos.x) * parentSize.x, (tgtPos.y - srcPos.y) * parentSize.y);
        float dist = pixelDir.magnitude;
        if (dist <= 1f) return null;

        GameObject arrow = new GameObject(name, typeof(RectTransform));
        arrow.transform.SetParent(mapClickZonesRoot != null ? mapClickZonesRoot.transform : canvas.transform, false);
        Image arrowImg = arrow.AddComponent<Image>();
        arrowImg.color = color;
        arrowImg.raycastTarget = false;

        RectTransform ar = arrow.GetComponent<RectTransform>();
        ar.anchorMin = ar.anchorMax = srcPos;
        ar.pivot = new Vector2(0f, 0.5f);
        ar.sizeDelta = new Vector2(dist, thickness);
        ar.localRotation = Quaternion.Euler(0f, 0f, Mathf.Atan2(pixelDir.y, pixelDir.x) * Mathf.Rad2Deg);
        ar.anchoredPosition = Vector2.zero;

        AddArrowWing(arrow.transform, "HeadA", color, thickness, 32f, 150f);
        AddArrowWing(arrow.transform, "HeadB", color, thickness, 32f, -150f);
        return arrow;
    }
    void AddArrowWing(Transform parent, string name, Color color, float thickness, float length, float angle)
    {
        GameObject wing = new GameObject(name, typeof(RectTransform));
        wing.transform.SetParent(parent, false);
        Image img = wing.AddComponent<Image>();
        img.color = color;
        img.raycastTarget = false;
        RectTransform wr = wing.GetComponent<RectTransform>();
        wr.anchorMin = wr.anchorMax = new Vector2(1f, 0.5f);
        wr.pivot = new Vector2(1f, 0.5f);
        wr.sizeDelta = new Vector2(length, Mathf.Max(2f, thickness));
        wr.anchoredPosition = Vector2.zero;
        wr.localRotation = Quaternion.Euler(0f, 0f, angle);
    }
    void HidePhaseArrows()
    {
        foreach (GameObject arrow in phaseArrows)
            if (arrow != null) Destroy(arrow);
        phaseArrows.Clear();
    }
    bool IsValidFortifyDestination(TerritoryData source, TerritoryData destination, int factionId)
    {
        if (source == null || destination == null || source == destination) return false;
        if (source.controlledBy != factionId || destination.controlledBy != factionId) return false;
        if (GameManager.Instance == null || GameManager.Instance.territories == null) return false;

        Queue<TerritoryData> open = new Queue<TerritoryData>();
        HashSet<TerritoryData> visited = new HashSet<TerritoryData>();
        open.Enqueue(source);
        visited.Add(source);

        while (open.Count > 0)
        {
            TerritoryData current = open.Dequeue();
            foreach (string adjName in ProvinceGraph.GetAttackNeighbours(current.name))
            {
                TerritoryData next = GameManager.Instance.territories.Find(t => t.name == adjName);
                if (next == null || next.controlledBy != factionId || visited.Contains(next)) continue;
                if (next == destination) return true;
                visited.Add(next);
                open.Enqueue(next);
            }
        }

        return false;
    }
    void EnterTerritoryAttackTargetMode(CardData card, TerritoryData source)
    {
        pendingAttackSourceTerritory = source;
        waitingForTerritoryAttackSource = false;
        waitingForTerritoryAttackTarget = true;

        ClearTerritoryHighlights();

        if (TerritoryGraphRenderer.Instance != null)
            TerritoryGraphRenderer.Instance.HighlightAttackOptions(source);

        List<TerritoryData> targets = GameManager.Instance.GetAdjacentEnemyTerritories(source);
        ShowAttackOptionArrows(source, targets);
        foreach (var kvp in territoryMapEntries)
        {
            TerritoryData tData = GameManager.Instance.territories.Find(t => t.name == kvp.Key);
            if (targets.Contains(tData))
            {
                Image bg = kvp.Value.GetComponent<Image>();
                if (bg != null) bg.color = new Color(0.50f, 0.15f, 0.10f);
            }
        }

        UpdateMapClickZones();
        foreach (var kvp in mapClickButtons)
        {
            TerritoryData tData = GameManager.Instance.territories.Find(t => t.name == kvp.Key);
            if (tData == null) continue;
            Transform badge = kvp.Value.transform.Find("TroopBadge");
            if (badge == null) continue;
            Image badgeBg = badge.GetComponent<Image>();
            if (badgeBg == null) continue;
            bool isTarget = targets.Contains(tData);
            bool isSource = tData.name == source.name;
            badgeBg.color = isTarget ? new Color(0.80f, 0.14f, 0.08f, 1.0f)
                : isSource ? new Color(0.10f, 0.50f, 0.80f, 1.0f)
                : new Color(0.22f, 0.22f, 0.22f, 0.55f);
        }

        ShowAttackStatus($"Select ATTACK TARGET territory from {source.name}");
        AddLogMessage($"\u2694 ATTACK: Click a RED enemy territory adjacent to {source.name} to attack.");
        if (probabilityPanel != null) probabilityPanel.SetActive(false);
        ShowPhase("\u2694  SELECT TARGET", new Color(0.8f, 0.2f, 0.1f));
    }
    void ExitTerritoryAttackMode()
    {
        if (pendingCard != null)
        {
            FactionData player = GameManager.Instance?.GetPlayerFaction();
            if (player != null && !player.hand.Contains(pendingCard))
            {
                player.hand.Add(pendingCard);
                UpdatePlayerHand(player.hand);
                AddLogMessage($"{pendingCard.cardName} returned to hand (attack cancelled).");
            }
            pendingCardPosition = Vector3.zero;
            pendingCard = null;
        }
        isSelectingTarget = false;
        waitingForTerritoryAttackSource = false;
        waitingForTerritoryAttackTarget = false;
        waitingForNeutralExpandSource = false;
        waitingForNeutralExpandTarget = false;
        pendingExpandSource = null;
        pendingCard = null;
        pendingCardPosition = Vector3.zero;
        pendingAttackSourceTerritory = null;
        if (GameManager.Instance != null)
        {
            GameManager.Instance.pendingAttackerDiceCount = 0;
            GameManager.Instance.pendingAttackerTroopCount = 0;
        }
        if (diceChoicePopup != null) diceChoicePopup.SetActive(false);
        if (attackModePopup != null) attackModePopup.SetActive(false);
        HidePhaseArrows();
        ClearTerritoryHighlights();
        HideAttackArrow();
        HideAttackStatus();
        if (TerritoryGraphRenderer.Instance != null)
        {
            TerritoryGraphRenderer.Instance.ClearHighlight();
            TerritoryGraphRenderer.Instance.ClearPendingAttack();
        }
    }
    void ShowAttackModeChoice(CardData card)
    {
        if (attackModePopup == null) BuildAttackModePopup();
        pendingCard = card;
        pendingCardPosition = GetCardWorldPosition(card);
        attackModePopup.SetActive(true);
    }
    void BuildAttackModePopup()
    {
        Transform ct = canvas.transform;
        attackModePopup = new GameObject("AttackModePopup", typeof(RectTransform));
        attackModePopup.transform.SetParent(ct, false);
        Image bg = attackModePopup.AddComponent<Image>();
        bg.color = new Color(0.10f, 0.05f, 0.01f, 0.95f);
        Anchor(attackModePopup.GetComponent<RectTransform>(), 0.30f, 0.38f, 0.70f, 0.58f);

        MakeUIText(attackModePopup.transform, "Title", 14, FontStyle.Bold,
            new Color(0.83f, 0.65f, 0.22f), new Vector2(0.05f, 0.72f), new Vector2(0.95f, 0.98f))
            .GetComponent<Text>().text = "CHOOSE ATTACK TYPE";

        Button terrBtn = MakeButton(attackModePopup.transform, "TerritoryBtn",
            new Vector2(0.05f, 0.40f), new Vector2(0.95f, 0.68f),
            "\u2694 TERRITORY ATTACK\n(select on map)",
            new Color(0.3f, 0.1f, 0.05f), new Color(0.9f, 0.4f, 0.1f));
        terrBtn.onClick.AddListener(() =>
        {
            attackModePopup.SetActive(false);
            EnterTerritoryAttackSourceMode(pendingCard);
        });

        Button directBtn = MakeButton(attackModePopup.transform, "DirectBtn",
            new Vector2(0.05f, 0.05f), new Vector2(0.95f, 0.38f),
            "\u2694 DIRECT ASSAULT\n(damage enemy faction)",
            new Color(0.1f, 0.05f, 0.2f), new Color(0.6f, 0.2f, 0.9f));
        directBtn.onClick.AddListener(() =>
        {
            attackModePopup.SetActive(false);
            EnterTargetMode(pendingCard);
        });

        attackModePopup.SetActive(false);
    }
    void BuildTerritoryTooltip(Transform ct)
    {
        territoryTooltip = new GameObject("TerritoryTooltip", typeof(RectTransform));
        territoryTooltip.transform.SetParent(ct, false);
        RectTransform tr = territoryTooltip.GetComponent<RectTransform>();
        tr.pivot = new Vector2(0f, 0f);
        tr.anchorMin = tr.anchorMax = Vector2.zero;
        tr.sizeDelta = new Vector2(220, 110);
        Image tb = territoryTooltip.AddComponent<Image>();
        tb.color = Dark;
        tb.raycastTarget = false;
        Canvas ttCanvas = territoryTooltip.AddComponent<Canvas>();
        ttCanvas.overrideSorting = true;
        ttCanvas.sortingOrder = 50;
        territoryTooltip.AddComponent<GraphicRaycaster>();
        territoryTooltip.SetActive(false);

        MakeHRule(territoryTooltip.transform, new Vector2(0.05f, 0.68f), new Vector2(0.95f, 0.70f), Gold.WithA(0.50f))
            .GetComponent<Image>().raycastTarget = false;

        territoryTooltipName = MakeUIText(territoryTooltip.transform, "Name", 14, FontStyle.Bold,
            Parchment, new Vector2(0.05f, 0.74f), new Vector2(0.95f, 0.96f)).GetComponent<Text>();

        territoryTooltipOwner = MakeUIText(territoryTooltip.transform, "Owner", 11, FontStyle.Normal,
            Parchment.WithA(0.75f), new Vector2(0.05f, 0.56f), new Vector2(0.95f, 0.68f)).GetComponent<Text>();

        territoryTooltipStats = MakeUIText(territoryTooltip.transform, "Stats", 10, FontStyle.Normal,
            Parchment.WithA(0.65f), new Vector2(0.05f, 0.02f), new Vector2(0.95f, 0.54f)).GetComponent<Text>();
        territoryTooltipStats.horizontalOverflow = HorizontalWrapMode.Wrap;
    }
    public void ShowTerritoryTooltip(TerritoryData t)
    {
        if (territoryTooltip == null || canvas == null) return;

        territoryTooltipName.text = t.name;
        string ownerName = t.controlledBy >= 0 && t.controlledBy < GameManager.Instance.factions.Count
            ? GameManager.Instance.factions[t.controlledBy].factionName : "Neutral";
        territoryTooltipOwner.text = $"Owner: {ownerName}";
        territoryTooltipStats.text = $"Troops: {t.troops}   Farms: {t.farmingValue}   Strategic: {t.strategicValue}";

        float anchorX = Mathf.Lerp(MapAnchorMin.x, MapAnchorMax.x, t.mapPosition.x);
        float anchorY = Mathf.Lerp(MapAnchorMin.y, MapAnchorMax.y, 1f - t.mapPosition.y);

        RectTransform canvasRT = canvas.GetComponent<RectTransform>();
        float cw = canvasRT.rect.width;
        float ch = canvasRT.rect.height;
        float rawX = anchorX * cw;
        float rawY = anchorY * ch;

        RectTransform tr = territoryTooltip.GetComponent<RectTransform>();
        float tw = tr.sizeDelta.x;
        float th = tr.sizeDelta.y;

        float finalX = Mathf.Clamp(rawX + 16f, 4f, cw - tw - 4f);
        float finalY = Mathf.Clamp(rawY + 16f, 4f, ch - th - 4f);

        tr.anchoredPosition = new Vector2(finalX, finalY);
        territoryTooltip.SetActive(true);
    }
    public void HideTerritoryTooltip()
    {
        if (territoryTooltip != null) territoryTooltip.SetActive(false);
    }
    void BuildAttackStatusBanner(Transform ct)
    {
        attackStatusBanner = new GameObject("AttackStatusBanner", typeof(RectTransform));
        attackStatusBanner.transform.SetParent(ct, false);
        Image asbImg = attackStatusBanner.AddComponent<Image>();
        asbImg.color = new Color(0.6f, 0.10f, 0.04f, 0.96f);
        Anchor(attackStatusBanner.GetComponent<RectTransform>(), 0.01f, 0.86f, 0.72f, 0.95f);

        attackStatusText = MakeUIText(attackStatusBanner.transform, "StatusText", 15, FontStyle.Bold,
            new Color(1.0f, 0.88f, 0.55f, 1.0f),
            new Vector2(0.02f, 0f), new Vector2(0.98f, 1f)).GetComponent<Text>();
        attackStatusText.alignment = TextAnchor.MiddleLeft;
        attackStatusBanner.SetActive(false);
    }
    public void ShowAttackStatus(string message)
    {
        if (attackStatusBanner == null || attackStatusText == null) return;
        attackStatusText.text = message;
        attackStatusBanner.SetActive(true);
        if (attackStatusPulseCoroutine != null)
            StopCoroutine(attackStatusPulseCoroutine);
        attackStatusPulseCoroutine = StartCoroutine(PulseAttackStatusBanner());
    }
    public void HideAttackStatus()
    {
        if (attackStatusBanner != null) attackStatusBanner.SetActive(false);
        if (attackStatusPulseCoroutine != null)
        {
            StopCoroutine(attackStatusPulseCoroutine);
            attackStatusPulseCoroutine = null;
        }
    }
    IEnumerator PulseAttackStatusBanner()
    {
        Image bg = attackStatusBanner.GetComponent<Image>();
        while (attackStatusBanner != null && attackStatusBanner.activeSelf)
        {
            float pulse = 0.82f + 0.18f * Mathf.PingPong(Time.unscaledTime * 2f, 1f);
            if (bg != null)
                bg.color = new Color(0.6f, 0.10f, 0.04f, pulse);
            yield return null;
        }
        attackStatusPulseCoroutine = null;
    }
    public void FlashTerritory(string territoryName)
    {
        Vector2 uv = TerritoryGraphRenderer.GetTerritoryPosition(territoryName);
        if (uv == Vector2.zero) return;
        Vector2 anchor = new Vector2(
            Mathf.Lerp(MapAnchorMin.x, MapAnchorMax.x, Mathf.Clamp01(uv.x)),
            Mathf.Lerp(MapAnchorMin.y, MapAnchorMax.y, 1f - Mathf.Clamp01(uv.y)));
        StartCoroutine(PulseRingCoroutine(anchor.x, anchor.y));
    }
    IEnumerator PulseRingCoroutine(float ax, float ay)
    {
        GameObject ring = new GameObject("PulseRing", typeof(RectTransform));
        ring.transform.SetParent(canvas.transform, false);
        Image ringImg = ring.AddComponent<Image>();
        ringImg.color = new Color(0.83f, 0.65f, 0.22f, 0.8f);
        ringImg.raycastTarget = false;
        ringImg.type = Image.Type.Sliced;
        RectTransform rr = ring.GetComponent<RectTransform>();
        rr.anchorMin = new Vector2(ax, ay);
        rr.anchorMax = new Vector2(ax, ay);
        rr.sizeDelta = Vector2.zero;

        float duration = 1.2f;
        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            float size = Mathf.Lerp(4f, 40f, t);
            rr.sizeDelta = new Vector2(size, size);
            ringImg.color = new Color(0.83f, 0.65f, 0.22f, Mathf.Lerp(0.8f, 0f, t));
            yield return null;
        }
        Destroy(ring);
    }
}
