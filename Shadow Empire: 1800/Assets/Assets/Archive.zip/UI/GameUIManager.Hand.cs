using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public partial class GameUIManager : MonoBehaviour
{
    public void UpdatePlayerHand(List<CardData> hand)
    {
        HideTooltip();
        foreach (Transform t in handArea.transform) Destroy(t.gameObject);
        foreach (Transform t in playedArea.transform) Destroy(t.gameObject);
        handCards.Clear();
        UpdateCardsRemaining();

        List<CardData> sorted = new List<CardData>(hand);
        sorted.Sort((a, b) => SortOrder(a.cardType).CompareTo(SortOrder(b.cardType)));
        foreach (CardData card in sorted) CreateHandCard(card);
        ApplyHandFanLayout();
    }
    void RefreshHandUI()
    {
        FactionData debugPlayer = GameManager.Instance?.GetPlayerFaction();
        Debug.Log($"[GameUIManager] RefreshHandUI called. State={GameManager.Instance?.currentState}, HandCount={debugPlayer?.hand?.Count ?? -1}, HandArea active={handArea?.activeInHierarchy}");
        if (debugPlayer != null)
            UpdatePlayerHand(debugPlayer.hand);
    }
    void ApplyHandFanLayout()
    {
        int count = handCards.Count;
        float fanAngle = Mathf.Min(4f, 20f / Mathf.Max(count, 1));
        float startAngle = -(count - 1) * fanAngle / 2f;

        for (int i = 0; i < handCards.Count; i++)
        {
            float angle = startAngle + i * fanAngle;
            float verticalOffset = -Mathf.Abs(angle) * 0.8f;

            RectTransform rt = handCards[i].GetComponent<RectTransform>();
            rt.localRotation = Quaternion.Euler(0, 0, angle);
            Vector2 basePos = handCards[i].originalPosition != Vector2.zero
                ? handCards[i].originalPosition
                : rt.anchoredPosition;
            rt.anchoredPosition = new Vector2(basePos.x, basePos.y + verticalOffset);

            handCards[i].originalAngle = angle;
            if (handCards[i].originalPosition == Vector2.zero)
                handCards[i].originalPosition = basePos;
        }
    }
    int SortOrder(CardType t) => t switch
    {
        CardType.ATTACK => 0,
        CardType.SABOTAGE => 1,
        CardType.DEFENSE => 2,
        CardType.INFLUENCE => 3,
        CardType.FARMING => 4,
        CardType.BLACK_MARKET => 5,
        _ => 6
    };
    void CreateHandCard(CardData card)
    {
        GameObject go = Instantiate(cardPrefab, handArea.transform);
        go.SetActive(true);
        go.name = card.cardName;
        CardUIController cc = go.GetComponent<CardUIController>();
        cc.BuildCard();
        Color fc = Color.gray;
        if (GameManager.Instance != null && card.factionId >= 0 && card.factionId < GameManager.Instance.factions.Count)
            fc = GameManager.Instance.factions[card.factionId].factionColor;
        cc.SetCard(card, fc);
        cc.SetInteractable(GameManager.Instance.currentState == GameState.PLAY_PHASE);
        CardData cap = card;
        cc.onCardClicked += () => OnHandCardClicked(cap);
        handCards.Add(cc);
    }
    void OnHandCardClicked(CardData card)
    {
        if (GameManager.Instance.currentState != GameState.PLAY_PHASE) return;
        if (isSelectingTarget) return;
        if (!GameManager.Instance.CanPlayMoreCards()) { AddLogMessage($"Maximum {GameManager.Instance.MaxCardsPerTurn} cards per turn."); StartCoroutine(ShakeCard(FindCardGO(card))); return; }

        switch (card.cardType)
        {
            case CardType.ATTACK:
                ShowAttackModeChoice(card);
                break;
            case CardType.SABOTAGE:
            case CardType.BLACK_MARKET:
                EnterTargetMode(card);
                break;
            default:
                StartCoroutine(AnimateCardPlay(card, GetCardWorldPosition(card)));
                GameManager.Instance.PlayCard(card, GameManager.Instance.GetPlayerFaction());
                break;
        }
    }
    GameObject FindCardGO(CardData card)
    {
        foreach (CardUIController cc in handCards)
            if (cc.CurrentCard == card) return cc.gameObject;
        return null;
    }
    IEnumerator ShakeCamera(float duration = 0.25f, float magnitude = 0.008f)
    {
        Camera cam = Camera.main;
        if (cam == null) yield break;
        Vector3 origin = cam.transform.localPosition;
        float t = 0f;
        while (t < duration)
        {
            float decay = 1f - (t / duration);
            cam.transform.localPosition = origin + new Vector3(
                UnityEngine.Random.Range(-1f, 1f),
                UnityEngine.Random.Range(-1f, 1f),
                0f) * magnitude * decay;
            t += Time.deltaTime;
            yield return null;
        }
        cam.transform.localPosition = origin;
    }
    IEnumerator PulseBadge(GameObject badge)
    {
        float t = 0f;
        while (t < 0.25f)
        {
            float s = 1f + 0.4f * Mathf.Sin(t / 0.25f * Mathf.PI);
            badge.transform.localScale = Vector3.one * s;
            t += Time.deltaTime;
            yield return null;
        }
        badge.transform.localScale = Vector3.one;
    }
    IEnumerator ShakeCard(GameObject cardGO)
    {
        if (cardGO == null) yield break;
        RectTransform rt = cardGO.GetComponent<RectTransform>();
        Vector2 origin = rt.anchoredPosition;
        float[] offsets = { -8f, 8f, -6f, 6f, -4f, 4f, 0f };
        foreach (float off in offsets)
        {
            rt.anchoredPosition = new Vector2(origin.x + off, origin.y);
            yield return new WaitForSeconds(0.04f);
        }
        rt.anchoredPosition = origin;
    }
    void EnterTargetMode(CardData card)
    {
        isSelectingTarget = true;
        waitingForTarget = true;
        pendingCard = card;
        pendingCardPosition = GetCardWorldPosition(card);
        targetPopupCardName.text = card.cardName;
        targetPopup.SetActive(true);
        FactionData player = GameManager.Instance.GetPlayerFaction();
        foreach (FactionPanelUI p in factionPanels)
            if (p.faction != player && !p.faction.isEliminated) p.SetHighlight(true);
        AddLogMessage($"Select a target for {card.cardName}...");
    }
    void ExitTargetMode()
    {
        isSelectingTarget = false;
        waitingForTarget = false;
        waitingForTerritoryAttackSource = false;
        waitingForTerritoryAttackTarget = false;
        pendingCard = null;
        pendingCardPosition = Vector3.zero;
        pendingAttackSourceTerritory = null;
        if (targetPopup != null) targetPopup.SetActive(false);
        foreach (FactionPanelUI p in factionPanels) p.SetHighlight(false);
        ClearTerritoryHighlights();
    }
    void OnFactionPanelClicked(FactionData faction)
    {
        if (!waitingForTarget || pendingCard == null) return;
        FactionData player = GameManager.Instance.GetPlayerFaction();
        if (faction == player || faction.isEliminated) return;
        CardData card = pendingCard;
        pendingCard = null;
        if (card.cardType == CardType.SABOTAGE)
        {
            pendingMinigameFactionTarget = faction;
            BuildCipherMinigame(card, faction.territories.FirstOrDefault());
            ExitTargetMode();
            return;
        }
        if (card.cardType == CardType.INFLUENCE)
        {
            pendingMinigameFactionTarget = faction;
            BuildNegotiationMinigame(card, faction);
            ExitTargetMode();
            return;
        }
        StartCoroutine(AnimateCardPlay(card, pendingCardPosition));
        GameManager.Instance.PlayCard(card, faction);
        ExitTargetMode();
    }
    public GameObject BuildCipherMinigame(CardData card, TerritoryData target)
    {
        GameObject overlay = CreateMinigameOverlay("CipherMinigame", "THE CIPHER");
        Transform panel = overlay.transform.Find("Panel");
        Text resultText = MakeUIText(panel, "Result", 15, FontStyle.Bold, Parchment,
            new Vector2(0.08f, 0.08f), new Vector2(0.92f, 0.18f)).GetComponent<Text>();
        resultText.text = "Find the marked cells.";

        HashSet<int> marked = new HashSet<int>();
        while (marked.Count < 6) marked.Add(Random.Range(0, 16));
        int clicks = 0;
        int bonus = 0;

        for (int i = 0; i < 16; i++)
        {
            int idx = i;
            Button btn = CreateMinigameButton(panel, "C" + i, "", 0.12f + (i % 4) * 0.19f, 0.22f + (3 - i / 4) * 0.13f, 0.16f, 0.10f);
            btn.onClick.AddListener(() =>
            {
                if (!btn.interactable || clicks >= 4) return;
                clicks++;
                bool hit = marked.Contains(idx);
                bonus += hit ? 3 : -1;
                btn.GetComponent<Image>().color = hit ? new Color(0.25f, 0.55f, 0.20f) : new Color(0.55f, 0.15f, 0.10f);
                btn.interactable = false;
                resultText.text = $"Clicks {clicks}/4 | Bonus {bonus:+#;-#;0}";
                if (clicks >= 4)
                {
                    lastMinigameBonus = bonus;
                    GameManager.Instance.pendingCardPowerBonus = bonus;
                    CompleteMinigameCard(card, pendingMinigameFactionTarget, overlay);
                }
            });
        }
        return overlay;
    }
    public GameObject BuildNegotiationMinigame(CardData card, FactionData target)
    {
        GameObject overlay = CreateMinigameOverlay("NegotiationMinigame", "THE NEGOTIATION");
        Transform panel = overlay.transform.Find("Panel");
        int hiddenTarget = Random.Range(30, 71);
        Slider slider = new GameObject("OfferSlider", typeof(RectTransform)).AddComponent<Slider>();
        slider.transform.SetParent(panel, false);
        Anchor(slider.GetComponent<RectTransform>(), 0.12f, 0.42f, 0.88f, 0.52f);
        slider.minValue = 0f;
        slider.maxValue = 100f;
        slider.value = 50f;
        GameObject sliderBg = new GameObject("Background", typeof(RectTransform));
        sliderBg.transform.SetParent(slider.transform, false);
        Image sliderBgImg = sliderBg.AddComponent<Image>();
        sliderBgImg.color = Med;
        FullStretch(sliderBg.GetComponent<RectTransform>());
        GameObject sliderFill = new GameObject("Fill", typeof(RectTransform));
        sliderFill.transform.SetParent(slider.transform, false);
        Image sliderFillImg = sliderFill.AddComponent<Image>();
        sliderFillImg.color = Gold.WithA(0.75f);
        FullStretch(sliderFill.GetComponent<RectTransform>());
        GameObject sliderHandle = new GameObject("Handle", typeof(RectTransform));
        sliderHandle.transform.SetParent(slider.transform, false);
        Image sliderHandleImg = sliderHandle.AddComponent<Image>();
        sliderHandleImg.color = Parchment;
        RectTransform handleRect = sliderHandle.GetComponent<RectTransform>();
        handleRect.sizeDelta = new Vector2(18, 18);
        slider.targetGraphic = sliderHandleImg;
        slider.fillRect = sliderFill.GetComponent<RectTransform>();
        slider.handleRect = handleRect;
        Text resultText = MakeUIText(panel, "Result", 15, FontStyle.Bold, Parchment,
            new Vector2(0.12f, 0.25f), new Vector2(0.88f, 0.35f)).GetComponent<Text>();
        resultText.text = "Offer";

        Button submit = CreateMinigameButton(panel, "Submit", "SUBMIT", 0.35f, 0.12f, 0.30f, 0.10f);
        submit.onClick.AddListener(() =>
        {
            submit.interactable = false;
            int diff = Mathf.Abs(Mathf.RoundToInt(slider.value) - hiddenTarget);
            int bonus = diff <= 10 ? 5 : diff <= 20 ? 0 : -Mathf.Max(1, card.power / 2);
            lastMinigameBonus = bonus;
            GameManager.Instance.pendingCardPowerBonus = bonus;
            resultText.text = diff <= 10 ? "Perfect agreement." : diff <= 20 ? "Accepted." : "Rejected. Half effect.";
            CompleteMinigameCard(card, target, overlay);
        });
        return overlay;
    }
    public GameObject BuildAmbushMinigame(TerritoryData source, TerritoryData target, System.Action<int> onResult)
    {
        GameObject overlay = CreateMinigameOverlay("AmbushMinigame", "THE AMBUSH");
        Transform panel = overlay.transform.Find("Panel");
        string[] routes = { "N", "S", "E", "W", "HOLD" };
        string escape = routes[Random.Range(0, routes.Length)];
        bool resolved = false;
        Text resultText = MakeUIText(panel, "Result", 15, FontStyle.Bold, Parchment,
            new Vector2(0.10f, 0.22f), new Vector2(0.90f, 0.32f)).GetComponent<Text>();
        resultText.text = "Choose the escape route.";
        for (int i = 0; i < routes.Length; i++)
        {
            string route = routes[i];
            Button btn = CreateMinigameButton(panel, "Route" + route, route, 0.08f + i * 0.17f, 0.45f, 0.14f, 0.12f);
            btn.onClick.AddListener(() =>
            {
                if (resolved) return;
                resolved = true;
                int bonus = route == escape ? 2 : 0;
                lastMinigameBonus = bonus;
                resultText.text = bonus > 0 ? "Ambush successful." : "The target slips away.";
                StartCoroutine(CloseMinigameAfterDelay(overlay, () => onResult?.Invoke(bonus)));
            });
        }
        return overlay;
    }
    GameObject CreateMinigameOverlay(string name, string title)
    {
        if (activeMinigamePanel != null) Destroy(activeMinigamePanel);
        GameObject overlay = new GameObject(name, typeof(RectTransform));
        overlay.transform.SetParent(canvas.transform, false);
        FullStretch(overlay.GetComponent<RectTransform>());
        Image bg = overlay.AddComponent<Image>();
        bg.color = new Color(0f, 0f, 0f, 0.75f);
        bg.raycastTarget = true;

        GameObject panel = new GameObject("Panel", typeof(RectTransform));
        panel.transform.SetParent(overlay.transform, false);
        Image panelBg = panel.AddComponent<Image>();
        panelBg.color = Darkest;
        Anchor(panel.GetComponent<RectTransform>(), 0.30f, 0.30f, 0.70f, 0.70f);
        MakeUIText(panel.transform, "Title", 22, FontStyle.Bold, Gold,
            new Vector2(0.08f, 0.80f), new Vector2(0.92f, 0.94f)).GetComponent<Text>().text = title;
        activeMinigamePanel = overlay;
        return overlay;
    }
    Button CreateMinigameButton(Transform parent, string name, string label, float x, float y, float w, float h)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        Image img = go.AddComponent<Image>();
        img.color = Med;
        Button btn = go.AddComponent<Button>();
        btn.targetGraphic = img;
        Anchor(go.GetComponent<RectTransform>(), x, y, x + w, y + h);
        MakeUIText(go.transform, "Label", 16, FontStyle.Bold, Parchment, Vector2.zero, Vector2.one).GetComponent<Text>().text = label;
        return btn;
    }
    void CompleteMinigameCard(CardData card, FactionData target, GameObject overlay)
    {
        StartCoroutine(CloseMinigameAfterDelay(overlay, () =>
        {
            StartCoroutine(AnimateCardPlay(card, pendingCardPosition));
            GameManager.Instance.PlayCard(card, target);
            pendingMinigameFactionTarget = null;
        }));
    }
    IEnumerator CloseMinigameAfterDelay(GameObject overlay, System.Action afterClose)
    {
        yield return new WaitForSeconds(1.5f);
        if (overlay != null) Destroy(overlay);
        if (activeMinigamePanel == overlay) activeMinigamePanel = null;
        afterClose?.Invoke();
    }
    void OnFactionEliminated(FactionData faction)
    {
        if (faction == null) return;
        if (!eliminatedFactions.Contains(faction.factionId)) eliminatedFactions.Add(faction.factionId);
        foreach (FactionPanelUI p in factionPanels)
            if (p.faction == faction) { p.SetEliminatedVisuals(); break; }
        if (factionPanelRoots.ContainsKey(faction.factionId))
        {
            GameObject panelRoot = factionPanelRoots[faction.factionId];
            Image bg = panelRoot.GetComponent<Image>();
            if (bg != null) bg.color = new Color(0.12f, 0.08f, 0.06f, 0.5f);
            GameObject stamp = new GameObject("EliminatedStamp");
            stamp.transform.SetParent(panelRoot.transform, false);
            RectTransform sr = stamp.AddComponent<RectTransform>();
            sr.anchorMin = Vector2.zero; sr.anchorMax = Vector2.one;
            sr.sizeDelta = Vector2.zero;
            Text st = stamp.AddComponent<Text>();
            st.text = "ELIMINATED";
            st.font = GetFont();
            st.fontSize = 14; st.fontStyle = FontStyle.Bold;
            st.color = new Color(0.8f, 0.1f, 0.1f, 0.7f);
            st.alignment = TextAnchor.MiddleCenter;
            st.raycastTarget = false;
            stamp.transform.localRotation = Quaternion.Euler(0, 0, -25f);
        }
        UpdateTerritoryMap();
    }
    Vector3 GetCardWorldPosition(CardData card)
    {
        foreach (CardUIController cc in handCards)
            if (cc.CurrentCard == card) return cc.transform.position;
        return Vector3.zero;
    }
    IEnumerator AnimateCardPlay(CardData card, Vector3 startPos)
    {
        GameObject ghost = Instantiate(cardPrefab, canvas.transform);
        ghost.SetActive(true);
        ghost.transform.position = startPos;
        CardUIController gc = ghost.GetComponent<CardUIController>();
        if (gc != null)
        {
            gc.BuildCard();
            Color ghostColor = Color.gray;
            if (GameManager.Instance != null && card.factionId >= 0 && card.factionId < GameManager.Instance.factions.Count)
                ghostColor = GameManager.Instance.factions[card.factionId].factionColor;
            gc.SetCard(card, ghostColor);
            gc.SetInteractable(false);
        }
        CanvasGroup gcg = ghost.GetComponent<CanvasGroup>();
        if (gcg != null) gcg.alpha = 1f;
        Vector3 center = new Vector3(Screen.width * 0.5f, Screen.height * 0.5f, 0f);
        for (float e = 0; e < 0.25f; e += Time.deltaTime)
        {
            ghost.transform.position = Vector3.Lerp(startPos, center, e / 0.25f);
            yield return null;
        }
        ghost.transform.position = center;
        yield return new WaitForSeconds(0.3f);
        if (gcg != null)
        {
            for (float e = 0; e < 0.2f; e += Time.deltaTime)
            {
                gcg.alpha = Mathf.Lerp(1f, 0f, e / 0.2f);
                yield return null;
            }
        }
        Destroy(ghost);
    }
    IEnumerator PlayCardAnimation(GameObject cardGO)
    {
        if (cardGO == null) yield break;
        RectTransform rt = cardGO.GetComponent<RectTransform>();
        if (rt == null) yield break;
        Vector2 startPos = rt.anchoredPosition;
        Vector2 endPos = startPos + new Vector2(0f, 200f);
        CanvasGroup cg = cardGO.GetComponent<CanvasGroup>();
        float t = 0f;
        while (t < 0.3f)
        {
            t += Time.deltaTime;
            float frac = Mathf.Clamp01(t / 0.3f);
            rt.anchoredPosition = Vector2.Lerp(startPos, endPos, frac);
            float scale = Mathf.Lerp(1f, 1.3f, frac);
            rt.localScale = Vector3.one * scale;
            if (cg != null && frac > 0.5f)
                cg.alpha = Mathf.Lerp(1f, 0f, (frac - 0.5f) * 2f);
            yield return null;
        }
        Destroy(cardGO);
    }
    public void FlashFactionPanel(int factionId)
    {
        foreach (FactionPanelUI p in factionPanels)
            if (p.faction != null && p.faction.factionId == factionId) { p.FlashDamage(); break; }
        if (factionPanelRoots.TryGetValue(factionId, out GameObject panel))
            StartCoroutine(FlashPanelBorder(panel, factionId));
    }
    IEnumerator FlashPanelBorder(GameObject panel, int factionId)
    {
        Image bg = panel.GetComponentInChildren<Image>();
        if (bg == null)
        {
            Debug.LogWarning("[GameUIManager] FlashPanelBorder: No Image component found on panel or children");
            yield break;
        }

        Color orig = bg.color;
        Color hitColor = new Color(0.8f, 0.1f, 0.05f, 0.85f);
        float t = 0f;
        while (t < 0.4f)
        {
            bg.color = Color.Lerp(hitColor, orig, t / 0.4f);
            t += Time.deltaTime;
            yield return null;
        }
        bg.color = orig;
    }
    public void UpdateAllFactions()
    {
        foreach (FactionPanelUI p in factionPanels) p.UpdateStats();
        // ADDED: UPGRADE 4 - refresh region bonus display every turn
        UpdateRegionBonusDisplay();
    }
    public void EnableCardInteractions(bool enabled)
    {
        if (!enabled) HideTooltip();
        foreach (CardUIController c in handCards) c.SetInteractable(enabled);
    }
    void OnAnyCardPlayed(CardData card, FactionData source, FactionData target)
    {
        if (GameManager.Instance == null) return;
        int remaining = GameManager.Instance.MaxCardsPerTurn - GameManager.Instance.CardsPlayedThisTurn;
        string label = $"\u25B6  {remaining} card{(remaining != 1 ? "s" : "")} remaining";
        ShowPhase(label, new Color(0.3f, 0.7f, 0.3f));
    }
    void UpdateCardsRemaining()
    {
        if (cardsRemainingText == null || GameManager.Instance == null) return;
        int played = GameManager.Instance.CardsPlayedThisTurn;
        int max = GameManager.Instance.MaxCardsPerTurn;
        FactionData player = GameManager.Instance.GetPlayerFaction();
        int handCount = player != null ? player.hand.Count : 0;
        string handStr = handCount >= 7
        ? $"<color=#C8A040>HAND FULL</color>"
        : $"Hand:{handCount}/7";
        cardsRemainingText.text = $"Cards:{played}/{max} {handStr}";
        cardsRemainingText.color = played >= max
        ? new Color(0.80f, 0.25f, 0.10f)
        : Parchment;
        if (GameManager.Instance.CardsPlayedThisTurn >= GameManager.Instance.MaxCardsPerTurn)
            StartCoroutine(PulseEndTurnButton());
    }
    public void ShowTooltip(CardData card, Vector3 worldPosition)
    {
        if (GameManager.Instance.currentState != GameState.PLAY_PHASE) return;
        tooltipNameText.text = card.cardName;
        (tooltipTypeText.text, tooltipTypeText.color) = card.cardType switch
        {
            CardType.ATTACK => ("ATTACK", new Color(0.75f, 0.30f, 0.25f)),
            CardType.DEFENSE => ("DEFENSE", new Color(0.30f, 0.45f, 0.70f)),
            CardType.INFLUENCE => ("INFLUENCE", new Color(0.30f, 0.65f, 0.30f)),
            CardType.SABOTAGE => ("SABOTAGE", new Color(0.60f, 0.30f, 0.60f)),
            CardType.FARMING => ("FARMING", new Color(0.50f, 0.38f, 0.20f)),
            CardType.BLACK_MARKET => ("BLACK MARKET", new Color(0.65f, 0.45f, 0.12f)),
            _ => ("UNKNOWN", Color.white)
        };
        tooltipPowerText.text = $"Power: {card.power}";
        tooltipDescriptionText.text = card.description;

        RectTransform canvasRT = canvas.GetComponent<RectTransform>();
        Vector2 localPoint;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRT,
                                                                new Vector2(worldPosition.x, worldPosition.y), null, out localPoint);
        Vector2 ap = localPoint + Vector2.Scale(canvasRT.rect.size, canvasRT.pivot);
        ap.y += ap.y + 330f > canvasRT.rect.height ? -170f : 170f;
        tooltipPanel.GetComponent<RectTransform>().anchoredPosition = ap;
        tooltipPanel.SetActive(true);
    }
    public void HideTooltip() { if (tooltipPanel != null) tooltipPanel.SetActive(false); }
    Color GetTypeColor(CardType type)
    {
        switch (type)
        {
            case CardType.ATTACK: return new Color(0.8f, 0.2f, 0.2f);
            case CardType.DEFENSE: return new Color(0.2f, 0.4f, 0.9f);
            case CardType.INFLUENCE: return new Color(0.8f, 0.7f, 0.1f);
            case CardType.SABOTAGE: return new Color(0.5f, 0.1f, 0.7f);
            case CardType.FARMING: return new Color(0.2f, 0.7f, 0.3f);
            case CardType.BLACK_MARKET: return new Color(0.6f, 0.4f, 0.1f);
            default: return Color.gray;
        }
    }
    string GetTypeHexColor(CardType type)
    {
        Color c = GetTypeColor(type);
        return ColorUtility.ToHtmlStringRGB(c);
    }
    public void FlashLegendaryDraw()
    {
        StartCoroutine(LegendaryDrawRoutine());
    }
    IEnumerator LegendaryDrawRoutine()
    {
        Image flashImg = null;
        GameObject flashGO = new GameObject("LegendaryFlash", typeof(RectTransform));
        flashGO.transform.SetParent(canvas.transform, false);
        flashImg = flashGO.AddComponent<Image>();
        flashImg.color = new Color(1f, 0.84f, 0f, 0.3f);
        flashImg.raycastTarget = false;
        FullStretch(flashGO.GetComponent<RectTransform>());

        float elapsed = 0f;
        while (elapsed < 0.5f)
        {
            elapsed += Time.deltaTime;
            flashImg.color = new Color(1f, 0.84f, 0f, Mathf.Lerp(0.3f, 0f, elapsed / 0.5f));
            yield return null;
        }
        Destroy(flashGO);

        if (handCards.Count > 0)
        {
            GameObject legendLabel = new GameObject("LegendaryLabel", typeof(RectTransform));
            legendLabel.transform.SetParent(canvas.transform, false);
            Text lt = legendLabel.AddComponent<Text>();
            lt.font = GetFont();
            lt.fontSize = 24;
            lt.fontStyle = FontStyle.Bold;
            lt.color = new Color(1f, 0.84f, 0f);
            lt.text = "\u2726 LEGENDARY \u2726";
            lt.alignment = TextAnchor.MiddleCenter;
            RectTransform lr = legendLabel.GetComponent<RectTransform>();
            lr.anchorMin = new Vector2(0.3f, 0.1f);
            lr.anchorMax = new Vector2(0.7f, 0.18f);
            lr.sizeDelta = Vector2.zero;

            yield return new WaitForSeconds(1.5f);

            for (float f = 0; f < 0.3f; f += Time.deltaTime)
            {
                lt.color = new Color(1f, 0.84f, 0f, Mathf.Lerp(1f, 0f, f / 0.3f));
                yield return null;
            }
            Destroy(legendLabel);
        }

        yield return new WaitForSeconds(0.3f);

        if (handCards.Count > 0)
        {
            CardUIController lastCard = handCards[handCards.Count - 1];
            if (lastCard != null && lastCard.CurrentCard != null &&
                lastCard.CurrentCard.rarity == CardRarity.LEGENDARY)
            {
                for (int i = 0; i < 8; i++)
                {
                    GameObject particle = new GameObject("GoldParticle", typeof(RectTransform));
                    particle.transform.SetParent(canvas.transform, false);
                    Image pImg = particle.AddComponent<Image>();
                    pImg.color = new Color(1f, 0.84f, 0f);
                    pImg.raycastTarget = false;
                    RectTransform pR = particle.GetComponent<RectTransform>();
                    pR.sizeDelta = new Vector2(4, 4);

                    Vector3 cardPos = lastCard.transform.position;
                    pR.anchorMin = pR.anchorMax = new Vector2(0.5f, 0.5f);
                    pR.anchoredPosition = cardPos;

                    Vector2 dir = Random.insideUnitCircle.normalized * Random.Range(30f, 80f);
                    StartCoroutine(ParticleBurst(particle, dir));
                }
            }
        }
    }
    IEnumerator ParticleBurst(GameObject particle, Vector2 velocity)
    {
        if (particle == null) yield break;
        RectTransform pr = particle.GetComponent<RectTransform>();
        Image pImg = particle.GetComponent<Image>();
        float elapsed = 0f;
        Vector3 startPos = pr.anchoredPosition;
        while (elapsed < 0.5f && particle != null)
        {
            elapsed += Time.deltaTime;
            pr.anchoredPosition = startPos + (Vector3)(velocity * elapsed);
            if (pImg != null)
                pImg.color = new Color(1f, 0.84f, 0f, Mathf.Lerp(1f, 0f, elapsed / 0.5f));
            yield return null;
        }
        if (particle != null) Destroy(particle);
    }
    void UpdateSparklineChart(Color lineColor)
    {
        if (probabilityHistory.Count < 2) return;

        Transform pp = probabilityPanel != null ? probabilityPanel.transform : null;
        if (pp == null) return;
        Transform existing = pp.Find("SparklineChart");
        if (existing != null) Destroy(existing.gameObject);

        GameObject chartGO = new GameObject("SparklineChart", typeof(RectTransform));
        chartGO.transform.SetParent(pp, false);

        int w = 80;
        int h = 40;
        RectTransform chartR = chartGO.GetComponent<RectTransform>();
        chartR.anchorMin = new Vector2(0.02f, 0.01f);
        chartR.anchorMax = new Vector2(0.98f, 0.06f);
        chartR.sizeDelta = Vector2.zero;

        Texture2D tex = new Texture2D(w, h);
        for (int x = 0; x < w; x++)
            for (int y = 0; y < h; y++)
                tex.SetPixel(x, y, new Color(0.04f, 0.02f, 0.01f));

        int count = probabilityHistory.Count;
        for (int i = 0; i < count - 1; i++)
        {
            float x1 = (float)i / (count - 1) * (w - 1);
            float x2 = (float)(i + 1) / (count - 1) * (w - 1);
            float y1 = (1f - probabilityHistory[i] / 100f) * (h - 1);
            float y2 = (1f - probabilityHistory[i + 1] / 100f) * (h - 1);
            DrawLine(tex, Mathf.RoundToInt(x1), Mathf.RoundToInt(y1),
                     Mathf.RoundToInt(x2), Mathf.RoundToInt(y2), lineColor);
        }
        tex.Apply();

        Image chartImg = chartGO.AddComponent<Image>();
        chartImg.sprite = Sprite.Create(tex, new Rect(0, 0, w, h), Vector2.zero);
        chartImg.raycastTarget = false;
    }
    void DrawLine(Texture2D tex, int x0, int y0, int x1, int y1, Color color)
    {
        int dx = Mathf.Abs(x1 - x0);
        int dy = Mathf.Abs(y1 - y0);
        int sx = x0 < x1 ? 1 : -1;
        int sy = y0 < y1 ? 1 : -1;
        int err = dx - dy;

        while (true)
        {
            if (x0 >= 0 && x0 < tex.width && y0 >= 0 && y0 < tex.height)
                tex.SetPixel(x0, y0, color);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x0 += sx; }
            if (e2 < dx) { err += dx; y0 += sy; }
        }
    }
    void UpdatePlayerHandWithAnimation(List<CardData> hand)
    {
        HideTooltip();

        int oldCount = handCards.Count;
        foreach (Transform t in handArea.transform) Destroy(t.gameObject);
        foreach (Transform t in playedArea.transform) Destroy(t.gameObject);
        handCards.Clear();
        UpdateCardsRemaining();

        List<CardData> sorted = new List<CardData>(hand);
        sorted.Sort((a, b) => SortOrder(a.cardType).CompareTo(SortOrder(b.cardType)));

        int newCardCount = 0;
        foreach (CardData card in sorted)
        {
            GameObject go = Instantiate(cardPrefab, handArea.transform);
            go.SetActive(true);
            go.name = card.cardName;
            CardUIController cc = go.GetComponent<CardUIController>();
            cc.BuildCard();
            Color fc = Color.gray;
            if (GameManager.Instance != null && card.factionId >= 0 && card.factionId < GameManager.Instance.factions.Count)
                fc = GameManager.Instance.factions[card.factionId].factionColor;
            cc.SetCard(card, fc);
            cc.SetInteractable(GameManager.Instance.currentState == GameState.PLAY_PHASE);
            CardData cap = card;
            cc.onCardClicked += () => OnHandCardClicked(cap);
            handCards.Add(cc);

            if (oldCount < hand.Count && newCardCount >= hand.Count - oldCount)
            {
                StartCoroutine(AnimateNewCard(go));
            }
            newCardCount++;
        }
        ApplyHandFanLayout();
    }
    IEnumerator AnimateNewCard(GameObject cardGO)
    {
        if (cardGO == null) yield break;
        CanvasGroup cg = cardGO.GetComponent<CanvasGroup>();
        if (cg == null) cg = cardGO.AddComponent<CanvasGroup>();
        cg.alpha = 0f;
        cardGO.transform.localScale = new Vector3(0.5f, 0.5f, 1f);

        float elapsed = 0f;
        float duration = 0.25f;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            if (cg != null) cg.alpha = Mathf.Lerp(0f, 1f, t);
            cardGO.transform.localScale = Vector3.Lerp(new Vector3(0.5f, 0.5f, 1f), Vector3.one, t);
            yield return null;
        }
        if (cg != null) cg.alpha = 1f;
        cardGO.transform.localScale = Vector3.one;

        CardUIController cc = cardGO.GetComponent<CardUIController>();
        if (cc != null && cc.CurrentCard != null && cc.CurrentCard.rarity == CardRarity.LEGENDARY)
        {
            FlashLegendaryDraw();
        }
    }
    void PreGenerateCardSprites()
    {
        // Base card body: 200x280px, radius 16, dark fill + dim gold border
        cardBaseSprite = RoundedRectGenerator.Generate(200, 280, 16,
            new Color(0.08f, 0.05f, 0.02f),
            new Color(0.55f, 0.40f, 0.08f), 3);

        // Art frame: 180x120px, radius 10
        cardArtFrameSprite = RoundedRectGenerator.Generate(180, 120, 10,
            new Color(0.12f, 0.08f, 0.04f),
            new Color(0.40f, 0.30f, 0.05f), 2);

        // Rarity glow ring: 210x290px, radius 18, transparent fill + gold border
        cardRarityGlowSprite = RoundedRectGenerator.Generate(210, 290, 18,
            Color.clear,
            new Color(1f, 0.84f, 0f, 0.85f), 4);

        // Power badge circle: 24x24px, radius 12
        cardPowerBadgeSprite = RoundedRectGenerator.Generate(24, 24, 12,
            new Color(0.05f, 0.03f, 0.01f),
            new Color(0.83f, 0.65f, 0.22f), 2);
    }
    void BuildCardPrefab()
    {
        cardPrefab = new GameObject("CardPrefab", typeof(RectTransform));
        cardPrefab.transform.SetParent(null);
        cardPrefab.GetComponent<RectTransform>().sizeDelta = new Vector2(80, 116);
        LayoutElement le = cardPrefab.AddComponent<LayoutElement>();
        le.preferredWidth = 80f;
        le.preferredHeight = 116f;
        le.minWidth = 60f;
        le.minHeight = 90f;
        le.flexibleWidth = 0f;
        le.flexibleHeight = 0f;

        cardPrefab.AddComponent<CardUIController>();
        if (cardPrefab.GetComponent<CanvasGroup>() == null)
            cardPrefab.AddComponent<CanvasGroup>();
        cardPrefab.SetActive(false);
    }
    void BuildFactionPanelPrefab()
    {
        factionPanelPrefab = new GameObject("FactionPanelPrefab", typeof(RectTransform));
        factionPanelPrefab.transform.SetParent(null);
        factionPanelPrefab.AddComponent<CanvasGroup>();
        factionPanelPrefab.GetComponent<RectTransform>().sizeDelta = new Vector2(250, 80);

        Image borderImg = MakeChild(factionPanelPrefab.transform, "BorderBg", Vector2.zero, Vector2.one, new Vector2(1, 1))
        .AddComponent<Image>();
        borderImg.color = Color.gray;
        Image bgImg = MakeChild(factionPanelPrefab.transform, "Bg", Vector2.zero, Vector2.one, new Vector2(-3, -3))
        .AddComponent<Image>();
        bgImg.color = new Color(0.10f, 0.055f, 0.02f, 0.97f);
        Image stripeImg = MakeChild(factionPanelPrefab.transform, "AccentStripe", new Vector2(0, 0.855f), Vector2.one, Vector2.zero)
        .AddComponent<Image>();
        stripeImg.color = Color.gray.WithA(0.9f);

        MakeHRule(factionPanelPrefab.transform, new Vector2(0.03f, 0.02f), new Vector2(0.97f, 0.045f), Gold.WithA(0.20f));

        Text nameText = MakeUIText(factionPanelPrefab.transform, "FactionName", 11, FontStyle.Bold,
                                   Parchment, new Vector2(0, 0.62f), new Vector2(0.68f, 0.86f)).GetComponent<Text>();
        Text shieldText = MakeUIText(factionPanelPrefab.transform, "StatsShield", 7, FontStyle.Normal,
                                     new Color(0.35f, 0.45f, 0.60f), new Vector2(0.70f, 0.65f), new Vector2(0.96f, 0.80f)).GetComponent<Text>();
        Text goldText = MakeUIText(factionPanelPrefab.transform, "GoldText", 8, FontStyle.Normal,
                                   new Color(0.9f, 0.75f, 0.1f), new Vector2(0.04f, 0.01f), new Vector2(0.62f, 0.14f)).GetComponent<Text>();

        Image powerBar, influenceBar, secretsBar;
        AddStatBar(factionPanelPrefab.transform, "PWR", new Color(0.75f, 0.25f, 0.15f), 0.43f, 0.57f, out powerBar);
        AddStatBar(factionPanelPrefab.transform, "INF", new Color(0.25f, 0.60f, 0.30f), 0.29f, 0.43f, out influenceBar);
        AddStatBar(factionPanelPrefab.transform, "SEC", new Color(0.55f, 0.40f, 0.10f), 0.15f, 0.29f, out secretsBar);

        GameObject statusBadgeGO = MakeChild(factionPanelPrefab.transform, "StatusBadge",
                                             new Vector2(0.65f, 0f), new Vector2(0.96f, 0.16f), Vector2.zero);
        Image sBadgeImg = statusBadgeGO.AddComponent<Image>();
        sBadgeImg.color = new Color(0.10f, 0.06f, 0.03f);
        sBadgeImg.raycastTarget = false;
        Text statusText = MakeUIText(statusBadgeGO.transform, "Status", 7, FontStyle.Bold,
                                     Parchment, Vector2.zero, Vector2.one).GetComponent<Text>();

        Button btn = factionPanelPrefab.AddComponent<Button>();
        btn.targetGraphic = bgImg;
        Navigation nav = new Navigation();
        nav.mode = Navigation.Mode.None;
        btn.navigation = nav;

        FactionPanelUI pui = factionPanelPrefab.AddComponent<FactionPanelUI>();
        pui.panelBackground = bgImg;
        pui.borderBg = borderImg;
        pui.accentStripe = stripeImg;
        pui.factionNameText = nameText;
        pui.statsPwrText = null;
        pui.statsInfText = null;
        pui.statsSecText = null;
        pui.statsShieldText = shieldText;
        pui.statsGoldText = goldText;
        pui.goldText = goldText;
        pui.statusText = statusText;
        pui.statusBadge = sBadgeImg;
        pui.powerBar = powerBar;
        pui.influenceBar = influenceBar;
        pui.secretsBar = secretsBar;
        factionPanelPrefab.SetActive(false);
    }
}
